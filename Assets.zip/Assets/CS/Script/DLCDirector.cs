using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using DLCPackage;
using MonomiPark.SlimeRancher.Persist;
using UnityEngine;

public class DLCDirector
{
	public delegate void OnPackageInstalledDelegate(Id package);

	private class PackageLoader
	{
		public readonly DLCPackageMetadata package;

		public readonly DLCContentMetadata[] content;

		public PackageLoader(Id id)
		{
			string path = Path.Combine("DLC", id.ToString().ToLowerInvariant());
			package = Resources.Load<DLCPackageMetadata>(Path.Combine(path, "package"));
			content = Resources.LoadAll<DLCContentMetadata>(Path.Combine(path, "package_metadata"));
			if (package == null)
			{
				throw new Exception(string.Format("Failed to load DLC package. [id={0}]", id));
			}
			if (content == null)
			{
				throw new Exception(string.Format("Failed to load DLC package contents. [id={0}]", id));
			}
		}
	}

	[CompilerGenerated]
	private sealed class _003C_003Ec__DisplayClass22_0
	{
		public DLCDirector _003C_003E4__this;

		public GameV12 game;

		internal bool _003CPurge_003Eb__0(Id p)
		{
			if (_003C_003E4__this.GetPackageState(p) < State.INSTALLED)
			{
				return _003C_003E4__this.PurgePackage(game, p);
			}
			return false;
		}
	}

	[Serializable]
	[CompilerGenerated]
	private sealed class _003C_003Ec
	{
		public static readonly _003C_003Ec _003C_003E9 = new _003C_003Ec();

		public static Predicate<SlimeAppearance.AppearanceSaveSet> _003C_003E9__23_0;

		public static OnPackageInstalledDelegate _003C_003E9__27_0;

		internal bool _003CPurgePackage_003Eb__23_0(SlimeAppearance.AppearanceSaveSet it)
		{
			return it == SlimeAppearance.AppearanceSaveSet.SECRET_STYLE;
		}

		internal void _003C_002Ector_003Eb__27_0(Id _003Cp0_003E)
		{
		}
	}

	[CompilerGenerated]
	private sealed class _003C_003Ec__DisplayClass25_0
	{
		public Identifiable.Id fashion;

		public Gadget.Id gadget;

		public Predicate<Identifiable.Id> _003C_003E9__4;

		public Predicate<Identifiable.Id> _003C_003E9__5;

		public Predicate<Identifiable.Id> _003C_003E9__6;

		public Predicate<Identifiable.Id> _003C_003E9__7;

		internal bool _003CPurgeFashion_003Eb__4(Identifiable.Id it)
		{
			return it == fashion;
		}

		internal bool _003CPurgeFashion_003Eb__5(Identifiable.Id it)
		{
			return it == fashion;
		}

		internal bool _003CPurgeFashion_003Eb__6(Identifiable.Id it)
		{
			return it == fashion;
		}

		internal bool _003CPurgeFashion_003Eb__7(Identifiable.Id it)
		{
			return it == fashion;
		}

		internal bool _003CPurgeFashion_003Eb__0(ActorDataV09 it)
		{
			return it.typeId == (int)fashion;
		}

		internal bool _003CPurgeFashion_003Eb__1(AmmoDataV02 d)
		{
			return d.id == fashion;
		}

		internal bool _003CPurgeFashion_003Eb__2(Gadget.Id it)
		{
			return it == gadget;
		}

		internal bool _003CPurgeFashion_003Eb__3(Gadget.Id it)
		{
			return it == gadget;
		}
	}

	[CompilerGenerated]
	private sealed class _003C_003Ec__DisplayClass26_0
	{
		public Identifiable.Id toy;

		internal bool _003CPurgeToy_003Eb__0(ActorDataV09 it)
		{
			return it.typeId == (int)toy;
		}
	}

	public static HashSet<string> SECRET_STYLE_TREASURE_PODS = new HashSet<string>
	{
		"pod1067506426", "pod0573382639", "pod0528457170", "pod0209361044", "pod2089428629", "pod0797820130", "pod0793461898", "pod1736587205", "pod1843001748", "pod1327729579",
		"pod1761631840", "pod0942230423", "pod1507800227", "pod0403498756", "pod0732526653", "pod1897070320", "pod1003003618", "pod0084486208", "pod0463402699", "pod1284546475"
	};

	private DLCProvider provider;

	private Dictionary<Id, PackageLoader> packageLoadersDict = new Dictionary<Id, PackageLoader>(IdComparer.Instance);

	public IEnumerable<Id> Installed
	{
		get
		{
			return GetSupportedPackages().Where(_003Cget_Installed_003Eb__6_0);
		}
	}

	public event OnPackageInstalledDelegate onPackageInstalled = _003C_003Ec._003C_003E9__27_0 ?? (_003C_003Ec._003C_003E9__27_0 = _003C_003Ec._003C_003E9._003C_002Ector_003Eb__27_0);

	public bool SetProvider(DLCProvider provider)
	{
		if (this.provider != null)
		{
			Log.Error("Attempting to replace existing DLC provider.");
			return false;
		}
		this.provider = provider;
		return true;
	}

	public IEnumerable<Id> GetSupportedPackages()
	{
		if (provider == null)
		{
			yield break;
		}
		foreach (Id item in provider.GetSupported())
		{
			yield return item;
		}
	}

	public bool HasReached(Id id, State state)
	{
		if (provider != null && provider.GetSupported().Contains(id))
		{
			return provider.GetState(id) >= state;
		}
		return false;
	}

	public State GetPackageState(Id id)
	{
		if (provider == null)
		{
			return State.UNDEFINED;
		}
		return provider.GetState(id);
	}

	public void ShowPackageInStore(Id id)
	{
		if (provider != null)
		{
			provider.ShowInStore(id);
		}
	}

	public bool IsPackageInstalledAndEnabled(Id id)
	{
		if (SRSingleton<SceneContext>.Instance.GameModeConfig.GetModeSettings().enableDLC)
		{
			return HasReached(id, State.INSTALLED);
		}
		return false;
	}

	public void InitForLevel()
	{
		if (provider != null && !Levels.isSpecial())
		{
			RegisterPackages();
		}
	}

	public IEnumerator RefreshPackagesAsync()
	{
		if (provider != null)
		{
			yield return provider.Refresh();
		}
	}

	public IEnumerator RegisterPackagesAsync()
	{
		yield return RefreshPackagesAsync();
		RegisterPackages();
	}

	public void RegisterPackages()
	{
		foreach (Id item in Installed)
		{
			DLCContentMetadata[] content = GetPackageLoader(item).content;
			for (int i = 0; i < content.Length; i++)
			{
				content[i].Register();
			}
			this.onPackageInstalled(item);
		}
	}

	public IEnumerable<DLCPackageMetadata> LoadPackageMetadatas()
	{
		return GetSupportedPackages().Select(_003CLoadPackageMetadatas_003Eb__18_0);
	}

	private PackageLoader GetPackageLoader(Id id)
	{
		if (packageLoadersDict.ContainsKey(id))
		{
			return packageLoadersDict[id];
		}
		return packageLoadersDict[id] = new PackageLoader(id);
	}

	public void Purge(GameV12 game)
	{
		_003C_003Ec__DisplayClass22_0 _003C_003Ec__DisplayClass22_ = new _003C_003Ec__DisplayClass22_0();
		_003C_003Ec__DisplayClass22_._003C_003E4__this = this;
		_003C_003Ec__DisplayClass22_.game = game;
		Id[] array = Enum.GetValues(typeof(Id)).Cast<Id>().Where(_003C_003Ec__DisplayClass22_._003CPurge_003Eb__0)
			.ToArray();
		if (array.Any())
		{
			throw new DLCPurgedException(array);
		}
	}

	private bool PurgePackage(GameV12 game, Id package)
	{
		int num = 0;
		switch (package)
		{
		case Id.PLAYSET_PIRATE:
			num += PurgeChromaPack(game, RanchDirector.Palette.PALETTE27);
			num += PurgeFashion(game, Gadget.Id.FASHION_POD_PIRATEY, Identifiable.Id.PIRATEY_FASHION);
			num += PurgeToy(game, Identifiable.Id.TREASURE_CHEST_TOY);
			break;
		case Id.PLAYSET_HEROIC:
			num += PurgeChromaPack(game, RanchDirector.Palette.PALETTE28);
			num += PurgeFashion(game, Gadget.Id.FASHION_POD_HEROIC, Identifiable.Id.HEROIC_FASHION);
			num += PurgeToy(game, Identifiable.Id.BOP_GOBLIN_TOY);
			break;
		case Id.PLAYSET_SCIFI:
			num += PurgeChromaPack(game, RanchDirector.Palette.PALETTE29);
			num += PurgeFashion(game, Gadget.Id.FASHION_POD_SCIFI, Identifiable.Id.SCIFI_FASHION);
			num += PurgeToy(game, Identifiable.Id.ROBOT_TOY);
			break;
		case Id.SECRET_STYLE:
			foreach (KeyValuePair<Identifiable.Id, List<SlimeAppearance.AppearanceSaveSet>> unlock in game.appearances.unlocks)
			{
				num += unlock.Value.RemoveAll(_003C_003Ec._003C_003E9__23_0 ?? (_003C_003Ec._003C_003E9__23_0 = _003C_003Ec._003C_003E9._003CPurgePackage_003Eb__23_0));
				game.appearances.selections[unlock.Key] = SlimeAppearance.AppearanceSaveSet.CLASSIC;
			}
			foreach (KeyValuePair<string, TreasurePodV01> treasurePod in game.world.treasurePods)
			{
				if (SECRET_STYLE_TREASURE_PODS.Contains(treasurePod.Key) && treasurePod.Value.state != 0)
				{
					treasurePod.Value.state = TreasurePod.State.LOCKED;
					num++;
				}
			}
			break;
		default:
			throw new InvalidOperationException();
		}
		return num > 0;
	}

	private int PurgeChromaPack(GameV12 game, RanchDirector.Palette palette)
	{
		int num = 0;
		foreach (RanchDirector.PaletteType item in game.ranch.palettes.Keys.ToList())
		{
			if (game.ranch.palettes[item] == palette)
			{
				game.ranch.palettes[item] = RanchDirector.Palette.DEFAULT;
				num++;
			}
		}
		return num;
	}

	private int PurgeFashion(GameV12 game, Gadget.Id gadget, Identifiable.Id fashion)
	{
		_003C_003Ec__DisplayClass25_0 _003C_003Ec__DisplayClass25_ = new _003C_003Ec__DisplayClass25_0();
		_003C_003Ec__DisplayClass25_.fashion = fashion;
		_003C_003Ec__DisplayClass25_.gadget = gadget;
		int num = 0;
		foreach (GordoV01 value in game.world.gordos.Values)
		{
			num += value.fashions.RemoveAll(_003C_003Ec__DisplayClass25_._003C_003E9__4 ?? (_003C_003Ec__DisplayClass25_._003C_003E9__4 = _003C_003Ec__DisplayClass25_._003CPurgeFashion_003Eb__4));
		}
		foreach (ActorDataV09 actor in game.actors)
		{
			num += actor.fashions.RemoveAll(_003C_003Ec__DisplayClass25_._003C_003E9__5 ?? (_003C_003Ec__DisplayClass25_._003C_003E9__5 = _003C_003Ec__DisplayClass25_._003CPurgeFashion_003Eb__5));
		}
		foreach (string item in game.world.placedGadgets.Keys.ToList())
		{
			if (game.world.placedGadgets[item].gadgetId == _003C_003Ec__DisplayClass25_.gadget)
			{
				num += Convert.ToInt32(game.world.placedGadgets.Remove(item));
			}
		}
		foreach (PlacedGadgetV08 value2 in game.world.placedGadgets.Values)
		{
			num += value2.fashions.RemoveAll(_003C_003Ec__DisplayClass25_._003C_003E9__6 ?? (_003C_003Ec__DisplayClass25_._003C_003E9__6 = _003C_003Ec__DisplayClass25_._003CPurgeFashion_003Eb__6));
			if (value2.drone != null)
			{
				num += value2.drone.drone.fashions.RemoveAll(_003C_003Ec__DisplayClass25_._003C_003E9__7 ?? (_003C_003Ec__DisplayClass25_._003C_003E9__7 = _003C_003Ec__DisplayClass25_._003CPurgeFashion_003Eb__7));
			}
		}
		num += game.actors.RemoveAll(_003C_003Ec__DisplayClass25_._003CPurgeFashion_003Eb__0);
		num += game.player.ammo[PlayerState.AmmoMode.DEFAULT].RemoveAll(_003C_003Ec__DisplayClass25_._003CPurgeFashion_003Eb__1);
		num += game.player.blueprints.RemoveAll(_003C_003Ec__DisplayClass25_._003CPurgeFashion_003Eb__2);
		num += game.player.availBlueprints.RemoveAll(_003C_003Ec__DisplayClass25_._003CPurgeFashion_003Eb__3);
		num += Convert.ToInt32(game.player.blueprintLocks.Remove(_003C_003Ec__DisplayClass25_.gadget));
		return num + Convert.ToInt32(game.player.gadgets.Remove(_003C_003Ec__DisplayClass25_.gadget));
	}

	private int PurgeToy(GameV12 game, Identifiable.Id toy)
	{
		_003C_003Ec__DisplayClass26_0 _003C_003Ec__DisplayClass26_ = new _003C_003Ec__DisplayClass26_0();
		_003C_003Ec__DisplayClass26_.toy = toy;
		return game.actors.RemoveAll(_003C_003Ec__DisplayClass26_._003CPurgeToy_003Eb__0);
	}

	[CompilerGenerated]
	private bool _003Cget_Installed_003Eb__6_0(Id package)
	{
		return GetPackageState(package) >= State.INSTALLED;
	}

	[CompilerGenerated]
	private DLCPackageMetadata _003CLoadPackageMetadatas_003Eb__18_0(Id id)
	{
		return GetPackageLoader(id).package;
	}
}
