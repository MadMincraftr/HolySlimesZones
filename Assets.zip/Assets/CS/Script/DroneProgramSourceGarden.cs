using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;

public class DroneProgramSourceGarden : DroneProgramSourceLandPlot
{
	[CompilerGenerated]
	private sealed class _003C_003Ec__DisplayClass1_0
	{
		public double endTime;

		public DroneProgramSourceGarden _003C_003E4__this;

		internal IEnumerable<DroneFastForwarder.GatherGroup> _003CGetFastForwardGroups_003Eb__2(SpawnResource r)
		{
			return r.GetFastForwardGroups(endTime);
		}

		internal bool _003CGetFastForwardGroups_003Eb__3(DroneFastForwarder.GatherGroup g)
		{
			return _003C_003E4__this.predicate(g.id);
		}
	}

	[Serializable]
	[CompilerGenerated]
	private sealed class _003C_003Ec
	{
		public static readonly _003C_003Ec _003C_003E9 = new _003C_003Ec();

		public static Func<DroneNetwork.LandPlotMetadata, bool> _003C_003E9__1_0;

		public static Func<DroneNetwork.LandPlotMetadata, IEnumerable<SpawnResource>> _003C_003E9__1_1;

		internal bool _003CGetFastForwardGroups_003Eb__1_0(DroneNetwork.LandPlotMetadata m)
		{
			return m.plot.typeId == LandPlot.Id.GARDEN;
		}

		internal IEnumerable<SpawnResource> _003CGetFastForwardGroups_003Eb__1_1(DroneNetwork.LandPlotMetadata m)
		{
			return m.plot.GetComponentsInChildren<SpawnResource>();
		}
	}

	protected override LandPlot.Id GetLandPlotID()
	{
		return LandPlot.Id.GARDEN;
	}

	public override IEnumerable<DroneFastForwarder.GatherGroup> GetFastForwardGroups(double endTime)
	{
		_003C_003Ec__DisplayClass1_0 _003C_003Ec__DisplayClass1_ = new _003C_003Ec__DisplayClass1_0();
		_003C_003Ec__DisplayClass1_.endTime = endTime;
		_003C_003Ec__DisplayClass1_._003C_003E4__this = this;
		return base.GetFastForwardGroups(_003C_003Ec__DisplayClass1_.endTime).Concat(drone.network.Plots.Where(_003C_003Ec._003C_003E9__1_0 ?? (_003C_003Ec._003C_003E9__1_0 = _003C_003Ec._003C_003E9._003CGetFastForwardGroups_003Eb__1_0)).SelectMany(_003C_003Ec._003C_003E9__1_1 ?? (_003C_003Ec._003C_003E9__1_1 = _003C_003Ec._003C_003E9._003CGetFastForwardGroups_003Eb__1_1)).SelectMany(_003C_003Ec__DisplayClass1_._003CGetFastForwardGroups_003Eb__2)
			.Where(_003C_003Ec__DisplayClass1_._003CGetFastForwardGroups_003Eb__3));
	}

	protected override float GetPickupRadius()
	{
		float num = base.GetPickupRadius();
		if (Identifiable.IsFruit(source.id))
		{
			ResourceCycle component = source.GetComponent<ResourceCycle>();
			if (component != null && component.GetState() == ResourceCycle.State.RIPE)
			{
				num *= 1.5f;
			}
		}
		return num;
	}
}
