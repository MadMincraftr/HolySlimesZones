public class Bundles
{
	public const string GLOBAL_BUNDLE = "global";

	public const string PEDIA_BUNDLE = "pedia";

	public const string UI_BUNDLE = "ui";

	public const string RANGE_BUNDLE = "range";

	public const string BUILD_BUNDLE = "build";

	public const string EXCHANGE_BUNDLE = "exchange";

	public const string ACTOR_BUNDLE = "actor";

	public const string TUTORIAL_BUNDLE = "tutorial";

	public const string KEYS_BUNDLE = "keys";

	public const string MAIL_BUNDLE = "mail";

	public const string ACHIEVE_BUNDLE = "achieve";
}
