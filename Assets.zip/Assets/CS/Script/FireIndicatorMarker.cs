public class FireIndicatorMarker : SRBehaviour
{
}
