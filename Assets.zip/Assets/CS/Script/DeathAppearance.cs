using System;
using UnityEngine;

[Serializable]
[CreateAssetMenu(menuName = "Slimes/Appearance Extras/Death Appearance")]
public class DeathAppearance : ScriptableObject
{
	public GameObject deathFX;
}
