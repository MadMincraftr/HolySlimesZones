public class DroneProgramSourceCorral : DroneProgramSourceLandPlot
{
	protected override LandPlot.Id GetLandPlotID()
	{
		return LandPlot.Id.CORRAL;
	}
}
