using System;
using System.Runtime.CompilerServices;
using UnityEngine;

public class CoopUI : LandPlotUI
{
	[Serializable]
	[CompilerGenerated]
	private sealed class _003C_003Ec
	{
		public static readonly _003C_003Ec _003C_003E9 = new _003C_003Ec();

		public static Func<bool> _003C_003E9__6_0;

		public static Func<bool> _003C_003E9__6_2;

		public static Func<bool> _003C_003E9__6_4;

		public static Func<bool> _003C_003E9__6_6;

		public static Func<bool> _003C_003E9__6_8;

		public static Func<bool> _003C_003E9__6_9;

		internal bool _003CCreatePurchaseUI_003Eb__6_0()
		{
			return true;
		}

		internal bool _003CCreatePurchaseUI_003Eb__6_2()
		{
			return true;
		}

		internal bool _003CCreatePurchaseUI_003Eb__6_4()
		{
			return true;
		}

		internal bool _003CCreatePurchaseUI_003Eb__6_6()
		{
			return SRSingleton<SceneContext>.Instance.ProgressDirector.GetProgress(ProgressDirector.ProgressType.MOCHI_REWARDS) >= 2;
		}

		internal bool _003CCreatePurchaseUI_003Eb__6_8()
		{
			return true;
		}

		internal bool _003CCreatePurchaseUI_003Eb__6_9()
		{
			return true;
		}
	}

	public UpgradePurchaseItem walls;

	public UpgradePurchaseItem feeder;

	public UpgradePurchaseItem vitamizer;

	public UpgradePurchaseItem deluxe;

	public PlotPurchaseItem demolish;

	public Sprite titleIcon;

	protected override GameObject CreatePurchaseUI()
	{
		PurchaseUI.Purchasable[] purchasables = new PurchaseUI.Purchasable[5]
		{
			new PurchaseUI.Purchasable("m.upgrade.name.coop.walls", walls.icon, walls.img, "m.upgrade.desc.coop.walls", walls.cost, PediaDirector.Id.COOP, UpgradeWalls, _003C_003Ec._003C_003E9__6_0 ?? (_003C_003Ec._003C_003E9__6_0 = _003C_003Ec._003C_003E9._003CCreatePurchaseUI_003Eb__6_0), _003CCreatePurchaseUI_003Eb__6_1),
			new PurchaseUI.Purchasable("m.upgrade.name.coop.feeder", feeder.icon, feeder.img, "m.upgrade.desc.coop.feeder", feeder.cost, PediaDirector.Id.COOP, UpgradeFeeder, _003C_003Ec._003C_003E9__6_2 ?? (_003C_003Ec._003C_003E9__6_2 = _003C_003Ec._003C_003E9._003CCreatePurchaseUI_003Eb__6_2), _003CCreatePurchaseUI_003Eb__6_3),
			new PurchaseUI.Purchasable("m.upgrade.name.coop.vitamizer", vitamizer.icon, vitamizer.img, "m.upgrade.desc.coop.vitamizer", vitamizer.cost, PediaDirector.Id.COOP, UpgradeVitamizer, _003C_003Ec._003C_003E9__6_4 ?? (_003C_003Ec._003C_003E9__6_4 = _003C_003Ec._003C_003E9._003CCreatePurchaseUI_003Eb__6_4), _003CCreatePurchaseUI_003Eb__6_5),
			new PurchaseUI.Purchasable("m.upgrade.name.coop.deluxe", deluxe.icon, deluxe.img, "m.upgrade.desc.coop.deluxe", deluxe.cost, PediaDirector.Id.COOP, UpgradeDeluxe, _003C_003Ec._003C_003E9__6_6 ?? (_003C_003Ec._003C_003E9__6_6 = _003C_003Ec._003C_003E9._003CCreatePurchaseUI_003Eb__6_6), _003CCreatePurchaseUI_003Eb__6_7),
			new PurchaseUI.Purchasable(MessageUtil.Qualify("ui", "l.demolish_plot"), demolish.icon, demolish.img, MessageUtil.Qualify("ui", "m.desc.demolish_plot"), demolish.cost, null, Demolish, _003C_003Ec._003C_003E9__6_8 ?? (_003C_003Ec._003C_003E9__6_8 = _003C_003Ec._003C_003E9._003CCreatePurchaseUI_003Eb__6_8), _003C_003Ec._003C_003E9__6_9 ?? (_003C_003Ec._003C_003E9__6_9 = _003C_003Ec._003C_003E9._003CCreatePurchaseUI_003Eb__6_9), "b.demolish")
		};
		return SRSingleton<GameContext>.Instance.UITemplates.CreatePurchaseUI(titleIcon, "t.coop", purchasables, false, Close);
	}

	public void UpgradeWalls()
	{
		Upgrade(LandPlot.Upgrade.WALLS, walls.cost);
	}

	public void UpgradeFeeder()
	{
		Upgrade(LandPlot.Upgrade.FEEDER, feeder.cost);
	}

	public void UpgradeVitamizer()
	{
		Upgrade(LandPlot.Upgrade.VITAMIZER, vitamizer.cost);
	}

	public void UpgradeDeluxe()
	{
		Upgrade(LandPlot.Upgrade.DELUXE_COOP, deluxe.cost);
	}

	public void Demolish()
	{
		if (playerState.GetCurrency() >= demolish.cost)
		{
			playerState.SpendCurrency(demolish.cost);
			Replace(demolish.plotPrefab);
			PlayPurchaseCue();
		}
		else
		{
			Error("e.insuf_coins");
		}
	}

	[CompilerGenerated]
	private bool _003CCreatePurchaseUI_003Eb__6_1()
	{
		return !activator.HasUpgrade(LandPlot.Upgrade.WALLS);
	}

	[CompilerGenerated]
	private bool _003CCreatePurchaseUI_003Eb__6_3()
	{
		return !activator.HasUpgrade(LandPlot.Upgrade.FEEDER);
	}

	[CompilerGenerated]
	private bool _003CCreatePurchaseUI_003Eb__6_5()
	{
		return !activator.HasUpgrade(LandPlot.Upgrade.VITAMIZER);
	}

	[CompilerGenerated]
	private bool _003CCreatePurchaseUI_003Eb__6_7()
	{
		return !activator.HasUpgrade(LandPlot.Upgrade.DELUXE_COOP);
	}
}
