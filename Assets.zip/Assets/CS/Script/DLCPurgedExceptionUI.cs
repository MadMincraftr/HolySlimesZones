using System;
using System.Linq;
using System.Runtime.CompilerServices;
using DLCPackage;
using TMPro;
using UnityEngine;

public class DLCPurgedExceptionUI : BaseUI
{
	[CompilerGenerated]
	private sealed class _003C_003Ec__DisplayClass7_0
	{
		public MessageBundle pedia;

		internal string _003CRebuildUI_003Eb__0(Id p)
		{
			return pedia.Get(string.Format("m.dlc.{0}", p.ToString().ToLowerInvariant()));
		}
	}

	[Tooltip("Text showing the error message.")]
	public TMP_Text message;

	private DLCPurgedException exception;

	private Action onContinue;

	private Action onCancel;

	public static DLCPurgedExceptionUI OnExceptionCaught(DLCPurgedExceptionUI prefab, DLCPurgedException exception, Action onContinue, Action onCancel)
	{
		DLCPurgedExceptionUI dLCPurgedExceptionUI = UnityEngine.Object.Instantiate(prefab);
		dLCPurgedExceptionUI.exception = exception;
		dLCPurgedExceptionUI.onContinue = onContinue;
		dLCPurgedExceptionUI.onCancel = onCancel;
		dLCPurgedExceptionUI.RebuildUI();
		return dLCPurgedExceptionUI;
	}

	public override void Update()
	{
		if (Closeable() && SRInput.PauseActions.cancel.WasPressed)
		{
			if (onCancel != null)
			{
				onCancel();
			}
			Close();
		}
	}

	public override void OnBundlesAvailable(MessageDirector messageDirector)
	{
		base.OnBundlesAvailable(messageDirector);
		RebuildUI();
	}

	private void RebuildUI()
	{
		_003C_003Ec__DisplayClass7_0 _003C_003Ec__DisplayClass7_ = new _003C_003Ec__DisplayClass7_0();
		MessageDirector messageDirector = SRSingleton<GameContext>.Instance.MessageDirector;
		MessageBundle bundle = messageDirector.GetBundle("ui");
		_003C_003Ec__DisplayClass7_.pedia = messageDirector.GetBundle("pedia");
		message.SetText((exception != null) ? bundle.Get("e.file_load_failed.dlc_purged", string.Join("\n", exception.packages.Select(_003C_003Ec__DisplayClass7_._003CRebuildUI_003Eb__0).ToArray())) : string.Empty);
	}

	public void OnContinue()
	{
		if (onContinue != null)
		{
			onContinue();
		}
	}

	public void OnShowPackageInStore()
	{
		if (exception != null && onCancel != null)
		{
			SRSingleton<GameContext>.Instance.DLCDirector.ShowPackageInStore(exception.packages.First());
			onCancel();
		}
	}

	public void OnCancel()
	{
		if (onCancel != null)
		{
			onCancel();
		}
	}
}
