using UnityEngine;

public interface ControllerCollisionListener
{
	void OnControllerCollision(GameObject gameObj);
}
