using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using MonomiPark.SlimeRancher.DataModel;
using UnityEngine;

public class HolidayDirector : MonoBehaviour, HolidayModel.Participant
{
	[Serializable]
	public class MonthAndDay : IEquatable<MonthAndDay>
	{
		public int month;

		public int day;

		public MonthAndDay(int month, int day)
		{
			this.month = month;
			this.day = day;
		}

		public bool Equals(MonthAndDay other)
		{
			if (month == other.month)
			{
				return day == other.day;
			}
			return false;
		}

		public override int GetHashCode()
		{
			return (month << 8) ^ day;
		}
	}

	[Serializable]
	public class OrnamentEntry
	{
		[Serializable]
		public class WeightEntry
		{
			public float weight;

			public Identifiable.Id id;
		}

		public MonthAndDay date;

		public List<WeightEntry> weights;

		public Dictionary<Identifiable.Id, float> weightDict = new Dictionary<Identifiable.Id, float>(Identifiable.idComparer);

		public void Init()
		{
			foreach (WeightEntry weight in weights)
			{
				weightDict[weight.id] = weight.weight;
			}
		}
	}

	[CompilerGenerated]
	private sealed class _003C_003Ec__DisplayClass10_0
	{
		public DateTime currentDate;

		public Func<HolidayModel.EventGordo, bool> _003C_003E9__1;

		internal bool _003COnSceneLoaded_EventGordos_003Eb__0(HolidayModel.EventGordo e)
		{
			return !e.IsLiveAsOf(currentDate);
		}

		internal bool _003COnSceneLoaded_EventGordos_003Eb__1(HolidayModel.EventGordo e)
		{
			return e.IsLiveAsOf(currentDate);
		}
	}

	[CompilerGenerated]
	private sealed class _003C_003Ec__DisplayClass12_0
	{
		public DateTime currentDate;

		public Func<HolidayModel.EventEchoNoteGordo, bool> _003C_003E9__1;

		internal bool _003COnSceneLoaded_EchoNoteGordo_003Eb__0(HolidayModel.EventEchoNoteGordo e)
		{
			return !e.IsLiveAsOf(currentDate);
		}

		internal bool _003COnSceneLoaded_EchoNoteGordo_003Eb__1(HolidayModel.EventEchoNoteGordo e)
		{
			return e.IsLiveAsOf(currentDate);
		}
	}

	public List<OrnamentEntry> ornaments = new List<OrnamentEntry>();

	private Dictionary<MonthAndDay, OrnamentEntry> ornamentDict = new Dictionary<MonthAndDay, OrnamentEntry>();

	private HolidayModel model;

	public void InitForLevel()
	{
		SRSingleton<SceneContext>.Instance.GameModel.RegisterHoliday(this);
		SceneContext.onSceneLoaded = (SceneContext.SceneLoadDelegate)Delegate.Combine(SceneContext.onSceneLoaded, new SceneContext.SceneLoadDelegate(OnSceneLoaded_EventGordos));
		SceneContext.onSceneLoaded = (SceneContext.SceneLoadDelegate)Delegate.Combine(SceneContext.onSceneLoaded, new SceneContext.SceneLoadDelegate(OnSceneLoaded_EchoNoteGordo));
	}

	public void Awake()
	{
		foreach (OrnamentEntry ornament in ornaments)
		{
			ornament.Init();
			ornamentDict[ornament.date] = ornament;
		}
	}

	public void InitModel(HolidayModel model)
	{
	}

	public void SetModel(HolidayModel model)
	{
		this.model = model;
	}

	public IEnumerable<Identifiable.Id> GetCurrOrnament()
	{
		if (DateTime.Today.Year == 2017)
		{
			MonthAndDay key = new MonthAndDay(DateTime.Today.Month, DateTime.Today.Day);
			if (ornamentDict.ContainsKey(key))
			{
				yield return Randoms.SHARED.Pick(ornamentDict[key].weightDict, Identifiable.Id.NONE);
			}
		}
	}

	private void OnSceneLoaded_EventGordos(SceneContext ctx)
	{
		_003C_003Ec__DisplayClass10_0 _003C_003Ec__DisplayClass10_ = new _003C_003Ec__DisplayClass10_0();
		SceneContext.onSceneLoaded = (SceneContext.SceneLoadDelegate)Delegate.Remove(SceneContext.onSceneLoaded, new SceneContext.SceneLoadDelegate(OnSceneLoaded_EventGordos));
		if (Levels.isSpecial() || !ctx.GameModeConfig.GetModeSettings().enableEventGordos)
		{
			model.eventGordos.Clear();
			return;
		}
		IDateProvider dateProvider = SRSingleton<SystemContext>.Instance.DateProvider;
		_003C_003Ec__DisplayClass10_.currentDate = dateProvider.GetToday();
		Log.Debug("Current System Date For Events", "Date", _003C_003Ec__DisplayClass10_.currentDate.ToString("yyyy-MM-dd"));
		bool flag = false;
		int num = model.eventGordos.RemoveWhere(_003C_003Ec__DisplayClass10_._003COnSceneLoaded_EventGordos_003Eb__0);
		flag = flag || num > 0;
		foreach (HolidayModel.EventGordo item in HolidayModel.EventGordo.INSTANCES.Where(_003C_003Ec__DisplayClass10_._003C_003E9__1 ?? (_003C_003Ec__DisplayClass10_._003C_003E9__1 = _003C_003Ec__DisplayClass10_._003COnSceneLoaded_EventGordos_003Eb__1)))
		{
			GordoModel gordoModel = SRSingleton<SceneContext>.Instance.GameModel.GetGordoModel(item.objectId);
			if (gordoModel == null)
			{
				Log.Error("Failed to active EventGordo.", "event", item);
				SentrySdk.CaptureMessage("Failed to active EventGordo!");
			}
			else
			{
				bool flag2 = model.eventGordos.Add(item);
				gordoModel.EventGordoActivate(flag2);
				flag = flag || flag2;
			}
		}
		if (flag)
		{
			StartCoroutine(ResetCratesAfterFrame());
		}
	}

	private IEnumerator ResetCratesAfterFrame()
	{
		yield return new WaitForEndOfFrame();
		ZoneDirector.Zone currentZone = SRSingleton<SceneContext>.Instance.Player.GetComponent<PlayerZoneTracker>().GetCurrentZone();
		ZoneDirector zoneDirector = ZoneDirector.zones.Get(currentZone);
		if (zoneDirector != null)
		{
			zoneDirector.ResetCrates();
		}
	}

	private void OnSceneLoaded_EchoNoteGordo(SceneContext ctx)
	{
		_003C_003Ec__DisplayClass12_0 _003C_003Ec__DisplayClass12_ = new _003C_003Ec__DisplayClass12_0();
		SceneContext.onSceneLoaded = (SceneContext.SceneLoadDelegate)Delegate.Remove(SceneContext.onSceneLoaded, new SceneContext.SceneLoadDelegate(OnSceneLoaded_EchoNoteGordo));
		if (Levels.isSpecial() || !ctx.GameModeConfig.GetModeSettings().enableEchoNoteGordos)
		{
			model.eventEchoNoteGordos.Clear();
			return;
		}
		IDateProvider dateProvider = SRSingleton<SystemContext>.Instance.DateProvider;
		_003C_003Ec__DisplayClass12_.currentDate = dateProvider.GetToday();
		Log.Debug("Current System Date For Wiggly Events", "Date", _003C_003Ec__DisplayClass12_.currentDate.ToString("yyyy-MM-dd"));
		model.eventEchoNoteGordos.RemoveWhere(_003C_003Ec__DisplayClass12_._003COnSceneLoaded_EchoNoteGordo_003Eb__0);
		foreach (HolidayModel.EventEchoNoteGordo item in HolidayModel.EventEchoNoteGordo.INSTANCES.Where(_003C_003Ec__DisplayClass12_._003C_003E9__1 ?? (_003C_003Ec__DisplayClass12_._003C_003E9__1 = _003C_003Ec__DisplayClass12_._003COnSceneLoaded_EchoNoteGordo_003Eb__1)))
		{
			EchoNoteGordoModel echoNoteGordoModel = SRSingleton<SceneContext>.Instance.GameModel.GetEchoNoteGordoModel(item.objectId);
			if (echoNoteGordoModel == null)
			{
				Log.Error("Failed to active EchoNoteGordo.", "id", item.objectId);
				SentrySdk.CaptureMessage("Failed to active EchoNoteGordo!");
			}
			else
			{
				bool isFirstActivation = model.eventEchoNoteGordos.Add(item);
				echoNoteGordoModel.Activate(isFirstActivation);
			}
		}
	}
}
