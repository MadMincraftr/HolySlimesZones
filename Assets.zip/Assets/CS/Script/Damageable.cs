using UnityEngine;

public interface Damageable
{
	bool Damage(int healthLoss, GameObject source);
}
