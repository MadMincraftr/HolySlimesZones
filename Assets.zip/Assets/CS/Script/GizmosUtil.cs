using UnityEngine;

public static class GizmosUtil
{
	public static bool IsThisOrChildSelected(GameObject gameObject)
	{
		return false;
	}
}
