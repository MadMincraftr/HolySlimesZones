using UnityEngine;

[CreateAssetMenu(menuName = "Lookup Data/Gadget Definitions")]
public class GadgetDefinitionList : ListAsset<GadgetDefinition>
{
}
