using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using DLCPackage;
using UnityEngine;
using UnityEngine.Events;

public class DLCManageUI : BaseUI
{
	[CompilerGenerated]
	private sealed class _003C_003Ec__DisplayClass5_0
	{
		public DLCDirector director;

		internal bool _003CIsEnabled_003Eb__0(Id id)
		{
			return director.HasReached(id, State.AVAILABLE);
		}
	}

	[CompilerGenerated]
	private sealed class _003C_003Ec__DisplayClass8_0
	{
		public float minLoadingTime;

		public DLCDirector director;

		public DLCManageUI _003C_003E4__this;

		public Func<DLCPackageMetadata, IEnumerable<PurchaseUI.Purchasable>> _003C_003E9__1;

		internal bool _003CRefresh_Coroutine_003Eb__0()
		{
			return Time.unscaledTime >= minLoadingTime;
		}

		internal IEnumerable<PurchaseUI.Purchasable> _003CRefresh_Coroutine_003Eb__1(DLCPackageMetadata package)
		{
			_003C_003Ec__DisplayClass8_1 _003C_003Ec__DisplayClass8_ = new _003C_003Ec__DisplayClass8_1
			{
				CS_0024_003C_003E8__locals1 = this,
				package = package
			};
			return _003C_003Ec__DisplayClass8_.package.contents.Select(_003C_003Ec__DisplayClass8_._003CRefresh_Coroutine_003Eb__2);
		}
	}

	[CompilerGenerated]
	private sealed class _003C_003Ec__DisplayClass8_1
	{
		public DLCPackageMetadata package;

		public _003C_003Ec__DisplayClass8_0 CS_0024_003C_003E8__locals1;

		public UnityAction _003C_003E9__3;

		public PurchaseUI.OnSelected _003C_003E9__4;

		public Func<bool> _003C_003E9__5;

		public Func<bool> _003C_003E9__6;

		internal PurchaseUI.Purchasable _003CRefresh_Coroutine_003Eb__2(DLCPackageMetadata.Content item)
		{
			return new PurchaseUI.Purchasable
			{
				nameKey = string.Format("m.dlc.{0}.contents.{1}", package.id.ToString().ToLowerInvariant(), item.id),
				descKey = string.Format("m.dlc.{0}.contents.{1}.desc", package.id.ToString().ToLowerInvariant(), item.id),
				icon = item.image,
				mainImg = item.imageLarge,
				onPurchase = (_003C_003E9__3 ?? (_003C_003E9__3 = _003CRefresh_Coroutine_003Eb__3)),
				onSelected = (_003C_003E9__4 ?? (_003C_003E9__4 = _003CRefresh_Coroutine_003Eb__4)),
				unlocked = (_003C_003E9__5 ?? (_003C_003E9__5 = _003CRefresh_Coroutine_003Eb__5)),
				avail = (_003C_003E9__6 ?? (_003C_003E9__6 = _003CRefresh_Coroutine_003Eb__6)),
				btnOverride = (CS_0024_003C_003E8__locals1.director.HasReached(package.id, State.INSTALLED) ? "b.dlc.installed" : "b.dlc.view_in_store")
			};
		}

		internal void _003CRefresh_Coroutine_003Eb__3()
		{
			CS_0024_003C_003E8__locals1.director.ShowPackageInStore(package.id);
		}

		internal void _003CRefresh_Coroutine_003Eb__4(PurchaseUI.Purchasable p)
		{
			CS_0024_003C_003E8__locals1._003C_003E4__this.OnPackageSelected(package);
		}

		internal bool _003CRefresh_Coroutine_003Eb__5()
		{
			return CS_0024_003C_003E8__locals1.director.HasReached(package.id, State.AVAILABLE);
		}

		internal bool _003CRefresh_Coroutine_003Eb__6()
		{
			return !CS_0024_003C_003E8__locals1.director.HasReached(package.id, State.INSTALLED);
		}
	}

	[Tooltip("Icon displayed at the top of the modal (see PurchaseUI).")]
	public Sprite icon;

	[Tooltip("Prefab showing the 'included in...' text/icon.")]
	public DLCManageUI_IncludedInPackage includedInPackagePrefab;

	private DLCManageUI_IncludedInPackage includedInPackage;

	private const float MIN_LOADING_TIME = 0.25f;

	private PurchaseUI purchaseUI;

	public static bool IsEnabled()
	{
		_003C_003Ec__DisplayClass5_0 _003C_003Ec__DisplayClass5_ = new _003C_003Ec__DisplayClass5_0();
		_003C_003Ec__DisplayClass5_.director = SRSingleton<GameContext>.Instance.DLCDirector;
		if (Levels.isSpecial() || SRSingleton<SceneContext>.Instance.GameModeConfig.GetModeSettings().enableDLC)
		{
			return _003C_003Ec__DisplayClass5_.director.GetSupportedPackages().Any(_003C_003Ec__DisplayClass5_._003CIsEnabled_003Eb__0);
		}
		return false;
	}

	public override void Awake()
	{
		base.Awake();
		includedInPackage = UnityEngine.Object.Instantiate(includedInPackagePrefab.gameObject).GetComponent<DLCManageUI_IncludedInPackage>();
		purchaseUI = SRSingleton<GameContext>.Instance.UITemplates.CreatePurchaseUI(icon, "t.dlc", new PurchaseUI.Purchasable[0], true, Close).GetComponent<PurchaseUI>();
		includedInPackage.transform.SetParent(purchaseUI.customizationPanel.transform, false);
		purchaseUI.transform.SetParent(base.transform, false);
		purchaseUI.Resize(450f, 600f);
		purchaseUI.ReselectOnReturnFromPedia();
		statusArea = purchaseUI.statusArea;
		StartCoroutine(Refresh_Coroutine());
	}

	public void OnApplicationFocus(bool hasFocus)
	{
		if (hasFocus)
		{
			StartCoroutine(Refresh_Coroutine());
		}
	}

	private IEnumerator Refresh_Coroutine()
	{
		_003C_003Ec__DisplayClass8_0 _003C_003Ec__DisplayClass8_ = new _003C_003Ec__DisplayClass8_0();
		_003C_003Ec__DisplayClass8_._003C_003E4__this = this;
		_003C_003Ec__DisplayClass8_.minLoadingTime = Time.unscaledTime + 0.25f;
		purchaseUI.SetActivePanels(PurchaseUI.Panel.LOADING);
		purchaseUI.ClearButtons();
		_003C_003Ec__DisplayClass8_.director = SRSingleton<GameContext>.Instance.DLCDirector;
		yield return _003C_003Ec__DisplayClass8_.director.RegisterPackagesAsync();
		yield return new WaitUntil(_003C_003Ec__DisplayClass8_._003CRefresh_Coroutine_003Eb__0);
		PurchaseUI.Purchasable[] array = _003C_003Ec__DisplayClass8_.director.LoadPackageMetadatas().SelectMany(_003C_003Ec__DisplayClass8_._003C_003E9__1 ?? (_003C_003Ec__DisplayClass8_._003C_003E9__1 = _003C_003Ec__DisplayClass8_._003CRefresh_Coroutine_003Eb__1)).ToArray();
		foreach (PurchaseUI.Purchasable purchasable in array)
		{
			purchaseUI.AddButton(purchasable, false);
		}
		purchaseUI.SetActivePanels(PurchaseUI.Panel.DEFAULT);
		purchaseUI.SelectFirst();
	}

	public override void OnBundlesAvailable(MessageDirector msg)
	{
		base.OnBundlesAvailable(msg);
		if (purchaseUI != null)
		{
			purchaseUI.Rebuild(false);
		}
	}

	private void OnPackageSelected(DLCPackageMetadata package)
	{
		if (package.contents.Count > 1)
		{
			string text = SRSingleton<GameContext>.Instance.MessageDirector.GetBundle("pedia").Get(string.Format("m.dlc.{0}", package.id.ToString().ToLowerInvariant()));
			includedInPackage.text.text = uiBundle.Get("m.dlc.included_in", text);
			includedInPackage.icon.sprite = package.icon;
			includedInPackage.gameObject.SetActive(true);
		}
		else
		{
			includedInPackage.gameObject.SetActive(false);
		}
	}
}
