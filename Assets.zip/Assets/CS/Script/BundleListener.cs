public interface BundleListener
{
	void InitBundles();
}
