using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using MonomiPark.SlimeRancher.Regions;
using UnityEngine;

public class DynamicObjectContainer : SRSingleton<DynamicObjectContainer>
{
	[Serializable]
	[CompilerGenerated]
	private sealed class _003C_003Ec
	{
		public static readonly _003C_003Ec _003C_003E9 = new _003C_003Ec();

		public static Action<Destroyer.Metadata> _003C_003E9__0_0;

		internal void _003CAwake_003Eb__0_0(Destroyer.Metadata metadata)
		{
			InvalidOperationException ex = new InvalidOperationException(string.Format("DynamicObjectContainer is being destroyed. [metadata={0}]", metadata));
			Log.Error(ex.ToString());
			SentrySdk.CaptureMessage("DynamicObjectContainer is being destroyed!");
			throw ex;
		}
	}

	public override void Awake()
	{
		base.Awake();
		Destroyer.Monitor(base.gameObject, _003C_003Ec._003C_003E9__0_0 ?? (_003C_003Ec._003C_003E9__0_0 = _003C_003Ec._003C_003E9._003CAwake_003Eb__0_0));
	}

	private List<GameObject> GetChildren()
	{
		List<GameObject> list = new List<GameObject>();
		Identifiable[] componentsInChildren = GetComponentsInChildren<Identifiable>();
		foreach (Identifiable identifiable in componentsInChildren)
		{
			list.Add(identifiable.gameObject);
		}
		return list;
	}

	public void RegisterDynamicObjectActors()
	{
		List<GameObject> children = GetChildren();
		foreach (GameObject item in children)
		{
			SRSingleton<SceneContext>.Instance.GameModel.RegisterStartingActor(item, RegionRegistry.RegionSetId.HOME);
		}
		foreach (GameObject item2 in children)
		{
			item2.transform.SetParent(null);
		}
	}

	public void DestroyDynamicObjectActors()
	{
		foreach (GameObject child in GetChildren())
		{
			Destroyer.Destroy(child, 0f, "DynamicObjectContainer.Awake", true);
		}
	}
}
