using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;

public class DroneProgramDestinationSilo : DroneProgramDestinationSiloStorage<DroneNetwork.StorageMetadata>
{
	[CompilerGenerated]
	private sealed class _003C_003Ec__DisplayClass0_0
	{
		public Identifiable.Id id;

		public bool overflow;

		internal bool _003CGetDestinations_003Eb__1(DroneNetwork.StorageMetadata s)
		{
			return s.storage.CanAccept(id, s.index, overflow);
		}
	}

	[Serializable]
	[CompilerGenerated]
	private sealed class _003C_003Ec
	{
		public static readonly _003C_003Ec _003C_003E9 = new _003C_003Ec();

		public static Func<DroneNetwork.LandPlotMetadata, IEnumerable<DroneNetwork.StorageMetadata>> _003C_003E9__0_0;

		public static Func<DroneNetwork.StorageMetadata, int> _003C_003E9__1_0;

		internal IEnumerable<DroneNetwork.StorageMetadata> _003CGetDestinations_003Eb__0_0(DroneNetwork.LandPlotMetadata m)
		{
			return m.silos;
		}

		internal int _003CPrioritize_003Eb__1_0(DroneNetwork.StorageMetadata s)
		{
			return s.count;
		}
	}

	protected override IEnumerable<DroneNetwork.StorageMetadata> GetDestinations(Identifiable.Id id, bool overflow)
	{
		_003C_003Ec__DisplayClass0_0 _003C_003Ec__DisplayClass0_ = new _003C_003Ec__DisplayClass0_0();
		_003C_003Ec__DisplayClass0_.id = id;
		_003C_003Ec__DisplayClass0_.overflow = overflow;
		return drone.network.Plots.SelectMany(_003C_003Ec._003C_003E9__0_0 ?? (_003C_003Ec._003C_003E9__0_0 = _003C_003Ec._003C_003E9._003CGetDestinations_003Eb__0_0)).Where(_003C_003Ec__DisplayClass0_._003CGetDestinations_003Eb__1);
	}

	protected override IEnumerable<DroneNetwork.StorageMetadata> Prioritize(IEnumerable<DroneNetwork.StorageMetadata> destinations)
	{
		return destinations.OrderByDescending(_003C_003Ec._003C_003E9__1_0 ?? (_003C_003Ec._003C_003E9__1_0 = _003C_003Ec._003C_003E9._003CPrioritize_003Eb__1_0));
	}
}
