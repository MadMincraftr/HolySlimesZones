public interface GadgetInteractor
{
	void OnInteract();

	bool CanInteract();
}
