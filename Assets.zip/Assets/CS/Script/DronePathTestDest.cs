using UnityEngine;

public class DronePathTestDest : MonoBehaviour
{
}
