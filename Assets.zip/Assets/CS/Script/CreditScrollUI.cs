using UnityEngine;

public class CreditScrollUI : MonoBehaviour
{
	public void OnEnable()
	{
	}

	public void OnDisable()
	{
		bool flag = SRSingleton<GameContext>.Instance != null;
	}
}
