using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using Assets.Script.Util.Extensions;
using MonomiPark.SlimeRancher.DataModel;
using MonomiPark.SlimeRancher.Regions;
using UnityEngine;

[RequireComponent(typeof(Region))]
public class GlitchImpostoDirector : SRBehaviour, GlitchImpostoDirectorModel.Participant
{
	[CompilerGenerated]
	private sealed class _003C_003Ec__DisplayClass14_0
	{
		public GlitchImposto imposto;

		internal bool _003CDeregister_003Eb__0(GlitchImposto d)
		{
			return d == imposto;
		}
	}

	[Serializable]
	[CompilerGenerated]
	private sealed class _003C_003Ec
	{
		public static readonly _003C_003Ec _003C_003E9 = new _003C_003Ec();

		public static Action<GlitchImposto> _003C_003E9__15_0;

		public static Func<GlitchImposto, bool> _003C_003E9__15_1;

		public static Func<GlitchImposto, float> _003C_003E9__15_2;

		internal void _003CResetImpostos_003Eb__15_0(GlitchImposto imposto)
		{
			imposto.Deactivate();
		}

		internal bool _003CResetImpostos_003Eb__15_1(GlitchImposto imposto)
		{
			return imposto.IsReady();
		}

		internal float _003CResetImpostos_003Eb__15_2(GlitchImposto imposto)
		{
			return imposto.weight;
		}
	}

	[Tooltip("Random range of number of impostos to enable this cell is unhibernated.")]
	public Vector2 availableCount;

	private GlitchImpostoDirectorModel model;

	private GlitchMetadata metadata;

	private TimeDirector timeDirector;

	private Region region;

	private List<GlitchImposto> registered = new List<GlitchImposto>();

	public string id
	{
		get
		{
			return base.name;
		}
	}

	public void Awake()
	{
		metadata = SRSingleton<SceneContext>.Instance.MetadataDirector.Glitch;
		timeDirector = SRSingleton<SceneContext>.Instance.TimeDirector;
		SRSingleton<SceneContext>.Instance.GameModel.Glitch.Register(this);
	}

	public void Start()
	{
		region = GetComponent<Region>();
		region.onHibernationStateChanged += OnHibernationStateChanged;
	}

	public void InitModel(GlitchImpostoDirectorModel model)
	{
		model.hibernationTime = null;
	}

	public void SetModel(GlitchImpostoDirectorModel model)
	{
		this.model = model;
	}

	public void OnDestroy()
	{
		if (SRSingleton<SceneContext>.Instance != null)
		{
			SRSingleton<SceneContext>.Instance.GameModel.Glitch.Unregister(this);
		}
		if (region != null)
		{
			region.onHibernationStateChanged -= OnHibernationStateChanged;
			region = null;
		}
	}

	public void Register(GlitchImposto imposto)
	{
		registered.Add(imposto);
	}

	public bool Deregister(GlitchImposto imposto)
	{
		_003C_003Ec__DisplayClass14_0 _003C_003Ec__DisplayClass14_ = new _003C_003Ec__DisplayClass14_0();
		_003C_003Ec__DisplayClass14_.imposto = imposto;
		return registered.RemoveAll(_003C_003Ec__DisplayClass14_._003CDeregister_003Eb__0) >= 1;
	}

	public void ResetImpostos()
	{
		registered.ForEach(_003C_003Ec._003C_003E9__15_0 ?? (_003C_003Ec._003C_003E9__15_0 = _003C_003Ec._003C_003E9._003CResetImpostos_003Eb__15_0));
		foreach (GlitchImposto item in Randoms.SHARED.Pick(registered.Where(_003C_003Ec._003C_003E9__15_1 ?? (_003C_003Ec._003C_003E9__15_1 = _003C_003Ec._003C_003E9._003CResetImpostos_003Eb__15_1)).ToList(), Mathf.FloorToInt(availableCount.GetRandom()), _003C_003Ec._003C_003E9__15_2 ?? (_003C_003Ec._003C_003E9__15_2 = _003C_003Ec._003C_003E9._003CResetImpostos_003Eb__15_2)))
		{
			item.Activate();
		}
	}

	private void OnHibernationStateChanged(bool hibernating)
	{
		if (hibernating)
		{
			if (!model.hibernationTime.HasValue)
			{
				model.hibernationTime = timeDirector.WorldTime();
			}
		}
		else if (!model.hibernationTime.HasValue || timeDirector.TimeSince(model.hibernationTime.Value) >= (double)(metadata.impostoMinHibernationTime * 3600f))
		{
			ResetImpostos();
		}
	}
}
