using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using UnityEngine;

public class GlitchBreadcrumbNetwork : PathingNetwork
{
	[Serializable]
	[CompilerGenerated]
	private sealed class _003C_003Ec
	{
		public static readonly _003C_003Ec _003C_003E9 = new _003C_003Ec();

		public static Action<GlitchBreadcrumbNetworkNode> _003C_003E9__9_0;

		internal void _003COnBreadcrumbsChanged_003Eb__9_0(GlitchBreadcrumbNetworkNode b)
		{
			b.Deactivate();
		}
	}

	private GlitchBreadcrumbNetworkPather pather = new GlitchBreadcrumbNetworkPather();

	private List<GlitchBreadcrumbNetworkNode> activeBreadcrumbs;

	private GlitchTeleportDestination exitDestination;

	public override Pather Pather
	{
		get
		{
			return pather;
		}
	}

	public void Update()
	{
		List<PathingNetworkNode> list = null;
		if (exitDestination != null && exitDestination.IsLinkActive())
		{
			Vector3 position = SRSingleton<SceneContext>.Instance.Player.transform.position;
			Vector3 position2 = exitDestination.transform.position;
			list = Pather.GeneratePathNodes(position, position2);
		}
		if (list == null != (activeBreadcrumbs == null) || (list != null && list[0] != activeBreadcrumbs[0]))
		{
			OnBreadcrumbsChanged(list);
		}
	}

	public void OnDisable()
	{
		OnBreadcrumbsChanged(null);
	}

	public void OnGlitchRegionLoaded()
	{
		foreach (GlitchTeleportDestination destination in SRSingleton<GlitchRegionHelper>.Instance.destinations)
		{
			destination.onExitTeleporterBecameActive += OnExitTeleporterBecameActive;
		}
	}

	private void OnExitTeleporterBecameActive(GlitchTeleportDestination destination)
	{
		exitDestination = destination;
	}

	private void OnBreadcrumbsChanged(List<PathingNetworkNode> breadcrumbs)
	{
		if (activeBreadcrumbs != null)
		{
			activeBreadcrumbs.ForEach(_003C_003Ec._003C_003E9__9_0 ?? (_003C_003Ec._003C_003E9__9_0 = _003C_003Ec._003C_003E9._003COnBreadcrumbsChanged_003Eb__9_0));
			activeBreadcrumbs = null;
		}
		if (breadcrumbs != null && breadcrumbs.Any())
		{
			activeBreadcrumbs = breadcrumbs.Cast<GlitchBreadcrumbNetworkNode>().ToList();
			for (int i = 0; i < activeBreadcrumbs.Count; i++)
			{
				activeBreadcrumbs[i].Activate((i + 1 >= activeBreadcrumbs.Count) ? exitDestination.transform.position : activeBreadcrumbs[i + 1].position);
			}
		}
	}
}
