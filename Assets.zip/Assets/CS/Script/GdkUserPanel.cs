using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class GdkUserPanel : SRBehaviour
{
	public TMP_Text gamerNameText;

	public TMP_Text keyText;

	public GameObject switchUserBox;

	public Image switchUserIcon;

	private InputDirector inputDirector;
}
