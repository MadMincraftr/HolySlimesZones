using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;

[CompilerGenerated]
internal sealed class _003C_003Ef__AnonymousType3<_003Cname_003Ej__TPar, _003Cposition_003Ej__TPar, _003Cvelocity_003Ej__TPar, _003CangularVelocity_003Ej__TPar>
{
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private readonly _003Cname_003Ej__TPar _003Cname_003Ei__Field;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private readonly _003Cposition_003Ej__TPar _003Cposition_003Ei__Field;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private readonly _003Cvelocity_003Ej__TPar _003Cvelocity_003Ei__Field;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private readonly _003CangularVelocity_003Ej__TPar _003CangularVelocity_003Ei__Field;

	public _003Cname_003Ej__TPar name
	{
		get
		{
			return _003Cname_003Ei__Field;
		}
	}

	public _003Cposition_003Ej__TPar position
	{
		get
		{
			return _003Cposition_003Ei__Field;
		}
	}

	public _003Cvelocity_003Ej__TPar velocity
	{
		get
		{
			return _003Cvelocity_003Ei__Field;
		}
	}

	public _003CangularVelocity_003Ej__TPar angularVelocity
	{
		get
		{
			return _003CangularVelocity_003Ei__Field;
		}
	}

	[DebuggerHidden]
	public _003C_003Ef__AnonymousType3(_003Cname_003Ej__TPar name, _003Cposition_003Ej__TPar position, _003Cvelocity_003Ej__TPar velocity, _003CangularVelocity_003Ej__TPar angularVelocity)
	{
		_003Cname_003Ei__Field = name;
		_003Cposition_003Ei__Field = position;
		_003Cvelocity_003Ei__Field = velocity;
		_003CangularVelocity_003Ei__Field = angularVelocity;
	}

	[DebuggerHidden]
	public override bool Equals(object value)
	{
		_003C_003Ef__AnonymousType3<_003Cname_003Ej__TPar, _003Cposition_003Ej__TPar, _003Cvelocity_003Ej__TPar, _003CangularVelocity_003Ej__TPar> anon = value as _003C_003Ef__AnonymousType3<_003Cname_003Ej__TPar, _003Cposition_003Ej__TPar, _003Cvelocity_003Ej__TPar, _003CangularVelocity_003Ej__TPar>;
		if (anon != null && EqualityComparer<_003Cname_003Ej__TPar>.Default.Equals(_003Cname_003Ei__Field, anon._003Cname_003Ei__Field) && EqualityComparer<_003Cposition_003Ej__TPar>.Default.Equals(_003Cposition_003Ei__Field, anon._003Cposition_003Ei__Field) && EqualityComparer<_003Cvelocity_003Ej__TPar>.Default.Equals(_003Cvelocity_003Ei__Field, anon._003Cvelocity_003Ei__Field))
		{
			return EqualityComparer<_003CangularVelocity_003Ej__TPar>.Default.Equals(_003CangularVelocity_003Ei__Field, anon._003CangularVelocity_003Ei__Field);
		}
		return false;
	}

	[DebuggerHidden]
	public override string ToString()
	{
		object[] array = new object[4];
		_003Cname_003Ej__TPar val = _003Cname_003Ei__Field;
		ref _003Cname_003Ej__TPar reference = ref val;
		_003Cname_003Ej__TPar val2 = default(_003Cname_003Ej__TPar);
		object obj;
		if (val2 == null)
		{
			val2 = reference;
			reference = ref val2;
			if (val2 == null)
			{
				obj = null;
				goto IL_0046;
			}
		}
		obj = reference.ToString();
		goto IL_0046;
		IL_00ff:
		object obj2;
		array[3] = obj2;
		return string.Format(null, "{{ name = {0}, position = {1}, velocity = {2}, angularVelocity = {3} }}", array);
		IL_0081:
		object obj3;
		array[1] = obj3;
		_003Cvelocity_003Ej__TPar val3 = _003Cvelocity_003Ei__Field;
		ref _003Cvelocity_003Ej__TPar reference2 = ref val3;
		_003Cvelocity_003Ej__TPar val4 = default(_003Cvelocity_003Ej__TPar);
		object obj4;
		if (val4 == null)
		{
			val4 = reference2;
			reference2 = ref val4;
			if (val4 == null)
			{
				obj4 = null;
				goto IL_00c0;
			}
		}
		obj4 = reference2.ToString();
		goto IL_00c0;
		IL_00c0:
		array[2] = obj4;
		_003CangularVelocity_003Ej__TPar val5 = _003CangularVelocity_003Ei__Field;
		ref _003CangularVelocity_003Ej__TPar reference3 = ref val5;
		_003CangularVelocity_003Ej__TPar val6 = default(_003CangularVelocity_003Ej__TPar);
		if (val6 == null)
		{
			val6 = reference3;
			reference3 = ref val6;
			if (val6 == null)
			{
				obj2 = null;
				goto IL_00ff;
			}
		}
		obj2 = reference3.ToString();
		goto IL_00ff;
		IL_0046:
		array[0] = obj;
		_003Cposition_003Ej__TPar val7 = _003Cposition_003Ei__Field;
		ref _003Cposition_003Ej__TPar reference4 = ref val7;
		_003Cposition_003Ej__TPar val8 = default(_003Cposition_003Ej__TPar);
		if (val8 == null)
		{
			val8 = reference4;
			reference4 = ref val8;
			if (val8 == null)
			{
				obj3 = null;
				goto IL_0081;
			}
		}
		obj3 = reference4.ToString();
		goto IL_0081;
	}
}
