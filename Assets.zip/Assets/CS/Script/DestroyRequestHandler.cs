using UnityEngine;

public interface DestroyRequestHandler
{
	void OnDestroyRequest(GameObject obj);
}
