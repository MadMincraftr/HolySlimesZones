using System;
using System.Runtime.CompilerServices;
using UnityEngine;

public class GardenUI : LandPlotUI
{
	[Serializable]
	[CompilerGenerated]
	private sealed class _003C_003Ec
	{
		public static readonly _003C_003Ec _003C_003E9 = new _003C_003Ec();

		public static Func<bool> _003C_003E9__9_0;

		public static Func<bool> _003C_003E9__9_2;

		public static Func<bool> _003C_003E9__9_4;

		public static Func<bool> _003C_003E9__9_6;

		public static Func<bool> _003C_003E9__9_8;

		public static Func<bool> _003C_003E9__9_11;

		public static Func<bool> _003C_003E9__9_12;

		public static Func<bool> _003C_003E9__9_13;

		internal bool _003CCreatePurchaseUI_003Eb__9_0()
		{
			return true;
		}

		internal bool _003CCreatePurchaseUI_003Eb__9_2()
		{
			return true;
		}

		internal bool _003CCreatePurchaseUI_003Eb__9_4()
		{
			return true;
		}

		internal bool _003CCreatePurchaseUI_003Eb__9_6()
		{
			return SRSingleton<SceneContext>.Instance.ProgressDirector.GetProgress(ProgressDirector.ProgressType.OGDEN_REWARDS) >= 1;
		}

		internal bool _003CCreatePurchaseUI_003Eb__9_8()
		{
			return SRSingleton<SceneContext>.Instance.ProgressDirector.GetProgress(ProgressDirector.ProgressType.OGDEN_REWARDS) >= 2;
		}

		internal bool _003CCreatePurchaseUI_003Eb__9_11()
		{
			return true;
		}

		internal bool _003CCreatePurchaseUI_003Eb__9_12()
		{
			return true;
		}

		internal bool _003CCreatePurchaseUI_003Eb__9_13()
		{
			return true;
		}
	}

	public UpgradePurchaseItem soil;

	public UpgradePurchaseItem sprinkler;

	public UpgradePurchaseItem scareslime;

	public UpgradePurchaseItem miracleMix;

	public UpgradePurchaseItem deluxe;

	public PurchaseItem clearCrop;

	public PlotPurchaseItem demolish;

	public Sprite titleIcon;

	public GameObject plantButtonPanelObject;

	protected override GameObject CreatePurchaseUI()
	{
		PurchaseUI.Purchasable[] purchasables = new PurchaseUI.Purchasable[7]
		{
			new PurchaseUI.Purchasable("m.upgrade.name.garden.soil", soil.icon, soil.img, "m.upgrade.desc.garden.soil", soil.cost, PediaDirector.Id.GARDEN, UpgradeSoil, _003C_003Ec._003C_003E9__9_0 ?? (_003C_003Ec._003C_003E9__9_0 = _003C_003Ec._003C_003E9._003CCreatePurchaseUI_003Eb__9_0), _003CCreatePurchaseUI_003Eb__9_1),
			new PurchaseUI.Purchasable("m.upgrade.name.garden.sprinkler", sprinkler.icon, sprinkler.img, "m.upgrade.desc.garden.sprinkler", sprinkler.cost, PediaDirector.Id.GARDEN, UpgradeSprinkler, _003C_003Ec._003C_003E9__9_2 ?? (_003C_003Ec._003C_003E9__9_2 = _003C_003Ec._003C_003E9._003CCreatePurchaseUI_003Eb__9_2), _003CCreatePurchaseUI_003Eb__9_3),
			new PurchaseUI.Purchasable("m.upgrade.name.garden.scareslime", scareslime.icon, scareslime.img, "m.upgrade.desc.garden.scareslime", scareslime.cost, PediaDirector.Id.GARDEN, UpgradeScareslime, _003C_003Ec._003C_003E9__9_4 ?? (_003C_003Ec._003C_003E9__9_4 = _003C_003Ec._003C_003E9._003CCreatePurchaseUI_003Eb__9_4), _003CCreatePurchaseUI_003Eb__9_5),
			new PurchaseUI.Purchasable("m.upgrade.name.garden.miracle_mix", miracleMix.icon, miracleMix.img, "m.upgrade.desc.garden.miracle_mix", miracleMix.cost, PediaDirector.Id.GARDEN, UpgradeMiracleMix, _003C_003Ec._003C_003E9__9_6 ?? (_003C_003Ec._003C_003E9__9_6 = _003C_003Ec._003C_003E9._003CCreatePurchaseUI_003Eb__9_6), _003CCreatePurchaseUI_003Eb__9_7),
			new PurchaseUI.Purchasable("m.upgrade.name.garden.deluxe", deluxe.icon, deluxe.img, "m.upgrade.desc.garden.deluxe", deluxe.cost, PediaDirector.Id.GARDEN, UpgradeDeluxe, _003C_003Ec._003C_003E9__9_8 ?? (_003C_003Ec._003C_003E9__9_8 = _003C_003Ec._003C_003E9._003CCreatePurchaseUI_003Eb__9_8), _003CCreatePurchaseUI_003Eb__9_9),
			new PurchaseUI.Purchasable(MessageUtil.Qualify("ui", "b.clear_crop"), clearCrop.icon, clearCrop.img, MessageUtil.Qualify("ui", "m.desc.clear_crop"), clearCrop.cost, null, ClearCrop, _003CCreatePurchaseUI_003Eb__9_10, _003C_003Ec._003C_003E9__9_11 ?? (_003C_003Ec._003C_003E9__9_11 = _003C_003Ec._003C_003E9._003CCreatePurchaseUI_003Eb__9_11)),
			new PurchaseUI.Purchasable(MessageUtil.Qualify("ui", "l.demolish_plot"), demolish.icon, demolish.img, MessageUtil.Qualify("ui", "m.desc.demolish_plot"), demolish.cost, null, Demolish, _003C_003Ec._003C_003E9__9_12 ?? (_003C_003Ec._003C_003E9__9_12 = _003C_003Ec._003C_003E9._003CCreatePurchaseUI_003Eb__9_12), _003C_003Ec._003C_003E9__9_13 ?? (_003C_003Ec._003C_003E9__9_13 = _003C_003Ec._003C_003E9._003CCreatePurchaseUI_003Eb__9_13), "b.demolish")
		};
		return SRSingleton<GameContext>.Instance.UITemplates.CreatePurchaseUI(titleIcon, "t.garden", purchasables, false, Close);
	}

	public void UpgradeSoil()
	{
		Upgrade(LandPlot.Upgrade.SOIL, soil.cost);
	}

	public void UpgradeSprinkler()
	{
		Upgrade(LandPlot.Upgrade.SPRINKLER, sprinkler.cost);
	}

	public void UpgradeScareslime()
	{
		Upgrade(LandPlot.Upgrade.SCARESLIME, scareslime.cost);
	}

	public void UpgradeMiracleMix()
	{
		Upgrade(LandPlot.Upgrade.MIRACLE_MIX, miracleMix.cost);
	}

	public void UpgradeDeluxe()
	{
		Upgrade(LandPlot.Upgrade.DELUXE_GARDEN, deluxe.cost);
	}

	public void ClearCrop()
	{
		if (playerState.GetCurrency() >= clearCrop.cost)
		{
			playerState.SpendCurrency(clearCrop.cost);
			activator.DestroyAttached();
			PlayPurchaseCue();
			Close();
		}
		else
		{
			Error("e.insuf_coins");
		}
	}

	public void Demolish()
	{
		if (playerState.GetCurrency() >= demolish.cost)
		{
			playerState.SpendCurrency(demolish.cost);
			Replace(demolish.plotPrefab);
			PlayPurchaseCue();
		}
		else
		{
			Error("e.insuf_coins");
		}
	}

	[CompilerGenerated]
	private bool _003CCreatePurchaseUI_003Eb__9_1()
	{
		return !activator.HasUpgrade(LandPlot.Upgrade.SOIL);
	}

	[CompilerGenerated]
	private bool _003CCreatePurchaseUI_003Eb__9_3()
	{
		return !activator.HasUpgrade(LandPlot.Upgrade.SPRINKLER);
	}

	[CompilerGenerated]
	private bool _003CCreatePurchaseUI_003Eb__9_5()
	{
		return !activator.HasUpgrade(LandPlot.Upgrade.SCARESLIME);
	}

	[CompilerGenerated]
	private bool _003CCreatePurchaseUI_003Eb__9_7()
	{
		return !activator.HasUpgrade(LandPlot.Upgrade.MIRACLE_MIX);
	}

	[CompilerGenerated]
	private bool _003CCreatePurchaseUI_003Eb__9_9()
	{
		return !activator.HasUpgrade(LandPlot.Upgrade.DELUXE_GARDEN);
	}

	[CompilerGenerated]
	private bool _003CCreatePurchaseUI_003Eb__9_10()
	{
		return activator.HasAttached();
	}
}
