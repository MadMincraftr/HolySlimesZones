using System;
using System.Runtime.CompilerServices;

public class DroneAmmo : Ammo
{
	[Serializable]
	[CompilerGenerated]
	private sealed class _003C_003Ec
	{
		public static readonly _003C_003Ec _003C_003E9 = new _003C_003Ec();

		public static Func<Identifiable.Id, int, int> _003C_003E9__1_0;

		internal int _003C_002Ector_003Eb__1_0(Identifiable.Id id, int index)
		{
			return 50;
		}
	}

	public const int MAX_COUNT = 50;

	public DroneAmmo()
		: base(SRSingleton<SceneContext>.Instance.PlayerState.GetPotentialAmmo(), 1, 1, new Predicate<Identifiable.Id>[1], _003C_003Ec._003C_003E9__1_0 ?? (_003C_003Ec._003C_003E9__1_0 = _003C_003Ec._003C_003E9._003C_002Ector_003Eb__1_0))
	{
	}

	public Identifiable.Id Pop()
	{
		Identifiable.Id slotName = GetSlotName();
		Decrement(slotName);
		return slotName;
	}

	public Identifiable.Id GetSlotName()
	{
		return GetSlotName(0);
	}

	public bool MaybeAddToSlot(Identifiable.Id id)
	{
		return MaybeAddToSpecificSlot(id, null, 0);
	}

	public new bool IsEmpty()
	{
		return GetSlotCount() <= 0;
	}

	public bool IsFull()
	{
		return GetSlotCount() >= GetSlotMaxCount();
	}

	public int GetSlotCount()
	{
		return GetSlotCount(0);
	}

	public int GetSlotMaxCount()
	{
		return GetSlotMaxCount(0);
	}

	public new bool CouldAddToSlot(Identifiable.Id id)
	{
		return CouldAddToSlot(id, 0, false);
	}

	public bool Any()
	{
		return GetSlotCount() > 0;
	}

	public bool None()
	{
		return GetSlotCount() <= 0;
	}
}
