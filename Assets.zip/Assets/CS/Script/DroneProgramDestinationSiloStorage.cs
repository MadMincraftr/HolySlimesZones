using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using UnityEngine;

public abstract class DroneProgramDestinationSiloStorage<T> : DroneProgramDestination<T> where T : DroneNetwork.StorageMetadata
{
	[CompilerGenerated]
	private sealed class _003C_003Ec__DisplayClass1_0
	{
		public Identifiable.Id id;

		internal int _003CGetAvailableSpace_003Eb__0(int accum, DroneNetwork.StorageMetadata d)
		{
			return accum + d.GetAvailableSpace(id);
		}
	}

	private double time;

	private CatcherOrientation orientation;

	public override void Deselected()
	{
		base.Deselected();
		if (orientation != null)
		{
			orientation.Dispose();
			orientation = null;
		}
	}

	public override int GetAvailableSpace(Identifiable.Id id)
	{
		_003C_003Ec__DisplayClass1_0 _003C_003Ec__DisplayClass1_ = new _003C_003Ec__DisplayClass1_0();
		_003C_003Ec__DisplayClass1_.id = id;
		return GetDestinations(_003C_003Ec__DisplayClass1_.id, false).Cast<DroneNetwork.StorageMetadata>().Aggregate(0, _003C_003Ec__DisplayClass1_._003CGetAvailableSpace_003Eb__0);
	}

	public override bool HasAvailableSpace(Identifiable.Id id)
	{
		return GetDestinations(id, false).Any();
	}

	protected override bool CanCancel()
	{
		if (!base.CanCancel())
		{
			return destination.CanCancel();
		}
		return true;
	}

	protected override IEnumerable<Orientation> GetTargetOrientations()
	{
		orientation = GetTargetOrientation_Catcher(destination.catcher.gameObject);
		yield return orientation.orientation;
	}

	protected override Vector3 GetTargetPosition()
	{
		return destination.catcher.transform.position;
	}

	protected override bool OnAction_Deposit(bool overflow)
	{
		if (timeDirector.HasReached(time))
		{
			Identifiable.Id slotName = drone.ammo.GetSlotName();
			if (destination.Increment(slotName, overflow))
			{
				drone.ammo.Decrement(slotName);
				time = timeDirector.HoursFromNow(0.0016666668f);
				if (!overflow)
				{
					return destination.IsFull();
				}
				return false;
			}
			return true;
		}
		return false;
	}

	public override FastForward_Response FastForward(Identifiable.Id id, bool overflow, double endTime, int maxFastForward)
	{
		DroneNetwork.StorageMetadata storageMetadata = Prioritize(GetDestinations(id, overflow)).First();
		maxFastForward = (overflow ? maxFastForward : Mathf.Min(maxFastForward, storageMetadata.GetAvailableSpace(id)));
		storageMetadata.Increment(id, overflow, maxFastForward);
		return new FastForward_Response
		{
			deposits = maxFastForward
		};
	}
}
