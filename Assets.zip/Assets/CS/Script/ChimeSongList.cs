public class ChimeSongList : ListAsset<EchoNoteClusterMetadata>
{
}
