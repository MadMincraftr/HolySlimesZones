public class GameCoreXboxInputEventManager
{
	public delegate void ControllerDisconnected();

	public ControllerDisconnected OnControllerDisconnected;
}
