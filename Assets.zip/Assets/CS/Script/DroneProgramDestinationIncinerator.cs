using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using UnityEngine;

public class DroneProgramDestinationIncinerator : DroneProgramDestination<Incinerate>
{
	private class Comparer : SRComparer<Incinerate>
	{
	}

	[Serializable]
	[CompilerGenerated]
	private sealed class _003C_003Ec
	{
		public static readonly _003C_003Ec _003C_003E9 = new _003C_003Ec();

		public static Func<int, Incinerate, int> _003C_003E9__0_0;

		public static Func<Incinerate, bool> _003C_003E9__1_0;

		public static Func<DroneNetwork.LandPlotMetadata, IEnumerable<Incinerate>> _003C_003E9__2_0;

		public static Func<Incinerate, bool> _003C_003E9__2_1;

		public static Func<Incinerate, Incinerate> _003C_003E9__4_0;

		public static Func<Incinerate, int> _003C_003E9__4_1;

		internal int _003CGetAvailableSpace_003Eb__0_0(int agg, Incinerate i)
		{
			return agg + i.GetAshSpace();
		}

		internal bool _003CHasAvailableSpace_003Eb__1_0(Incinerate i)
		{
			return i.GetAshSpace() > 0;
		}

		internal IEnumerable<Incinerate> _003CGetDestinations_003Eb__2_0(DroneNetwork.LandPlotMetadata i)
		{
			return i.incinerators;
		}

		internal bool _003CGetDestinations_003Eb__2_1(Incinerate i)
		{
			return i.GetAshSpace() > 0;
		}

		internal Incinerate _003CPrioritize_003Eb__4_0(Incinerate d)
		{
			return d;
		}

		internal int _003CPrioritize_003Eb__4_1(Incinerate i)
		{
			return i.GetAshSpace();
		}
	}

	private double time;

	private int dropCount;

	public override int GetAvailableSpace(Identifiable.Id id)
	{
		return GetDestinations(id, false).Aggregate(0, _003C_003Ec._003C_003E9__0_0 ?? (_003C_003Ec._003C_003E9__0_0 = _003C_003Ec._003C_003E9._003CGetAvailableSpace_003Eb__0_0));
	}

	public override bool HasAvailableSpace(Identifiable.Id id)
	{
		return GetDestinations(id, false).Any(_003C_003Ec._003C_003E9__1_0 ?? (_003C_003Ec._003C_003E9__1_0 = _003C_003Ec._003C_003E9._003CHasAvailableSpace_003Eb__1_0));
	}

	protected override IEnumerable<Incinerate> GetDestinations(Identifiable.Id id, bool overflow)
	{
		return drone.network.Plots.SelectMany(_003C_003Ec._003C_003E9__2_0 ?? (_003C_003Ec._003C_003E9__2_0 = _003C_003Ec._003C_003E9._003CGetDestinations_003Eb__2_0)).Where(_003C_003Ec._003C_003E9__2_1 ?? (_003C_003Ec._003C_003E9__2_1 = _003C_003Ec._003C_003E9._003CGetDestinations_003Eb__2_1));
	}

	protected override IEnumerable<Incinerate> Prioritize(IEnumerable<Incinerate> destinations)
	{
		return destinations.OrderBy(_003C_003Ec._003C_003E9__4_0 ?? (_003C_003Ec._003C_003E9__4_0 = _003C_003Ec._003C_003E9._003CPrioritize_003Eb__4_0), new Comparer().OrderByDescending(_003C_003Ec._003C_003E9__4_1 ?? (_003C_003Ec._003C_003E9__4_1 = _003C_003Ec._003C_003E9._003CPrioritize_003Eb__4_1)).OrderBy<float>(_003CPrioritize_003Eb__4_2));
	}

	protected override IEnumerable<Orientation> GetTargetOrientations()
	{
		return GetTargetOrientations_Gather(destination.gameObject, new GatherConfig
		{
			fallbackOffset = Vector3.forward,
			distanceHorizontal = 2.5f
		});
	}

	protected override Vector3 GetTargetPosition()
	{
		return destination.transform.position;
	}

	protected override void OnFirstAction()
	{
		base.OnFirstAction();
		dropCount = destination.GetAshSpace();
	}

	protected override bool OnAction_Deposit(bool overflow)
	{
		if ((dropCount > 0 || overflow) && timeDirector.HasReached(time))
		{
			Identifiable.Id slotName = drone.ammo.GetSlotName();
			time = timeDirector.HoursFromNow(0.0016666668f);
			drone.ammo.Decrement(slotName);
			destination.ProcessIncinerateResults(slotName, 1, destination.transform.position + (drone.transform.position - destination.transform.position).normalized * PhysicsUtil.RadiusOfObject(destination.gameObject) * 0.25f, Quaternion.identity);
			dropCount--;
		}
		if (!overflow)
		{
			return dropCount <= 0;
		}
		return false;
	}

	public override FastForward_Response FastForward(Identifiable.Id id, bool overflow, double endTime, int maxFastForward)
	{
		Incinerate incinerate = Prioritize(GetDestinations(id, overflow)).First();
		maxFastForward = (overflow ? maxFastForward : Mathf.Min(maxFastForward, incinerate.GetAshSpace()));
		incinerate.ProcessIncinerateResults(id, maxFastForward);
		return new FastForward_Response
		{
			deposits = maxFastForward
		};
	}

	[CompilerGenerated]
	private float _003CPrioritize_003Eb__4_2(Incinerate i)
	{
		return (i.transform.position - drone.transform.position).sqrMagnitude;
	}
}
