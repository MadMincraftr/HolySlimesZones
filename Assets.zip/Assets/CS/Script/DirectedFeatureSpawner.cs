public class DirectedFeatureSpawner : SRBehaviour
{
}
