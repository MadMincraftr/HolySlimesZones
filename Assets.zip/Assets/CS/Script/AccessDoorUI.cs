using System;
using System.Runtime.CompilerServices;
using UnityEngine;

public class AccessDoorUI : BaseUI
{
	[Serializable]
	[CompilerGenerated]
	private sealed class _003C_003Ec
	{
		public static readonly _003C_003Ec _003C_003E9 = new _003C_003Ec();

		public static Func<bool> _003C_003E9__5_0;

		public static Func<bool> _003C_003E9__5_1;

		internal bool _003CCreatePurchaseUI_003Eb__5_0()
		{
			return true;
		}

		internal bool _003CCreatePurchaseUI_003Eb__5_1()
		{
			return true;
		}
	}

	public Sprite titleIcon;

	private PlayerState playerState;

	private AccessDoor door;

	public override void Awake()
	{
		base.Awake();
		playerState = SRSingleton<SceneContext>.Instance.PlayerState;
	}

	public void SetAccessDoor(AccessDoor door)
	{
		this.door = door;
		if (door.CurrState == AccessDoor.State.LOCKED)
		{
			GameObject gameObject = CreatePurchaseUI();
			gameObject.transform.SetParent(base.transform, false);
			statusArea = gameObject.GetComponent<PurchaseUI>().statusArea;
		}
		else
		{
			Close();
			door.CurrState = AccessDoor.State.OPEN;
			SRSingleton<SceneContext>.Instance.PediaDirector.ShowPedia(door.lockedRegionId);
		}
	}

	protected GameObject CreatePurchaseUI()
	{
		PurchaseUI.Purchasable[] array = new PurchaseUI.Purchasable[1]
		{
			new PurchaseUI.Purchasable("t." + door.lockedRegionId.ToString().ToLowerInvariant(), door.doorPurchase.icon, door.doorPurchase.img, "m.intro." + door.lockedRegionId.ToString().ToLowerInvariant(), door.doorPurchase.cost, door.lockedRegionId, UnlockDoor, _003C_003Ec._003C_003E9__5_0 ?? (_003C_003Ec._003C_003E9__5_0 = _003C_003Ec._003C_003E9._003CCreatePurchaseUI_003Eb__5_0), _003C_003Ec._003C_003E9__5_1 ?? (_003C_003Ec._003C_003E9__5_1 = _003C_003Ec._003C_003E9._003CCreatePurchaseUI_003Eb__5_1))
		};
		GameObject obj = SRSingleton<GameContext>.Instance.UITemplates.CreatePurchaseUI(titleIcon, MessageUtil.Qualify("ui", "t.access_door"), array, false, Close);
		obj.GetComponent<PurchaseUI>().Select(array[0]);
		obj.GetComponent<PurchaseUI>().HideSelectionPanel();
		return obj;
	}

	public void UnlockDoor()
	{
		if (playerState.GetCurrency() >= door.doorPurchase.cost)
		{
			playerState.SpendCurrency(door.doorPurchase.cost);
			door.CurrState = AccessDoor.State.OPEN;
			if (door.linkedDoors != null)
			{
				AccessDoor[] linkedDoors = door.linkedDoors;
				foreach (AccessDoor accessDoor in linkedDoors)
				{
					if (accessDoor.CurrState == AccessDoor.State.LOCKED)
					{
						accessDoor.CurrState = AccessDoor.State.CLOSED;
					}
				}
			}
			Play(SRSingleton<GameContext>.Instance.UITemplates.purchaseExpansionCue);
			Close();
			SRSingleton<GameContext>.Instance.AutoSaveDirector.SaveAllNow();
		}
		else
		{
			PlayErrorCue();
			Error("e.insuf_coins");
		}
	}
}
