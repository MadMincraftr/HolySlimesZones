using System;
using UnityEngine;

[Serializable]
[CreateAssetMenu(menuName = "Slimes/Appearance Extras/Crystal Appearance")]
public class CrystalAppearance : ScriptableObject
{
	public GameObject largeCrystalPrefab;

	public GameObject smallCrystalPrefab;
}
