using System.Runtime.CompilerServices;
using UnityEngine;

public class GlitchTerminalAudio : SRBehaviour
{
	[CompilerGenerated]
	private sealed class _003C_003Ec__DisplayClass3_0
	{
		public GlitchTerminalAudio _003C_003E4__this;

		public GlitchMetadata metadata;

		internal void _003CAwake_003Eb__0(GlitchTerminalAnimatorState.Id id)
		{
			switch (id)
			{
			case GlitchTerminalAnimatorState.Id.SLEEP:
				_003C_003E4__this.onStateIdle.gameObject.SetActive(false);
				break;
			case GlitchTerminalAnimatorState.Id.BOOT_UP:
				SECTR_AudioSystem.Play(metadata.animationOnTerminalBootupCue, _003C_003E4__this.onStateBootup.position, false);
				break;
			case GlitchTerminalAnimatorState.Id.IDLE:
				_003C_003E4__this.onStateIdle.gameObject.SetActive(true);
				break;
			}
		}
	}

	[Tooltip("Reference to the parent animator.")]
	public GlitchTerminalAnimator animator;

	[Tooltip("Transform of where to play the BOOT_UP state sound.")]
	public Transform onStateBootup;

	[Tooltip("Sound component playing the IDLE state sound.")]
	public PlaySoundOnEnable onStateIdle;

	public void Awake()
	{
		_003C_003Ec__DisplayClass3_0 _003C_003Ec__DisplayClass3_ = new _003C_003Ec__DisplayClass3_0();
		_003C_003Ec__DisplayClass3_._003C_003E4__this = this;
		_003C_003Ec__DisplayClass3_.metadata = SRSingleton<SceneContext>.Instance.MetadataDirector.Glitch;
		onStateIdle.cue = _003C_003Ec__DisplayClass3_.metadata.animationOnTerminalIdleCue;
		onStateIdle.gameObject.SetActive(false);
		animator.onStateEnter += _003C_003Ec__DisplayClass3_._003CAwake_003Eb__0;
	}
}
