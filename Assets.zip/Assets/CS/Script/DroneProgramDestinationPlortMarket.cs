using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using UnityEngine;

public class DroneProgramDestinationPlortMarket : DroneProgramDestination<ScorePlort>
{
	private class Comparer : SRComparer<ScorePlort>
	{
	}

	[CompilerGenerated]
	private sealed class _003C_003Ec__DisplayClass3_0
	{
		public Identifiable.Id id;

		internal bool _003CGetDestinations_003Eb__0(ScorePlort s)
		{
			return s.CanDeposit(id, true);
		}
	}

	[Serializable]
	[CompilerGenerated]
	private sealed class _003C_003Ec
	{
		public static readonly _003C_003Ec _003C_003E9 = new _003C_003Ec();

		public static Func<ScorePlort, ScorePlort> _003C_003E9__12_0;

		internal ScorePlort _003CPrioritize_003Eb__12_0(ScorePlort d)
		{
			return d;
		}
	}

	private double time;

	private EconomyDirector economyDirector;

	private CatcherOrientation orientation;

	public override void Awake()
	{
		base.Awake();
		economyDirector = SRSingleton<SceneContext>.Instance.EconomyDirector;
	}

	public override void Deselected()
	{
		base.Deselected();
		if (orientation != null)
		{
			orientation.Dispose();
			orientation = null;
		}
	}

	public override int GetAvailableSpace(Identifiable.Id id)
	{
		if (!GetDestinations(id, false).Any())
		{
			return 0;
		}
		return MAX_AVAIL_TO_REPORT;
	}

	protected override IEnumerable<ScorePlort> GetDestinations(Identifiable.Id id, bool overflow)
	{
		_003C_003Ec__DisplayClass3_0 _003C_003Ec__DisplayClass3_ = new _003C_003Ec__DisplayClass3_0();
		_003C_003Ec__DisplayClass3_.id = id;
		return drone.network.Markets.Where(_003C_003Ec__DisplayClass3_._003CGetDestinations_003Eb__0);
	}

	protected override IEnumerable<Orientation> GetTargetOrientations()
	{
		orientation = GetTargetOrientation_Catcher(destination.gameObject);
		yield return orientation.orientation;
	}

	protected override Vector3 GetTargetPosition()
	{
		return destination.transform.position;
	}

	protected override bool OnAction_Deposit(bool overflow)
	{
		if (timeDirector.HasReached(time) && !economyDirector.IsMarketShutdown())
		{
			if (destination.Deposit(drone.ammo.GetSlotName(), 1, PlayerState.CoinsType.DRONE))
			{
				time = timeDirector.HoursFromNow(0.0016666668f);
				drone.ammo.Pop();
				return false;
			}
			return true;
		}
		return false;
	}

	public override FastForward_Response FastForward(Identifiable.Id id, bool overflow, double endTime, int maxFastForward)
	{
		ScorePlort.Deposit_Response deposit_Response = Prioritize(GetDestinations(id, overflow)).First().Deposit(id, maxFastForward, PlayerState.CoinsType.NONE, true);
		return new FastForward_Response
		{
			deposits = deposit_Response.deposits,
			currency = deposit_Response.currency
		};
	}

	protected override IEnumerable<ScorePlort> Prioritize(IEnumerable<ScorePlort> destinations)
	{
		return destinations.OrderBy(_003C_003Ec._003C_003E9__12_0 ?? (_003C_003Ec._003C_003E9__12_0 = _003C_003Ec._003C_003E9._003CPrioritize_003Eb__12_0), new Comparer().OrderBy<float>(_003CPrioritize_003Eb__12_1));
	}

	[CompilerGenerated]
	private float _003CPrioritize_003Eb__12_1(ScorePlort m)
	{
		return (m.transform.position - drone.transform.position).sqrMagnitude;
	}
}
