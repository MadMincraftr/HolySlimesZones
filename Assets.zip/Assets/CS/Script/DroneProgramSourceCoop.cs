using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using UnityEngine;

public class DroneProgramSourceCoop : DroneProgramSourceLandPlot
{
	[CompilerGenerated]
	private sealed class _003C_003Ec__DisplayClass1_0
	{
		public Predicate<Identifiable.Id> predicate;

		public TrackContainedIdentifiables container;

		public DroneProgramSourceCoop _003C_003E4__this;

		public DroneNetwork.LandPlotMetadata metadata;

		internal bool _003CGetSources_003Eb__0(KeyValuePair<Identifiable.Id, HashSet<Identifiable>> pair)
		{
			return predicate(pair.Key);
		}

		internal IEnumerable<Identifiable> _003CGetSources_003Eb__1(KeyValuePair<Identifiable.Id, HashSet<Identifiable>> pair)
		{
			return pair.Value.Skip(GetSkipCount(pair.Key, container));
		}

		internal bool _003CGetSources_003Eb__2(Identifiable s)
		{
			return _003C_003E4__this.SourcePredicate(metadata, s);
		}
	}

	private const int SKIP_ROOSTER = 2;

	private const int SKIP_HEN_RARE = 1;

	private const int SKIP_HEN = 4;

	protected override LandPlot.Id GetLandPlotID()
	{
		return LandPlot.Id.COOP;
	}

	protected override IEnumerable<Identifiable> GetSources(Predicate<Identifiable.Id> predicate, DroneNetwork.LandPlotMetadata metadata)
	{
		_003C_003Ec__DisplayClass1_0 _003C_003Ec__DisplayClass1_ = new _003C_003Ec__DisplayClass1_0();
		_003C_003Ec__DisplayClass1_.predicate = predicate;
		_003C_003Ec__DisplayClass1_._003C_003E4__this = this;
		_003C_003Ec__DisplayClass1_.metadata = metadata;
		_003C_003Ec__DisplayClass1_.container = _003C_003Ec__DisplayClass1_.metadata.trackers.First();
		return _003C_003Ec__DisplayClass1_.container.GetAllTracked().Where(_003C_003Ec__DisplayClass1_._003CGetSources_003Eb__0).SelectMany(_003C_003Ec__DisplayClass1_._003CGetSources_003Eb__1)
			.Where(_003C_003Ec__DisplayClass1_._003CGetSources_003Eb__2);
	}

	protected override int GetMaxPickup(Identifiable.Id id)
	{
		int b = int.MaxValue;
		if (currentLandPlot != null && Identifiable.MEAT_CLASS.Contains(id))
		{
			TrackContainedIdentifiables trackContainedIdentifiables = currentLandPlot.trackers.First();
			b = trackContainedIdentifiables.Count(id) - GetSkipCount(id, trackContainedIdentifiables);
		}
		return Mathf.Min(base.GetMaxPickup(id), b);
	}

	private static int GetSkipCount(Identifiable.Id id, TrackContainedIdentifiables container)
	{
		switch (id)
		{
		case Identifiable.Id.ROOSTER:
			return 2;
		case Identifiable.Id.PAINTED_HEN:
		{
			int num8 = Mathf.Min(1, container.Count(Identifiable.Id.BRIAR_HEN));
			int num9 = Mathf.Min(1, container.Count(Identifiable.Id.STONY_HEN));
			return Math.Max(1, 4 - num8 - num9);
		}
		case Identifiable.Id.BRIAR_HEN:
		{
			int num6 = container.Count(Identifiable.Id.PAINTED_HEN);
			int num7 = Mathf.Min(1, container.Count(Identifiable.Id.STONY_HEN));
			return Math.Max(1, 4 - num6 - num7);
		}
		case Identifiable.Id.STONY_HEN:
		{
			int num4 = container.Count(Identifiable.Id.PAINTED_HEN);
			int num5 = container.Count(Identifiable.Id.BRIAR_HEN);
			return Math.Max(1, 4 - num4 - num5);
		}
		case Identifiable.Id.HEN:
		{
			int num = container.Count(Identifiable.Id.PAINTED_HEN);
			int num2 = container.Count(Identifiable.Id.BRIAR_HEN);
			int num3 = container.Count(Identifiable.Id.STONY_HEN);
			return Mathf.Max(0, 4 - num - num2 - num3);
		}
		default:
			return 0;
		}
	}
}
