public interface DestroyAfterTimeListener
{
	void WillDestroyAfterTime();
}
