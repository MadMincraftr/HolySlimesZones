using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using UnityEngine;

public abstract class DroneProgramSource : DroneProgram
{
	[CompilerGenerated]
	private sealed class _003C_003Ec__DisplayClass10_0
	{
		public Identifiable.Id id;

		internal int _003CGetAvailableDestinationSpace_003Eb__0(int c, DroneProgramDestination d)
		{
			return c + d.GetAvailableSpace(id);
		}
	}

	[CompilerGenerated]
	private sealed class _003C_003Ec__DisplayClass11_0
	{
		public Identifiable.Id id;

		internal bool _003CHasAvailableDestinationSpace_003Eb__0(DroneProgramDestination d)
		{
			return d.HasAvailableSpace(id);
		}
	}

	[Serializable]
	[CompilerGenerated]
	private sealed class _003C_003Ec
	{
		public static readonly _003C_003Ec _003C_003E9 = new _003C_003Ec();

		public static Predicate<Identifiable.Id> _003C_003E9__13_0;

		internal bool _003C_002Ector_003Eb__13_0(Identifiable.Id id)
		{
			return false;
		}
	}

	public static HashSet<GameObject> BLACKLIST = new HashSet<GameObject>();

	public Predicate<Identifiable.Id> predicate = _003C_003Ec._003C_003E9__13_0 ?? (_003C_003Ec._003C_003E9__13_0 = _003C_003Ec._003C_003E9._003C_002Ector_003Eb__13_0);

	public IEnumerable<DroneProgramDestination> destinations = Enumerable.Empty<DroneProgramDestination>();

	protected override DroneAnimator.Id animation
	{
		get
		{
			return DroneAnimator.Id.GATHER;
		}
	}

	protected override DroneAnimatorState.Id animationStateBegin
	{
		get
		{
			return DroneAnimatorState.Id.GATHER_BEGIN;
		}
	}

	protected override DroneAnimatorState.Id animationStateEnd
	{
		get
		{
			return DroneAnimatorState.Id.GATHER_END;
		}
	}

	public abstract IEnumerable<DroneFastForwarder.GatherGroup> GetFastForwardGroups(double endTime);

	protected int GetAvailableDestinationSpace(Identifiable.Id id)
	{
		_003C_003Ec__DisplayClass10_0 _003C_003Ec__DisplayClass10_ = new _003C_003Ec__DisplayClass10_0();
		_003C_003Ec__DisplayClass10_.id = id;
		return destinations.Aggregate(0, _003C_003Ec__DisplayClass10_._003CGetAvailableDestinationSpace_003Eb__0);
	}

	protected bool HasAvailableDestinationSpace(Identifiable.Id id)
	{
		_003C_003Ec__DisplayClass11_0 _003C_003Ec__DisplayClass11_ = new _003C_003Ec__DisplayClass11_0();
		_003C_003Ec__DisplayClass11_.id = id;
		return destinations.Any(_003C_003Ec__DisplayClass11_._003CHasAvailableDestinationSpace_003Eb__0);
	}

	protected bool HasAvailableDestinationSpace(Identifiable.Id id, int minimum)
	{
		foreach (DroneProgramDestination destination in destinations)
		{
			int availableSpace = destination.GetAvailableSpace(id);
			if (availableSpace >= minimum)
			{
				return true;
			}
			minimum -= availableSpace;
		}
		return false;
	}
}
public abstract class DroneProgramSource<T> : DroneProgramSource where T : class
{
	protected T source;

	private GameObject sourceGameObject;

	public override bool Relevancy()
	{
		if (drone.ammo.IsFull())
		{
			return false;
		}
		if (!drone.station.battery.HasAny())
		{
			return false;
		}
		if (drone.ammo.Any() && !HasAvailableDestinationSpace(drone.ammo.GetSlotName(), drone.ammo.GetSlotCount() + 1))
		{
			return false;
		}
		foreach (T source in GetSources(_003CRelevancy_003Eb__0_0))
		{
			sourceGameObject = GetTargetGameObject(source);
			this.source = source;
			if (DroneProgramSource.BLACKLIST.Add(sourceGameObject) && GeneratePath(GetSubnetwork(), GetTargetOrientations(), GetTargetPosition()))
			{
				return true;
			}
		}
		sourceGameObject = null;
		this.source = null;
		return false;
	}

	public override void Selected()
	{
		base.Selected();
	}

	public override void Deselected()
	{
		base.Deselected();
		DroneProgramSource.BLACKLIST.Remove(sourceGameObject);
		sourceGameObject = null;
	}

	protected override void OnPathGenerationFailed()
	{
		base.OnPathGenerationFailed();
		if (sourceGameObject != null)
		{
			sourceGameObject.AddComponent<DroneProgramSource_PathGenerationFailure>();
			sourceGameObject = null;
		}
	}

	protected sealed override IEnumerable<Orientation> GetTargetOrientations()
	{
		return GetTargetOrientations(source);
	}

	protected sealed override Vector3 GetTargetPosition()
	{
		return GetTargetPosition(source);
	}

	protected abstract IEnumerable<T> GetSources(Predicate<Identifiable.Id> predicate);

	protected abstract IEnumerable<Orientation> GetTargetOrientations(T source);

	protected abstract Vector3 GetTargetPosition(T source);

	protected abstract GameObject GetTargetGameObject(T source);

	[CompilerGenerated]
	private bool _003CRelevancy_003Eb__0_0(Identifiable.Id id)
	{
		if (predicate(id) && drone.ammo.CouldAddToSlot(id))
		{
			if (!drone.ammo.Any())
			{
				return HasAvailableDestinationSpace(id);
			}
			return true;
		}
		return false;
	}
}
