using UnityEngine;

public class DisableDuringLoading : MonoBehaviour
{
	private void Start()
	{
	}

	private void Update()
	{
	}
}
