using UnityEngine;

public class DebugTeleportDestination : SRBehaviour
{
	[Tooltip("Name shown on the debug command menu.")]
	public new string name;
}
