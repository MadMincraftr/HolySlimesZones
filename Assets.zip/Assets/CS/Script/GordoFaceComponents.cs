using UnityEngine;

public class GordoFaceComponents : SRBehaviour
{
	public Material blinkEyes;

	public Material strainEyes;

	public Material chompOpenMouth;

	public Material strainMouth;

	public Material happyMouth;
}
