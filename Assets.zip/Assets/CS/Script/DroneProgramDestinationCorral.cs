using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using UnityEngine;

public class DroneProgramDestinationCorral : DroneProgramDestination<DroneProgramDestinationCorral.Destination>
{
	public class Destination
	{
		public class Comparer : SRComparer<Destination>
		{
			[Serializable]
			[CompilerGenerated]
			private sealed class _003C_003Ec
			{
				public static readonly _003C_003Ec _003C_003E9 = new _003C_003Ec();

				internal bool _003C_002Ecctor_003Eb__2_0(Destination m)
				{
					return m.anyFavorite;
				}

				internal int _003C_002Ecctor_003Eb__2_1(Destination m)
				{
					return m.available;
				}
			}

			public new static Comparer<Destination> Default = new Comparer().OrderByDescending<bool>(_003C_003Ec._003C_003E9._003C_002Ecctor_003Eb__2_0).OrderBy<int>(_003C_003Ec._003C_003E9._003C_002Ecctor_003Eb__2_1);
		}

		[Serializable]
		[CompilerGenerated]
		private sealed class _003C_003Ec
		{
			public static readonly _003C_003Ec _003C_003E9 = new _003C_003Ec();

			public static Func<SlimeDiet.EatMapEntry, bool> _003C_003E9__5_0;

			internal bool _003C_002Ector_003Eb__5_0(SlimeDiet.EatMapEntry e)
			{
				return e.isFavorite;
			}
		}

		public readonly DroneNetwork.LandPlotMetadata metadata;

		public readonly int available;

		public readonly bool anyEat;

		public readonly bool anyFavorite;

		public Destination(DroneNetwork.LandPlotMetadata metadata, Identifiable.Id id)
		{
			this.metadata = metadata;
			int num = 0;
			int num2 = 0;
			TrackContainedIdentifiables[] trackers = metadata.trackers;
			for (int i = 0; i < trackers.Length; i++)
			{
				foreach (KeyValuePair<Identifiable.Id, HashSet<Identifiable>> item in trackers[i].GetAllTracked())
				{
					if (!item.Value.Any())
					{
						continue;
					}
					if (Identifiable.IsSlime(item.Key))
					{
						if (!anyEat || !anyFavorite)
						{
							SlimeEat component = item.Value.First().GetComponent<SlimeEat>();
							anyEat |= component.DoesEat(id);
							anyFavorite |= component.GetEatMapById(id).Any(_003C_003Ec._003C_003E9__5_0 ?? (_003C_003Ec._003C_003E9__5_0 = _003C_003Ec._003C_003E9._003C_002Ector_003Eb__5_0));
						}
						num += item.Value.Count;
					}
					else if (Identifiable.IsFood(item.Key))
					{
						num2 += item.Value.Count;
					}
				}
			}
			available = Mathf.Max(0, Mathf.Max(5, Mathf.CeilToInt((float)num * 1.2f)) - num2);
		}

		public bool CanCancel()
		{
			return metadata.plot == null;
		}
	}

	[Serializable]
	[CompilerGenerated]
	private sealed class _003C_003Ec
	{
		public static readonly _003C_003Ec _003C_003E9 = new _003C_003Ec();

		public static Func<int, Destination, int> _003C_003E9__0_0;

		public static Func<Destination, bool> _003C_003E9__1_0;

		public static Func<DroneNetwork.LandPlotMetadata, bool> _003C_003E9__2_0;

		public static Func<Destination, bool> _003C_003E9__2_2;

		public static Func<Destination, Destination> _003C_003E9__3_0;

		internal int _003CGetAvailableSpace_003Eb__0_0(int cd, Destination m)
		{
			return cd + m.available;
		}

		internal bool _003CHasAvailableSpace_003Eb__1_0(Destination m)
		{
			return m.available > 0;
		}

		internal bool _003CGetDestinations_003Eb__2_0(DroneNetwork.LandPlotMetadata m)
		{
			return m.plot.typeId == LandPlot.Id.CORRAL;
		}

		internal bool _003CGetDestinations_003Eb__2_2(Destination m)
		{
			if (m.anyEat)
			{
				return m.available >= 5;
			}
			return false;
		}

		internal Destination _003CPrioritize_003Eb__3_0(Destination d)
		{
			return d;
		}
	}

	[CompilerGenerated]
	private sealed class _003C_003Ec__DisplayClass2_0
	{
		public Identifiable.Id id;

		internal Destination _003CGetDestinations_003Eb__1(DroneNetwork.LandPlotMetadata m)
		{
			return new Destination(m, id);
		}
	}

	private double time;

	private int dropCount;

	private const float FOODS_PER_SLIME = 1.2f;

	private const int MINIMUM_DELIVERY = 5;

	protected override DroneAnimator.Id animation
	{
		get
		{
			return DroneAnimator.Id.IDLE;
		}
	}

	protected override DroneAnimatorState.Id animationStateBegin
	{
		get
		{
			return DroneAnimatorState.Id.NONE;
		}
	}

	protected override DroneAnimatorState.Id animationStateEnd
	{
		get
		{
			return DroneAnimatorState.Id.NONE;
		}
	}

	public override int GetAvailableSpace(Identifiable.Id id)
	{
		return GetDestinations(id, false).Aggregate(0, _003C_003Ec._003C_003E9__0_0 ?? (_003C_003Ec._003C_003E9__0_0 = _003C_003Ec._003C_003E9._003CGetAvailableSpace_003Eb__0_0));
	}

	public override bool HasAvailableSpace(Identifiable.Id id)
	{
		return GetDestinations(id, false).Any(_003C_003Ec._003C_003E9__1_0 ?? (_003C_003Ec._003C_003E9__1_0 = _003C_003Ec._003C_003E9._003CHasAvailableSpace_003Eb__1_0));
	}

	protected override IEnumerable<Destination> GetDestinations(Identifiable.Id id, bool overflow)
	{
		_003C_003Ec__DisplayClass2_0 _003C_003Ec__DisplayClass2_ = new _003C_003Ec__DisplayClass2_0();
		_003C_003Ec__DisplayClass2_.id = id;
		return drone.network.Plots.Where(_003C_003Ec._003C_003E9__2_0 ?? (_003C_003Ec._003C_003E9__2_0 = _003C_003Ec._003C_003E9._003CGetDestinations_003Eb__2_0)).Select(_003C_003Ec__DisplayClass2_._003CGetDestinations_003Eb__1).Where(_003C_003Ec._003C_003E9__2_2 ?? (_003C_003Ec._003C_003E9__2_2 = _003C_003Ec._003C_003E9._003CGetDestinations_003Eb__2_2));
	}

	protected override IEnumerable<Destination> Prioritize(IEnumerable<Destination> destinations)
	{
		return destinations.OrderBy(_003C_003Ec._003C_003E9__3_0 ?? (_003C_003Ec._003C_003E9__3_0 = _003C_003Ec._003C_003E9._003CPrioritize_003Eb__3_0), Destination.Comparer.Default);
	}

	protected override bool CanCancel()
	{
		if (!base.CanCancel())
		{
			return destination.CanCancel();
		}
		return true;
	}

	protected override IEnumerable<Orientation> GetTargetOrientations()
	{
		return GetTargetOrientations(destination);
	}

	protected static IEnumerable<Orientation> GetTargetOrientations(Destination destination)
	{
		yield return new Orientation(destination.metadata.plot.transform.position + Vector3.up * (destination.metadata.plot.HasUpgrade(LandPlot.Upgrade.WALLS) ? 6 : 3), Quaternion.Euler(0f, Randoms.SHARED.GetInRange(0, 360), 0f));
	}

	protected override Vector3 GetTargetPosition()
	{
		return destination.metadata.plot.transform.position;
	}

	protected override void OnFirstAction()
	{
		base.OnFirstAction();
		time = timeDirector.HoursFromNow(0.013333335f);
		dropCount = new Destination(destination.metadata, drone.ammo.GetSlotName()).available;
	}

	protected override bool OnAction_Deposit(bool overflow)
	{
		if (dropCount > 0 || overflow)
		{
			dropCount -= (OnAction_DumpAmmo(ref time) ? 1 : 0);
		}
		if (!overflow)
		{
			return dropCount <= 0;
		}
		return false;
	}

	public override FastForward_Response FastForward(Identifiable.Id id, bool overflow, double endTime, int maxFastForward)
	{
		Destination destination = Prioritize(GetDestinations(id, overflow)).First();
		maxFastForward = (overflow ? maxFastForward : Mathf.Min(maxFastForward, destination.available));
		maxFastForward = RanchCellFastForwarder.FeedSlimes(destination.metadata, endTime, new RanchCellFastForwarder.FeedingSource.Basic(id, maxFastForward));
		return new FastForward_Response
		{
			deposits = maxFastForward
		};
	}
}
