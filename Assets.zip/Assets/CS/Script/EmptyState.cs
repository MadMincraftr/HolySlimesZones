public class EmptyState : BaseState
{
	public EmptyState(string name)
		: base(name)
	{
	}
}
