using System.Collections.Generic;

public class DroneProgramSourceFreeRange : DroneProgramSourceDynamic
{
	protected override GardenDroneSubnetwork GetSubnetwork()
	{
		DroneNetwork.LandPlotMetadata containing = drone.network.GetContaining(source);
		if (containing == null)
		{
			return null;
		}
		return containing.subnetwork;
	}

	protected override IEnumerable<Orientation> GetTargetOrientations(Identifiable source)
	{
		return GetTargetOrientations_Gather(source.gameObject, new GatherConfig
		{
			distanceVertical = 1.25f
		});
	}
}
