using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using MonomiPark.SlimeRancher.DataModel;
using UnityEngine;

public class EventGordoRewards : GordoRewardsBase
{
	[CompilerGenerated]
	private sealed class _003C_003Ec__DisplayClass4_0
	{
		public string id;

		internal bool _003CPickOrnamentReward_003Eb__0(HolidayModel.EventGordo e)
		{
			return e.objectId == id;
		}
	}

	[Tooltip("Fashion to attach to spawned slimes. (optional)")]
	public Fashion slimeFashion;

	[Tooltip("Number of EventGordo crates to spawn on break.")]
	public int cratesToSpawn;

	protected override IEnumerable<GameObject> SelectActiveRewardPrefabs()
	{
		LookupDirector lookupDirector = SRSingleton<GameContext>.Instance.LookupDirector;
		List<GameObject> list = new List<GameObject>();
		list.Add(lookupDirector.GetPrefab(PickOrnamentReward()));
		list.AddRange(Enumerable.Repeat(lookupDirector.GetPrefab(HolidayModel.EventGordo.CRATE), cratesToSpawn));
		return list;
	}

	protected override void OnInstantiatedReward(GameObject instance)
	{
		base.OnInstantiatedReward(instance);
		if (slimeFashion != null)
		{
			AttachFashions component = instance.GetComponent<AttachFashions>();
			if (component != null)
			{
				component.Attach(slimeFashion, true);
			}
		}
	}

	private Identifiable.Id PickOrnamentReward()
	{
		_003C_003Ec__DisplayClass4_0 _003C_003Ec__DisplayClass4_ = new _003C_003Ec__DisplayClass4_0();
		_003C_003Ec__DisplayClass4_.id = GetComponent<IdHandler>().id;
		HolidayModel.EventGordo eventGordo = SRSingleton<SceneContext>.Instance.GameModel.GetHolidayModel().eventGordos.FirstOrDefault(_003C_003Ec__DisplayClass4_._003CPickOrnamentReward_003Eb__0);
		if (eventGordo is HolidayModel.EventGordo.Fixed)
		{
			return ((HolidayModel.EventGordo.Fixed)eventGordo).ornament;
		}
		return Randoms.SHARED.Pick(HolidayModel.EventGordo.RARE_ORNAMENTS);
	}
}
