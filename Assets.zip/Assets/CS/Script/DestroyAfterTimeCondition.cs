public interface DestroyAfterTimeCondition
{
	bool ReadyToDestroy();
}
