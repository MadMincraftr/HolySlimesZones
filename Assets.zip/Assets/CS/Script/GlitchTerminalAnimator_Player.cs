using System.Collections;
using System.Runtime.CompilerServices;
using UnityEngine;

public class GlitchTerminalAnimator_Player : SRAnimator
{
	private delegate void OnStateChanged(GlitchTerminalAnimator_PlayerState.Id id);

	public enum AnimationEvent
	{
		ENTERING_FULLY_COVERED = 0
	}

	private delegate void OnAnimationEventListener(AnimationEvent eventId);

	[CompilerGenerated]
	private sealed class _003C_003Ec__DisplayClass6_0
	{
		public bool wasTriggered;

		public GlitchTerminalAnimator_PlayerState.Id id;

		internal void _003CWaitForStateExit_003Eb__0(GlitchTerminalAnimator_PlayerState.Id otherid)
		{
			wasTriggered |= id == otherid;
		}

		internal bool _003CWaitForStateExit_003Eb__1()
		{
			return wasTriggered;
		}
	}

	[CompilerGenerated]
	private sealed class _003C_003Ec__DisplayClass13_0
	{
		public bool wasTriggered;

		public AnimationEvent eventId;

		internal void _003CWaitForAnimationEvent_003Eb__0(AnimationEvent otherid)
		{
			wasTriggered |= eventId == otherid;
		}

		internal bool _003CWaitForAnimationEvent_003Eb__1()
		{
			return wasTriggered;
		}
	}

	public const string TRIGGER_ENTER_SLIMULATION = "trigger_enter_slimulation";

	public const string TRIGGER_EXIT_SLIMULATION = "trigger_exit_slimulation";

	private event OnStateChanged onStateExit;

	private event OnAnimationEventListener onAnimationEvent;

	public IEnumerator WaitForStateExit(GlitchTerminalAnimator_PlayerState.Id id)
	{
		_003C_003Ec__DisplayClass6_0 _003C_003Ec__DisplayClass6_ = new _003C_003Ec__DisplayClass6_0();
		_003C_003Ec__DisplayClass6_.id = id;
		_003C_003Ec__DisplayClass6_.wasTriggered = false;
		OnStateChanged listener = _003C_003Ec__DisplayClass6_._003CWaitForStateExit_003Eb__0;
		onStateExit += listener;
		yield return new WaitUntil(_003C_003Ec__DisplayClass6_._003CWaitForStateExit_003Eb__1);
		onStateExit -= listener;
	}

	public void OnStateExit(GlitchTerminalAnimator_PlayerState.Id id)
	{
		if (this.onStateExit != null)
		{
			this.onStateExit(id);
		}
	}

	public IEnumerator WaitForAnimationEvent(AnimationEvent eventId)
	{
		_003C_003Ec__DisplayClass13_0 _003C_003Ec__DisplayClass13_ = new _003C_003Ec__DisplayClass13_0();
		_003C_003Ec__DisplayClass13_.eventId = eventId;
		_003C_003Ec__DisplayClass13_.wasTriggered = false;
		OnAnimationEventListener listener = _003C_003Ec__DisplayClass13_._003CWaitForAnimationEvent_003Eb__0;
		onAnimationEvent += listener;
		yield return new WaitUntil(_003C_003Ec__DisplayClass13_._003CWaitForAnimationEvent_003Eb__1);
		onAnimationEvent -= listener;
	}

	public void OnAnimationEvent(AnimationEvent eventId)
	{
		if (this.onAnimationEvent != null)
		{
			this.onAnimationEvent(eventId);
		}
	}
}
