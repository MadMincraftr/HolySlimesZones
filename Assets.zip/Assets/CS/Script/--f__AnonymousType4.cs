using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;

[CompilerGenerated]
internal sealed class _003C_003Ef__AnonymousType4<_003CgameObject_003Ej__TPar, _003CcullSlimesLimit_003Ej__TPar, _003CtargetSlimeCount_003Ej__TPar, _003CdespawnFactor_003Ej__TPar, _003CslimesCount_003Ej__TPar, _003ChasTooManySlimes_003Ej__TPar>
{
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private readonly _003CgameObject_003Ej__TPar _003CgameObject_003Ei__Field;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private readonly _003CcullSlimesLimit_003Ej__TPar _003CcullSlimesLimit_003Ei__Field;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private readonly _003CtargetSlimeCount_003Ej__TPar _003CtargetSlimeCount_003Ei__Field;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private readonly _003CdespawnFactor_003Ej__TPar _003CdespawnFactor_003Ei__Field;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private readonly _003CslimesCount_003Ej__TPar _003CslimesCount_003Ei__Field;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private readonly _003ChasTooManySlimes_003Ej__TPar _003ChasTooManySlimes_003Ei__Field;

	public _003CgameObject_003Ej__TPar gameObject
	{
		get
		{
			return _003CgameObject_003Ei__Field;
		}
	}

	public _003CcullSlimesLimit_003Ej__TPar cullSlimesLimit
	{
		get
		{
			return _003CcullSlimesLimit_003Ei__Field;
		}
	}

	public _003CtargetSlimeCount_003Ej__TPar targetSlimeCount
	{
		get
		{
			return _003CtargetSlimeCount_003Ei__Field;
		}
	}

	public _003CdespawnFactor_003Ej__TPar despawnFactor
	{
		get
		{
			return _003CdespawnFactor_003Ei__Field;
		}
	}

	public _003CslimesCount_003Ej__TPar slimesCount
	{
		get
		{
			return _003CslimesCount_003Ei__Field;
		}
	}

	public _003ChasTooManySlimes_003Ej__TPar hasTooManySlimes
	{
		get
		{
			return _003ChasTooManySlimes_003Ei__Field;
		}
	}

	[DebuggerHidden]
	public _003C_003Ef__AnonymousType4(_003CgameObject_003Ej__TPar gameObject, _003CcullSlimesLimit_003Ej__TPar cullSlimesLimit, _003CtargetSlimeCount_003Ej__TPar targetSlimeCount, _003CdespawnFactor_003Ej__TPar despawnFactor, _003CslimesCount_003Ej__TPar slimesCount, _003ChasTooManySlimes_003Ej__TPar hasTooManySlimes)
	{
		_003CgameObject_003Ei__Field = gameObject;
		_003CcullSlimesLimit_003Ei__Field = cullSlimesLimit;
		_003CtargetSlimeCount_003Ei__Field = targetSlimeCount;
		_003CdespawnFactor_003Ei__Field = despawnFactor;
		_003CslimesCount_003Ei__Field = slimesCount;
		_003ChasTooManySlimes_003Ei__Field = hasTooManySlimes;
	}

	[DebuggerHidden]
	public override bool Equals(object value)
	{
		_003C_003Ef__AnonymousType4<_003CgameObject_003Ej__TPar, _003CcullSlimesLimit_003Ej__TPar, _003CtargetSlimeCount_003Ej__TPar, _003CdespawnFactor_003Ej__TPar, _003CslimesCount_003Ej__TPar, _003ChasTooManySlimes_003Ej__TPar> anon = value as _003C_003Ef__AnonymousType4<_003CgameObject_003Ej__TPar, _003CcullSlimesLimit_003Ej__TPar, _003CtargetSlimeCount_003Ej__TPar, _003CdespawnFactor_003Ej__TPar, _003CslimesCount_003Ej__TPar, _003ChasTooManySlimes_003Ej__TPar>;
		if (anon != null && EqualityComparer<_003CgameObject_003Ej__TPar>.Default.Equals(_003CgameObject_003Ei__Field, anon._003CgameObject_003Ei__Field) && EqualityComparer<_003CcullSlimesLimit_003Ej__TPar>.Default.Equals(_003CcullSlimesLimit_003Ei__Field, anon._003CcullSlimesLimit_003Ei__Field) && EqualityComparer<_003CtargetSlimeCount_003Ej__TPar>.Default.Equals(_003CtargetSlimeCount_003Ei__Field, anon._003CtargetSlimeCount_003Ei__Field) && EqualityComparer<_003CdespawnFactor_003Ej__TPar>.Default.Equals(_003CdespawnFactor_003Ei__Field, anon._003CdespawnFactor_003Ei__Field) && EqualityComparer<_003CslimesCount_003Ej__TPar>.Default.Equals(_003CslimesCount_003Ei__Field, anon._003CslimesCount_003Ei__Field))
		{
			return EqualityComparer<_003ChasTooManySlimes_003Ej__TPar>.Default.Equals(_003ChasTooManySlimes_003Ei__Field, anon._003ChasTooManySlimes_003Ei__Field);
		}
		return false;
	}

	[DebuggerHidden]
	public override string ToString()
	{
		object[] array = new object[6];
		_003CgameObject_003Ej__TPar val = _003CgameObject_003Ei__Field;
		ref _003CgameObject_003Ej__TPar reference = ref val;
		_003CgameObject_003Ej__TPar val2 = default(_003CgameObject_003Ej__TPar);
		object obj;
		if (val2 == null)
		{
			val2 = reference;
			reference = ref val2;
			if (val2 == null)
			{
				obj = null;
				goto IL_0046;
			}
		}
		obj = reference.ToString();
		goto IL_0046;
		IL_0081:
		object obj2;
		array[1] = obj2;
		_003CtargetSlimeCount_003Ej__TPar val3 = _003CtargetSlimeCount_003Ei__Field;
		ref _003CtargetSlimeCount_003Ej__TPar reference2 = ref val3;
		_003CtargetSlimeCount_003Ej__TPar val4 = default(_003CtargetSlimeCount_003Ej__TPar);
		object obj3;
		if (val4 == null)
		{
			val4 = reference2;
			reference2 = ref val4;
			if (val4 == null)
			{
				obj3 = null;
				goto IL_00c0;
			}
		}
		obj3 = reference2.ToString();
		goto IL_00c0;
		IL_017d:
		object obj4;
		array[5] = obj4;
		return string.Format(null, "{{ gameObject = {0}, cullSlimesLimit = {1}, targetSlimeCount = {2}, despawnFactor = {3}, slimesCount = {4}, hasTooManySlimes = {5} }}", array);
		IL_00ff:
		object obj5;
		array[3] = obj5;
		_003CslimesCount_003Ej__TPar val5 = _003CslimesCount_003Ei__Field;
		ref _003CslimesCount_003Ej__TPar reference3 = ref val5;
		_003CslimesCount_003Ej__TPar val6 = default(_003CslimesCount_003Ej__TPar);
		object obj6;
		if (val6 == null)
		{
			val6 = reference3;
			reference3 = ref val6;
			if (val6 == null)
			{
				obj6 = null;
				goto IL_013e;
			}
		}
		obj6 = reference3.ToString();
		goto IL_013e;
		IL_0046:
		array[0] = obj;
		_003CcullSlimesLimit_003Ej__TPar val7 = _003CcullSlimesLimit_003Ei__Field;
		ref _003CcullSlimesLimit_003Ej__TPar reference4 = ref val7;
		_003CcullSlimesLimit_003Ej__TPar val8 = default(_003CcullSlimesLimit_003Ej__TPar);
		if (val8 == null)
		{
			val8 = reference4;
			reference4 = ref val8;
			if (val8 == null)
			{
				obj2 = null;
				goto IL_0081;
			}
		}
		obj2 = reference4.ToString();
		goto IL_0081;
		IL_013e:
		array[4] = obj6;
		_003ChasTooManySlimes_003Ej__TPar val9 = _003ChasTooManySlimes_003Ei__Field;
		ref _003ChasTooManySlimes_003Ej__TPar reference5 = ref val9;
		_003ChasTooManySlimes_003Ej__TPar val10 = default(_003ChasTooManySlimes_003Ej__TPar);
		if (val10 == null)
		{
			val10 = reference5;
			reference5 = ref val10;
			if (val10 == null)
			{
				obj4 = null;
				goto IL_017d;
			}
		}
		obj4 = reference5.ToString();
		goto IL_017d;
		IL_00c0:
		array[2] = obj3;
		_003CdespawnFactor_003Ej__TPar val11 = _003CdespawnFactor_003Ei__Field;
		ref _003CdespawnFactor_003Ej__TPar reference6 = ref val11;
		_003CdespawnFactor_003Ej__TPar val12 = default(_003CdespawnFactor_003Ej__TPar);
		if (val12 == null)
		{
			val12 = reference6;
			reference6 = ref val12;
			if (val12 == null)
			{
				obj5 = null;
				goto IL_00ff;
			}
		}
		obj5 = reference6.ToString();
		goto IL_00ff;
	}
}
