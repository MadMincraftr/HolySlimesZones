public class BasicIdHandler : IdHandler
{
	protected override string IdPrefix()
	{
		return string.Empty;
	}
}
