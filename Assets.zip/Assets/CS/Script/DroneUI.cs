using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class DroneUI : BaseUI
{
	private delegate DroneMetadata.Program DeriveProgram(DroneMetadata.Program program);

	[Serializable]
	[CompilerGenerated]
	private sealed class _003C_003Ec
	{
		public static readonly _003C_003Ec _003C_003E9 = new _003C_003Ec();

		public static Func<DroneMetadata.Program, DroneMetadata.Program> _003C_003E9__7_0;

		public static Func<DroneMetadata.Program, bool> _003C_003E9__13_0;

		public static Func<DroneMetadata.Program, bool> _003C_003E9__13_1;

		internal DroneMetadata.Program _003CInit_003Eb__7_0(DroneMetadata.Program p)
		{
			return p.Clone();
		}

		internal bool _003CUpdateButtonState_003Eb__13_0(DroneMetadata.Program p)
		{
			return p.IsComplete();
		}

		internal bool _003CUpdateButtonState_003Eb__13_1(DroneMetadata.Program p)
		{
			return !p.IsReset();
		}
	}

	[CompilerGenerated]
	private sealed class _003C_003Ec__DisplayClass12_0
	{
		public int idx;

		public DroneMetadata.Program program;

		public DroneUI _003C_003E4__this;

		internal void _003CResetUI_003Eb__1(DroneMetadata.Program wp)
		{
			_003C_003Ec__DisplayClass12_1 _003C_003Ec__DisplayClass12_ = new _003C_003Ec__DisplayClass12_1
			{
				CS_0024_003C_003E8__locals1 = this,
				wp = wp
			};
			_003C_003E4__this.GatherTarget(_003C_003Ec__DisplayClass12_.wp, _003C_003Ec__DisplayClass12_._003CResetUI_003Eb__6);
		}

		internal void _003CResetUI_003Eb__3(DroneMetadata.Program wp)
		{
			_003C_003Ec__DisplayClass12_2 _003C_003Ec__DisplayClass12_ = new _003C_003Ec__DisplayClass12_2
			{
				CS_0024_003C_003E8__locals2 = this,
				wp = wp
			};
			_003C_003E4__this.GatherSource(_003C_003Ec__DisplayClass12_.wp, _003C_003Ec__DisplayClass12_._003CResetUI_003Eb__7);
		}

		internal void _003CResetUI_003Eb__5(DroneMetadata.Program wp)
		{
			_003C_003Ec__DisplayClass12_3 _003C_003Ec__DisplayClass12_ = new _003C_003Ec__DisplayClass12_3
			{
				CS_0024_003C_003E8__locals3 = this,
				wp = wp
			};
			_003C_003E4__this.GatherDestination(_003C_003Ec__DisplayClass12_.wp, _003C_003Ec__DisplayClass12_._003CResetUI_003Eb__8);
		}
	}

	[CompilerGenerated]
	private sealed class _003C_003Ec__DisplayClass12_1
	{
		public DroneMetadata.Program wp;

		public _003C_003Ec__DisplayClass12_0 CS_0024_003C_003E8__locals1;

		internal void _003CResetUI_003Eb__6(DroneMetadata.Program.Target tgt)
		{
			wp.target = tgt;
			CS_0024_003C_003E8__locals1._003C_003E4__this.programs[CS_0024_003C_003E8__locals1.idx] = (CS_0024_003C_003E8__locals1.program = wp);
			CS_0024_003C_003E8__locals1._003C_003E4__this.programsChanged = true;
		}
	}

	[CompilerGenerated]
	private sealed class _003C_003Ec__DisplayClass12_2
	{
		public DroneMetadata.Program wp;

		public _003C_003Ec__DisplayClass12_0 CS_0024_003C_003E8__locals2;

		internal void _003CResetUI_003Eb__7(DroneMetadata.Program.Behaviour src)
		{
			wp.source = src;
			CS_0024_003C_003E8__locals2._003C_003E4__this.programs[CS_0024_003C_003E8__locals2.idx] = (CS_0024_003C_003E8__locals2.program = wp);
			CS_0024_003C_003E8__locals2._003C_003E4__this.programsChanged = true;
		}
	}

	[CompilerGenerated]
	private sealed class _003C_003Ec__DisplayClass12_3
	{
		public DroneMetadata.Program wp;

		public _003C_003Ec__DisplayClass12_0 CS_0024_003C_003E8__locals3;

		internal void _003CResetUI_003Eb__8(DroneMetadata.Program.Behaviour dest)
		{
			wp.destination = dest;
			CS_0024_003C_003E8__locals3._003C_003E4__this.programs[CS_0024_003C_003E8__locals3.idx] = (CS_0024_003C_003E8__locals3.program = wp);
			CS_0024_003C_003E8__locals3._003C_003E4__this.programsChanged = true;
		}
	}

	[CompilerGenerated]
	private sealed class _003C_003Ec__DisplayClass19_0
	{
		public DeriveProgram deriver;

		public DroneMetadata.Program program;

		public Action<DroneMetadata.Program> onClicked;

		internal void _003CSetProgramPicker_003Eb__0()
		{
			DroneMetadata.Program obj = deriver(program);
			onClicked(obj);
		}
	}

	[CompilerGenerated]
	private sealed class _003C_003Ec__DisplayClass23_0
	{
		public DroneMetadata.Program workingProgram;

		internal bool _003CFilterSources_003Eb__0(DroneMetadata.Program.Behaviour s)
		{
			return s.isCompatible(workingProgram);
		}
	}

	[CompilerGenerated]
	private sealed class _003C_003Ec__DisplayClass24_0
	{
		public DroneMetadata.Program workingProgram;

		internal bool _003CFilterDestinations_003Eb__0(DroneMetadata.Program.Behaviour d)
		{
			if (d.isCompatible(workingProgram))
			{
				return d.id != workingProgram.source.id.Replace("source", "destination");
			}
			return false;
		}
	}

	[CompilerGenerated]
	private sealed class _003C_003Ec__DisplayClass25_0<T> where T : DroneMetadata.Program.BaseComponent
	{
		public SECTR_AudioCue buttonCue;

		public DroneUI _003C_003E4__this;

		public Action<T> onPicked;

		internal void _003CCreatePicker_003Eb__1()
		{
			if (SRSingleton<SceneContext>.Instance != null && _003C_003E4__this != null && _003C_003E4__this.gameObject != null)
			{
				_003C_003E4__this.ResetUI();
			}
		}
	}

	[CompilerGenerated]
	private sealed class _003C_003Ec__DisplayClass25_1<T> where T : DroneMetadata.Program.BaseComponent
	{
		public T option;

		public _003C_003Ec__DisplayClass25_0<T> CS_0024_003C_003E8__locals1;

		internal void _003CCreatePicker_003Eb__0()
		{
			SECTR_AudioSystem.Play(CS_0024_003C_003E8__locals1.buttonCue, Vector3.zero, false);
			CS_0024_003C_003E8__locals1._003C_003E4__this.pickerUI.Close();
			CS_0024_003C_003E8__locals1.onPicked(option);
		}
	}

	public Transform programsParent;

	public TMP_Text warningText;

	public Button activateButton;

	public Button resetButton;

	private List<DroneUIProgram> programUIs = new List<DroneUIProgram>();

	private bool programsChanged;

	private const int GRID_COLUMNS = 6;

	private DroneGadget gadget;

	private DroneMetadata.Program[] programs;

	private DroneUIProgramPicker pickerUI;

	private DroneMetadata metadata
	{
		get
		{
			return gadget.metadata;
		}
	}

	public DroneUI Init(DroneGadget gadget)
	{
		this.gadget = gadget;
		programs = this.gadget.programs.Select(_003C_003Ec._003C_003E9__7_0 ?? (_003C_003Ec._003C_003E9__7_0 = _003C_003Ec._003C_003E9._003CInit_003Eb__7_0)).ToArray();
		ResetUI();
		string programWarning = GetProgramWarning();
		warningText.gameObject.SetActive(programWarning != null);
		if (programWarning != null)
		{
			warningText.text = SRSingleton<GameContext>.Instance.MessageDirector.GetBundle("ui").Xlate(programWarning);
		}
		return this;
	}

	public void Start()
	{
		SECTR_AudioSystem.Play(metadata.onGuiEnableCue, Vector3.zero, false);
	}

	public void OnEnable()
	{
		if (gadget != null)
		{
			SECTR_AudioSystem.Play(metadata.onGuiEnableCue, Vector3.zero, false);
		}
	}

	public void OnDisable()
	{
		SECTR_AudioSystem.Play(metadata.onGuiDisableCue, Vector3.zero, false);
	}

	private string GetProgramWarning()
	{
		if (!gadget.drone.ammo.IsEmpty())
		{
			return "w.drone_reprogram_drops_ammo";
		}
		return null;
	}

	private void ResetUI()
	{
		foreach (DroneUIProgram programUI in programUIs)
		{
			Destroyer.Destroy(programUI.gameObject, "DroneUI.ResetUI");
		}
		programUIs.Clear();
		for (int i = 0; i < programs.Length; i++)
		{
			_003C_003Ec__DisplayClass12_0 _003C_003Ec__DisplayClass12_ = new _003C_003Ec__DisplayClass12_0();
			_003C_003Ec__DisplayClass12_._003C_003E4__this = this;
			_003C_003Ec__DisplayClass12_.program = programs[i];
			int? index = ((programs.Length >= 2) ? new int?(i + 1) : null);
			DroneUIProgram droneUIProgram = UnityEngine.Object.Instantiate(metadata.droneUIProgram.gameObject, programsParent).GetComponent<DroneUIProgram>().Init(_003C_003Ec__DisplayClass12_.program, index);
			programUIs.Add(droneUIProgram);
			_003C_003Ec__DisplayClass12_.idx = i;
			SetProgramPicker(droneUIProgram.buttonTarget, _003C_003Ec__DisplayClass12_.program, _003CResetUI_003Eb__12_0, true, _003C_003Ec__DisplayClass12_._003CResetUI_003Eb__1);
			SetProgramPicker(droneUIProgram.buttonSource, _003C_003Ec__DisplayClass12_.program, _003CResetUI_003Eb__12_2, _003C_003Ec__DisplayClass12_.program.target.id != "drone.target.none", _003C_003Ec__DisplayClass12_._003CResetUI_003Eb__3);
			SetProgramPicker(droneUIProgram.buttonDestination, _003C_003Ec__DisplayClass12_.program, _003CResetUI_003Eb__12_4, _003C_003Ec__DisplayClass12_.program.source.id != "drone.behaviour.none", _003C_003Ec__DisplayClass12_._003CResetUI_003Eb__5);
		}
		UpdateButtonState();
		SelectFirstButton();
		for (int j = 1; j < programUIs.Count; j++)
		{
			DroneUIProgram droneUIProgram2 = programUIs[j - 1];
			DroneUIProgram down = programUIs[j];
			droneUIProgram2.LinkGamepadNav(down);
		}
		programUIs.Last().LinkGamepadNav(activateButton.interactable ? activateButton : resetButton);
	}

	private void UpdateButtonState()
	{
		activateButton.interactable = programsChanged && programs.Any(_003C_003Ec._003C_003E9__13_0 ?? (_003C_003Ec._003C_003E9__13_0 = _003C_003Ec._003C_003E9._003CUpdateButtonState_003Eb__13_0));
		resetButton.interactable = programs.Any(_003C_003Ec._003C_003E9__13_1 ?? (_003C_003Ec._003C_003E9__13_1 = _003C_003Ec._003C_003E9._003CUpdateButtonState_003Eb__13_1));
		SRBehaviour.LinkNavigation(activateButton, resetButton, NavigationDirection.DOWN_UP);
	}

	private void SelectFirstButton()
	{
		for (int i = 0; i < programs.Length; i++)
		{
			if (programs[i].target.id == "drone.target.none")
			{
				programUIs[i].buttonTarget.button.Select();
				return;
			}
			if (programs[i].source.id == "drone.behaviour.none")
			{
				programUIs[i].buttonSource.button.Select();
				return;
			}
			if (programs[i].destination.id == "drone.behaviour.none")
			{
				programUIs[i].buttonDestination.button.Select();
				return;
			}
		}
		if (activateButton.interactable)
		{
			activateButton.Select();
		}
		else
		{
			programUIs[0].buttonTarget.button.Select();
		}
	}

	protected override bool Closeable()
	{
		if (base.Closeable())
		{
			return pickerUI == null;
		}
		return false;
	}

	public void OnClickConfirmation()
	{
		SECTR_AudioSystem.Play(metadata.onGuiButtonActivateCue, Vector3.zero, false);
		gadget.SetPrograms(programs);
		Close();
	}

	public void OnClickReset()
	{
		SECTR_AudioSystem.Play(metadata.onGuiButtonResetCue, Vector3.zero, false);
		DroneMetadata.Program[] array = programs;
		foreach (DroneMetadata.Program obj in array)
		{
			obj.target = metadata.GetDefaultTarget();
			obj.source = metadata.GetDefaultBehaviour();
			obj.destination = metadata.GetDefaultBehaviour();
		}
		gadget.SetPrograms(programs);
		programsChanged = false;
		ResetUI();
	}

	private void SetProgramPicker(DroneUIProgramButton button, DroneMetadata.Program program, DeriveProgram deriver, bool interactable, Action<DroneMetadata.Program> onClicked)
	{
		_003C_003Ec__DisplayClass19_0 _003C_003Ec__DisplayClass19_ = new _003C_003Ec__DisplayClass19_0();
		_003C_003Ec__DisplayClass19_.deriver = deriver;
		_003C_003Ec__DisplayClass19_.program = program;
		_003C_003Ec__DisplayClass19_.onClicked = onClicked;
		button.button.interactable = interactable;
		button.button.onClick.AddListener(_003C_003Ec__DisplayClass19_._003CSetProgramPicker_003Eb__0);
	}

	private void GatherTarget(DroneMetadata.Program workingProgram, Action<DroneMetadata.Program.Target> onComplete)
	{
		if (workingProgram.target.id == "drone.target.none")
		{
			CreatePicker("t.drone.pick_target", metadata.pickTargetIcon, metadata.targets, metadata.onGuiButtonTargetCue, onComplete);
		}
		else
		{
			onComplete(workingProgram.target);
		}
	}

	private void GatherSource(DroneMetadata.Program workingProgram, Action<DroneMetadata.Program.Behaviour> onComplete)
	{
		if (workingProgram.source.id == "drone.behaviour.none")
		{
			CreatePicker("t.drone.pick_source", metadata.pickSourceIcon, FilterSources(workingProgram, metadata.sources), metadata.onGuiButtonSourceCue, onComplete);
		}
		else
		{
			onComplete(workingProgram.source);
		}
	}

	private void GatherDestination(DroneMetadata.Program workingProgram, Action<DroneMetadata.Program.Behaviour> onComplete)
	{
		if (workingProgram.destination.id == "drone.behaviour.none")
		{
			CreatePicker("t.drone.pick_destination", metadata.pickDestinationIcon, FilterDestinations(workingProgram, metadata.destinations), metadata.onGuiButtonDestinationCue, onComplete);
		}
		else
		{
			onComplete(workingProgram.destination);
		}
	}

	private DroneMetadata.Program.Behaviour[] FilterSources(DroneMetadata.Program workingProgram, DroneMetadata.Program.Behaviour[] allSrcs)
	{
		_003C_003Ec__DisplayClass23_0 _003C_003Ec__DisplayClass23_ = new _003C_003Ec__DisplayClass23_0();
		_003C_003Ec__DisplayClass23_.workingProgram = workingProgram;
		return allSrcs.Where(_003C_003Ec__DisplayClass23_._003CFilterSources_003Eb__0).ToArray();
	}

	private DroneMetadata.Program.Behaviour[] FilterDestinations(DroneMetadata.Program workingProgram, DroneMetadata.Program.Behaviour[] allDests)
	{
		_003C_003Ec__DisplayClass24_0 _003C_003Ec__DisplayClass24_ = new _003C_003Ec__DisplayClass24_0();
		_003C_003Ec__DisplayClass24_.workingProgram = workingProgram;
		return allDests.Where(_003C_003Ec__DisplayClass24_._003CFilterDestinations_003Eb__0).ToArray();
	}

	private void CreatePicker<T>(string title, Sprite titleIcon, T[] options, SECTR_AudioCue buttonCue, Action<T> onPicked) where T : DroneMetadata.Program.BaseComponent
	{
		_003C_003Ec__DisplayClass25_0<T> _003C_003Ec__DisplayClass25_ = new _003C_003Ec__DisplayClass25_0<T>();
		_003C_003Ec__DisplayClass25_.buttonCue = buttonCue;
		_003C_003Ec__DisplayClass25_._003C_003E4__this = this;
		_003C_003Ec__DisplayClass25_.onPicked = onPicked;
		if (pickerUI != null)
		{
			Destroyer.Destroy(pickerUI.gameObject, "DroneUI.SetProgramPicker");
		}
		pickerUI = UnityEngine.Object.Instantiate(metadata.droneUIProgramPicker.gameObject).GetComponent<DroneUIProgramPicker>();
		pickerUI.title.text = uiBundle.Get(title);
		pickerUI.icon.sprite = titleIcon;
		Button[] array = new Button[options.Length];
		for (int i = 0; i < options.Length; i++)
		{
			_003C_003Ec__DisplayClass25_1<T> _003C_003Ec__DisplayClass25_2 = new _003C_003Ec__DisplayClass25_1<T>();
			_003C_003Ec__DisplayClass25_2.CS_0024_003C_003E8__locals1 = _003C_003Ec__DisplayClass25_;
			_003C_003Ec__DisplayClass25_2.option = options[i];
			DroneUIProgramButton droneUIProgramButton = UnityEngine.Object.Instantiate(metadata.droneUIProgramButton.gameObject, pickerUI.contentGrid).GetComponent<DroneUIProgramButton>().Init(_003C_003Ec__DisplayClass25_2.option);
			droneUIProgramButton.button.onClick.AddListener(_003C_003Ec__DisplayClass25_2._003CCreatePicker_003Eb__0);
			array[i] = droneUIProgramButton.button;
			if (i == 0)
			{
				droneUIProgramButton.button.gameObject.AddComponent<InitSelected>();
			}
		}
		int num = Mathf.CeilToInt((float)array.Length / 6f);
		for (int j = 0; j < array.Length; j++)
		{
			int num2 = j / 6;
			int num3 = j % 6;
			Navigation navigation = array[j].navigation;
			navigation.mode = Navigation.Mode.Explicit;
			if (num2 > 0)
			{
				navigation.selectOnUp = array[(num2 - 1) * 6 + num3];
			}
			if (num2 < num - 1)
			{
				navigation.selectOnDown = array[Math.Min((num2 + 1) * 6 + num3, array.Length - 1)];
			}
			if (num3 > 0)
			{
				navigation.selectOnLeft = array[num2 * 6 + (num3 - 1)];
			}
			if (num3 < 5 && j < array.Length - 1)
			{
				navigation.selectOnRight = array[num2 * 6 + (num3 + 1)];
			}
			array[j].navigation = navigation;
		}
		DroneUIProgramPicker droneUIProgramPicker = pickerUI;
		droneUIProgramPicker.onDestroy = (OnDestroyDelegate)Delegate.Combine(droneUIProgramPicker.onDestroy, new OnDestroyDelegate(_003C_003Ec__DisplayClass25_._003CCreatePicker_003Eb__1));
	}

	[CompilerGenerated]
	private DroneMetadata.Program _003CResetUI_003Eb__12_0(DroneMetadata.Program p)
	{
		return new DroneMetadata.Program(metadata.GetDefaultTarget(), metadata.GetDefaultBehaviour(), metadata.GetDefaultBehaviour());
	}

	[CompilerGenerated]
	private DroneMetadata.Program _003CResetUI_003Eb__12_2(DroneMetadata.Program p)
	{
		return new DroneMetadata.Program(p.target, metadata.GetDefaultBehaviour(), metadata.GetDefaultBehaviour());
	}

	[CompilerGenerated]
	private DroneMetadata.Program _003CResetUI_003Eb__12_4(DroneMetadata.Program p)
	{
		return new DroneMetadata.Program(p.target, p.source, metadata.GetDefaultBehaviour());
	}
}
