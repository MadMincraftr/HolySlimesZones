public class GordoIdentifiable : SRBehaviour
{
	public enum Id
	{
		NONE = 0
	}

	public ZoneDirector.Zone[] nativeZones;

	public Identifiable.Id id;
}
