public class GameCoreEngagementPopupUI : BaseUI
{
}
