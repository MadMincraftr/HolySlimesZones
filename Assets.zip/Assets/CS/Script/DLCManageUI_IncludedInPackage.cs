using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class DLCManageUI_IncludedInPackage : MonoBehaviour
{
	[Tooltip("'Included in...' package text.")]
	public TMP_Text text;

	[Tooltip("Package icon.")]
	public Image icon;
}
