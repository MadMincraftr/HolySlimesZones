using System;
using System.Runtime.CompilerServices;
using UnityEngine;

public class CorralUI : LandPlotUI
{
	[Serializable]
	[CompilerGenerated]
	private sealed class _003C_003Ec
	{
		public static readonly _003C_003Ec _003C_003E9 = new _003C_003Ec();

		public static Func<bool> _003C_003E9__8_0;

		public static Func<bool> _003C_003E9__8_2;

		public static Func<bool> _003C_003E9__8_4;

		public static Func<bool> _003C_003E9__8_6;

		public static Func<bool> _003C_003E9__8_8;

		public static Func<bool> _003C_003E9__8_10;

		public static Func<bool> _003C_003E9__8_12;

		internal bool _003CCreatePurchaseUI_003Eb__8_0()
		{
			return true;
		}

		internal bool _003CCreatePurchaseUI_003Eb__8_2()
		{
			return true;
		}

		internal bool _003CCreatePurchaseUI_003Eb__8_4()
		{
			return true;
		}

		internal bool _003CCreatePurchaseUI_003Eb__8_6()
		{
			return true;
		}

		internal bool _003CCreatePurchaseUI_003Eb__8_8()
		{
			return true;
		}

		internal bool _003CCreatePurchaseUI_003Eb__8_10()
		{
			return true;
		}

		internal bool _003CCreatePurchaseUI_003Eb__8_12()
		{
			return true;
		}
	}

	public UpgradePurchaseItem walls;

	public UpgradePurchaseItem musicBox;

	public UpgradePurchaseItem airNet;

	public UpgradePurchaseItem solarShield;

	public UpgradePurchaseItem plortCollector;

	public UpgradePurchaseItem feeder;

	public PlotPurchaseItem demolish;

	public Sprite titleIcon;

	protected override GameObject CreatePurchaseUI()
	{
		PurchaseUI.Purchasable[] purchasables = new PurchaseUI.Purchasable[7]
		{
			new PurchaseUI.Purchasable("m.upgrade.name.corral.walls", walls.icon, walls.img, "m.upgrade.desc.corral.walls", walls.cost, PediaDirector.Id.CORRAL, UpgradeWalls, _003C_003Ec._003C_003E9__8_0 ?? (_003C_003Ec._003C_003E9__8_0 = _003C_003Ec._003C_003E9._003CCreatePurchaseUI_003Eb__8_0), _003CCreatePurchaseUI_003Eb__8_1),
			new PurchaseUI.Purchasable("m.upgrade.name.corral.music_box", musicBox.icon, musicBox.img, "m.upgrade.desc.corral.music_box", musicBox.cost, PediaDirector.Id.CORRAL, UpgradeMusicBox, _003C_003Ec._003C_003E9__8_2 ?? (_003C_003Ec._003C_003E9__8_2 = _003C_003Ec._003C_003E9._003CCreatePurchaseUI_003Eb__8_2), _003CCreatePurchaseUI_003Eb__8_3),
			new PurchaseUI.Purchasable("m.upgrade.name.corral.air_net", airNet.icon, airNet.img, "m.upgrade.desc.corral.air_net", airNet.cost, PediaDirector.Id.CORRAL, UpgradeAirNet, _003C_003Ec._003C_003E9__8_4 ?? (_003C_003Ec._003C_003E9__8_4 = _003C_003Ec._003C_003E9._003CCreatePurchaseUI_003Eb__8_4), _003CCreatePurchaseUI_003Eb__8_5),
			new PurchaseUI.Purchasable("m.upgrade.name.corral.solar_shield", solarShield.icon, solarShield.img, "m.upgrade.desc.corral.solar_shield", solarShield.cost, PediaDirector.Id.CORRAL, UpgradeSolarShield, _003C_003Ec._003C_003E9__8_6 ?? (_003C_003Ec._003C_003E9__8_6 = _003C_003Ec._003C_003E9._003CCreatePurchaseUI_003Eb__8_6), _003CCreatePurchaseUI_003Eb__8_7),
			new PurchaseUI.Purchasable("m.upgrade.name.corral.plort_collector", plortCollector.icon, plortCollector.img, "m.upgrade.desc.corral.plort_collector", plortCollector.cost, PediaDirector.Id.CORRAL, UpgradePlortCollector, _003C_003Ec._003C_003E9__8_8 ?? (_003C_003Ec._003C_003E9__8_8 = _003C_003Ec._003C_003E9._003CCreatePurchaseUI_003Eb__8_8), _003CCreatePurchaseUI_003Eb__8_9),
			new PurchaseUI.Purchasable("m.upgrade.name.corral.feeder", feeder.icon, feeder.img, "m.upgrade.desc.corral.feeder", feeder.cost, PediaDirector.Id.CORRAL, UpgradeFeeder, _003C_003Ec._003C_003E9__8_10 ?? (_003C_003Ec._003C_003E9__8_10 = _003C_003Ec._003C_003E9._003CCreatePurchaseUI_003Eb__8_10), _003CCreatePurchaseUI_003Eb__8_11),
			new PurchaseUI.Purchasable(MessageUtil.Qualify("ui", "l.demolish_plot"), demolish.icon, demolish.img, MessageUtil.Qualify("ui", "m.desc.demolish_plot"), demolish.cost, null, Demolish, _003C_003Ec._003C_003E9__8_12 ?? (_003C_003Ec._003C_003E9__8_12 = _003C_003Ec._003C_003E9._003CCreatePurchaseUI_003Eb__8_12), _003CCreatePurchaseUI_003Eb__8_13, "b.demolish", AllowDemolish() ? null : "w.cannot_demolish_corral_tutorial")
		};
		return SRSingleton<GameContext>.Instance.UITemplates.CreatePurchaseUI(titleIcon, "t.corral", purchasables, false, Close);
	}

	private bool AllowDemolish()
	{
		TutorialDirector tutorialDirector = SRSingleton<SceneContext>.Instance.TutorialDirector;
		OptionsDirector optionsDirector = SRSingleton<GameContext>.Instance.OptionsDirector;
		if (!tutorialDirector.IsCompletedOrDisabled(TutorialDirector.Id.SHOOTING))
		{
			return SRSingleton<SceneContext>.Instance.GameModeConfig.GetModeSettings().assumeExperiencedUser;
		}
		return true;
	}

	public void UpgradeWalls()
	{
		Upgrade(LandPlot.Upgrade.WALLS, walls.cost);
	}

	public void UpgradeMusicBox()
	{
		Upgrade(LandPlot.Upgrade.MUSIC_BOX, musicBox.cost);
	}

	public void UpgradeAirNet()
	{
		Upgrade(LandPlot.Upgrade.AIR_NET, airNet.cost);
	}

	public void UpgradeSolarShield()
	{
		Upgrade(LandPlot.Upgrade.SOLAR_SHIELD, solarShield.cost);
	}

	public void UpgradePlortCollector()
	{
		Upgrade(LandPlot.Upgrade.PLORT_COLLECTOR, plortCollector.cost);
	}

	public void UpgradeFeeder()
	{
		Upgrade(LandPlot.Upgrade.FEEDER, feeder.cost);
	}

	public void Demolish()
	{
		if (playerState.GetCurrency() >= demolish.cost)
		{
			playerState.SpendCurrency(demolish.cost);
			Replace(demolish.plotPrefab);
			PlayPurchaseCue();
		}
		else
		{
			Error("e.insuf_coins");
		}
	}

	[CompilerGenerated]
	private bool _003CCreatePurchaseUI_003Eb__8_1()
	{
		return !activator.HasUpgrade(LandPlot.Upgrade.WALLS);
	}

	[CompilerGenerated]
	private bool _003CCreatePurchaseUI_003Eb__8_3()
	{
		return !activator.HasUpgrade(LandPlot.Upgrade.MUSIC_BOX);
	}

	[CompilerGenerated]
	private bool _003CCreatePurchaseUI_003Eb__8_5()
	{
		return !activator.HasUpgrade(LandPlot.Upgrade.AIR_NET);
	}

	[CompilerGenerated]
	private bool _003CCreatePurchaseUI_003Eb__8_7()
	{
		return !activator.HasUpgrade(LandPlot.Upgrade.SOLAR_SHIELD);
	}

	[CompilerGenerated]
	private bool _003CCreatePurchaseUI_003Eb__8_9()
	{
		return !activator.HasUpgrade(LandPlot.Upgrade.PLORT_COLLECTOR);
	}

	[CompilerGenerated]
	private bool _003CCreatePurchaseUI_003Eb__8_11()
	{
		return !activator.HasUpgrade(LandPlot.Upgrade.FEEDER);
	}

	[CompilerGenerated]
	private bool _003CCreatePurchaseUI_003Eb__8_13()
	{
		return AllowDemolish();
	}
}
