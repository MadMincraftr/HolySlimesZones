using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using UnityEngine;

public class DroneNetwork : PathingNetwork
{
	public class LandPlotMetadata
	{
		[CompilerGenerated]
		private sealed class _003C_003Ec__DisplayClass9_0
		{
			public Identifiable identifiable;

			internal bool _003CContains_003Eb__0(TrackContainedIdentifiables t)
			{
				return t.Contains(identifiable);
			}
		}

		public LandPlot plot;

		public GardenCatcher[] gardens;

		public StorageMetadata[] feeders;

		public StorageMetadata[] silos;

		public StorageMetadata[] plortCollectors;

		public StorageMetadata[] elderCollectors;

		public TrackContainedIdentifiables[] trackers;

		public Incinerate[] incinerators;

		public GardenDroneSubnetwork subnetwork;

		public bool Contains(Identifiable identifiable)
		{
			_003C_003Ec__DisplayClass9_0 _003C_003Ec__DisplayClass9_ = new _003C_003Ec__DisplayClass9_0();
			_003C_003Ec__DisplayClass9_.identifiable = identifiable;
			return trackers.Any(_003C_003Ec__DisplayClass9_._003CContains_003Eb__0);
		}
	}

	public class StorageMetadata
	{
		public SiloStorage storage;

		public SiloCatcher catcher;

		public int index;

		public Ammo ammo
		{
			get
			{
				return storage.GetRelevantAmmo();
			}
		}

		public Identifiable.Id id
		{
			get
			{
				return ammo.GetSlotName(index);
			}
		}

		public int count
		{
			get
			{
				return ammo.GetSlotCount(index);
			}
		}

		public int maxCount
		{
			get
			{
				return ammo.GetSlotMaxCount(index);
			}
		}

		public StorageMetadata()
		{
		}

		public StorageMetadata(StorageMetadata other)
		{
			storage = other.storage;
			catcher = other.catcher;
			index = other.index;
		}

		public bool CanCancel()
		{
			if (!(storage == null))
			{
				return !storage.gameObject.activeInHierarchy;
			}
			return true;
		}

		public int GetAvailableSpace(Identifiable.Id id)
		{
			if (this.id != id && this.id != 0)
			{
				return 0;
			}
			return maxCount - count;
		}

		public bool Increment(Identifiable.Id id, bool overflow, int count = 1)
		{
			return storage.MaybeAddIdentifiable(id, index, count, overflow);
		}

		public void Decrement(int count = 1)
		{
			ammo.Decrement(index, count);
		}

		public bool IsFull()
		{
			return count >= maxCount;
		}
	}

	[CompilerGenerated]
	private sealed class _003C_003Ec__DisplayClass8_0
	{
		public SiloStorage s;

		internal StorageMetadata _003CRegister_003Eb__8(int i)
		{
			_003C_003Ec__DisplayClass8_1 _003C_003Ec__DisplayClass8_ = new _003C_003Ec__DisplayClass8_1
			{
				i = i
			};
			return new StorageMetadata
			{
				index = _003C_003Ec__DisplayClass8_.i,
				storage = s,
				catcher = s.GetComponentsInChildren<SiloStorageActivator>().First(_003C_003Ec__DisplayClass8_._003CRegister_003Eb__10).siloCatcher
			};
		}
	}

	[CompilerGenerated]
	private sealed class _003C_003Ec__DisplayClass8_1
	{
		public int i;

		public Func<SiloSlotUI, bool> _003C_003E9__11;

		internal bool _003CRegister_003Eb__10(SiloStorageActivator a)
		{
			return a.siloSlotUIs.Any(_003C_003E9__11 ?? (_003C_003E9__11 = _003CRegister_003Eb__11));
		}

		internal bool _003CRegister_003Eb__11(SiloSlotUI ui)
		{
			return ui.slotIdx == i;
		}
	}

	[Serializable]
	[CompilerGenerated]
	private sealed class _003C_003Ec
	{
		public static readonly _003C_003Ec _003C_003E9 = new _003C_003Ec();

		public static Func<FeederUpgrader, bool> _003C_003E9__8_0;

		public static Func<FeederUpgrader, SiloStorage> _003C_003E9__8_1;

		public static Func<PlortCollectorUpgrader, bool> _003C_003E9__8_2;

		public static Func<PlortCollectorUpgrader, SiloStorage> _003C_003E9__8_3;

		public static Func<DeluxeCoopUpgrader, bool> _003C_003E9__8_4;

		public static Func<DeluxeCoopUpgrader, SiloStorage> _003C_003E9__8_5;

		public static Func<SiloSlotUI, int> _003C_003E9__8_9;

		public static Func<SiloStorageActivator, IEnumerable<int>> _003C_003E9__8_7;

		public static Func<SiloStorage, IEnumerable<StorageMetadata>> _003C_003E9__8_6;

		public static Func<SiloStorage, _003C_003Ef__AnonymousType0<SiloStorage, Ammo>> _003C_003E9__12_0;

		public static Func<_003C_003Ef__AnonymousType0<SiloStorage, Ammo>, IEnumerable<StorageMetadata>> _003C_003E9__12_1;

		internal bool _003CRegister_003Eb__8_0(FeederUpgrader c)
		{
			if (c != null)
			{
				return c.feeder.activeInHierarchy;
			}
			return false;
		}

		internal SiloStorage _003CRegister_003Eb__8_1(FeederUpgrader c)
		{
			return c.feeder.GetComponent<SiloStorage>();
		}

		internal bool _003CRegister_003Eb__8_2(PlortCollectorUpgrader c)
		{
			if (c != null)
			{
				return c.collector.activeInHierarchy;
			}
			return false;
		}

		internal SiloStorage _003CRegister_003Eb__8_3(PlortCollectorUpgrader c)
		{
			return c.collector.GetComponent<SiloStorage>();
		}

		internal bool _003CRegister_003Eb__8_4(DeluxeCoopUpgrader c)
		{
			if (c != null)
			{
				return c.deluxeStuff.activeInHierarchy;
			}
			return false;
		}

		internal SiloStorage _003CRegister_003Eb__8_5(DeluxeCoopUpgrader c)
		{
			return c.deluxeStuff.GetComponentInChildren<SiloStorage>();
		}

		internal IEnumerable<StorageMetadata> _003CRegister_003Eb__8_6(SiloStorage s)
		{
			_003C_003Ec__DisplayClass8_0 _003C_003Ec__DisplayClass8_ = new _003C_003Ec__DisplayClass8_0
			{
				s = s
			};
			return _003C_003Ec__DisplayClass8_.s.GetComponentsInChildren<SiloStorageActivator>().SelectMany(_003C_003E9__8_7 ?? (_003C_003E9__8_7 = _003C_003E9._003CRegister_003Eb__8_7)).Select(_003C_003Ec__DisplayClass8_._003CRegister_003Eb__8);
		}

		internal IEnumerable<int> _003CRegister_003Eb__8_7(SiloStorageActivator a)
		{
			return a.siloSlotUIs.Select(_003C_003E9__8_9 ?? (_003C_003E9__8_9 = _003C_003E9._003CRegister_003Eb__8_9));
		}

		internal int _003CRegister_003Eb__8_9(SiloSlotUI ui)
		{
			return ui.slotIdx;
		}

		internal _003C_003Ef__AnonymousType0<SiloStorage, Ammo> _003CGetStorageMetadata_003Eb__12_0(SiloStorage s)
		{
			return new _003C_003Ef__AnonymousType0<SiloStorage, Ammo>(s, s.GetRelevantAmmo());
		}

		internal IEnumerable<StorageMetadata> _003CGetStorageMetadata_003Eb__12_1(_003C_003Ef__AnonymousType0<SiloStorage, Ammo> s)
		{
			_003C_003Ec__DisplayClass12_0 _003C_003Ec__DisplayClass12_ = new _003C_003Ec__DisplayClass12_0
			{
				s = s
			};
			return Enumerable.Range(0, _003C_003Ec__DisplayClass12_.s.ammo.GetUsableSlotCount()).Select(_003C_003Ec__DisplayClass12_._003CGetStorageMetadata_003Eb__2);
		}
	}

	[CompilerGenerated]
	private sealed class _003C_003Ec__DisplayClass9_0
	{
		public LandPlot deregister;

		internal bool _003CDeregister_003Eb__0(LandPlotMetadata p)
		{
			return p.plot == deregister;
		}
	}

	[CompilerGenerated]
	private sealed class _003C_003Ec__DisplayClass11_0
	{
		public Identifiable source;

		internal bool _003CGetContaining_003Eb__0(LandPlotMetadata m)
		{
			return m.Contains(source);
		}
	}

	[CompilerGenerated]
	private sealed class _003C_003Ec__DisplayClass12_0
	{
		public _003C_003Ef__AnonymousType0<SiloStorage, Ammo> s;

		internal StorageMetadata _003CGetStorageMetadata_003Eb__2(int i)
		{
			_003C_003Ec__DisplayClass12_1 _003C_003Ec__DisplayClass12_ = new _003C_003Ec__DisplayClass12_1
			{
				i = i
			};
			return new StorageMetadata
			{
				index = _003C_003Ec__DisplayClass12_.i,
				storage = s.storage,
				catcher = s.storage.GetComponentsInChildren<SiloCatcher>().First(_003C_003Ec__DisplayClass12_._003CGetStorageMetadata_003Eb__3)
			};
		}
	}

	[CompilerGenerated]
	private sealed class _003C_003Ec__DisplayClass12_1
	{
		public int i;

		internal bool _003CGetStorageMetadata_003Eb__3(SiloCatcher c)
		{
			return c.slotIdx == i;
		}
	}

	[CompilerGenerated]
	private sealed class _003C_003Ec__DisplayClass20_0
	{
		public Drone deregister;

		internal bool _003CDeregister_003Eb__0(Drone d)
		{
			return d == deregister;
		}
	}

	[CompilerGenerated]
	private sealed class _003C_003Ec__DisplayClass25_0
	{
		public SiloCatcher catcher;

		internal bool _003CDeregister_003Eb__0(SiloCatcher d)
		{
			return d == catcher;
		}
	}

	[CompilerGenerated]
	private sealed class _003C_003Ec__DisplayClass30_0
	{
		public ScorePlort market;

		internal bool _003CDeregister_003Eb__0(ScorePlort d)
		{
			return d == market;
		}
	}

	public const float PATHING_THROTTLE_HRS = 1f / 30f;

	[HideInInspector]
	public double pathingThrottleUntil;

	private const float MAX_CONNECTION_DIST = 40f;

	private DronePather pather = new DronePather(40f);

	private List<LandPlotMetadata> plots = new List<LandPlotMetadata>();

	private List<Drone> drones = new List<Drone>();

	private List<SiloCatcher> refineryCatchers = new List<SiloCatcher>();

	private List<ScorePlort> markets = new List<ScorePlort>();

	public override Pather Pather
	{
		get
		{
			return pather;
		}
	}

	public IEnumerable<LandPlotMetadata> Plots
	{
		get
		{
			return plots;
		}
	}

	public IEnumerable<Drone> Drones
	{
		get
		{
			return drones;
		}
	}

	public IEnumerable<SiloCatcher> RefineryCatchers
	{
		get
		{
			return refineryCatchers;
		}
	}

	public IEnumerable<ScorePlort> Markets
	{
		get
		{
			return markets;
		}
	}

	public void Register(LandPlot p)
	{
		plots.Add(new LandPlotMetadata
		{
			plot = p,
			trackers = p.GetComponentsInChildren<TrackContainedIdentifiables>(),
			subnetwork = p.GetComponentInChildren<GardenDroneSubnetwork>(),
			feeders = ((p.typeId == LandPlot.Id.CORRAL) ? GetStorageMetadata(p.GetComponents<FeederUpgrader>().Where(_003C_003Ec._003C_003E9__8_0 ?? (_003C_003Ec._003C_003E9__8_0 = _003C_003Ec._003C_003E9._003CRegister_003Eb__8_0)).Select(_003C_003Ec._003C_003E9__8_1 ?? (_003C_003Ec._003C_003E9__8_1 = _003C_003Ec._003C_003E9._003CRegister_003Eb__8_1))).ToArray() : new StorageMetadata[0]),
			plortCollectors = ((p.typeId == LandPlot.Id.CORRAL) ? GetStorageMetadata(p.GetComponents<PlortCollectorUpgrader>().Where(_003C_003Ec._003C_003E9__8_2 ?? (_003C_003Ec._003C_003E9__8_2 = _003C_003Ec._003C_003E9._003CRegister_003Eb__8_2)).Select(_003C_003Ec._003C_003E9__8_3 ?? (_003C_003Ec._003C_003E9__8_3 = _003C_003Ec._003C_003E9._003CRegister_003Eb__8_3))).ToArray() : new StorageMetadata[0]),
			elderCollectors = ((p.typeId == LandPlot.Id.COOP) ? GetStorageMetadata(p.GetComponents<DeluxeCoopUpgrader>().Where(_003C_003Ec._003C_003E9__8_4 ?? (_003C_003Ec._003C_003E9__8_4 = _003C_003Ec._003C_003E9._003CRegister_003Eb__8_4)).Select(_003C_003Ec._003C_003E9__8_5 ?? (_003C_003Ec._003C_003E9__8_5 = _003C_003Ec._003C_003E9._003CRegister_003Eb__8_5))).ToArray() : new StorageMetadata[0]),
			silos = ((p.typeId == LandPlot.Id.SILO) ? p.GetComponents<SiloStorage>().SelectMany(_003C_003Ec._003C_003E9__8_6 ?? (_003C_003Ec._003C_003E9__8_6 = _003C_003Ec._003C_003E9._003CRegister_003Eb__8_6)).ToArray() : new StorageMetadata[0]),
			gardens = ((p.typeId == LandPlot.Id.GARDEN) ? p.GetComponentsInChildren<GardenCatcher>() : new GardenCatcher[0]),
			incinerators = ((p.typeId == LandPlot.Id.INCINERATOR) ? p.GetComponentsInChildren<Incinerate>() : new Incinerate[0])
		});
	}

	public bool Deregister(LandPlot deregister)
	{
		_003C_003Ec__DisplayClass9_0 _003C_003Ec__DisplayClass9_ = new _003C_003Ec__DisplayClass9_0();
		_003C_003Ec__DisplayClass9_.deregister = deregister;
		return plots.RemoveAll(_003C_003Ec__DisplayClass9_._003CDeregister_003Eb__0) >= 1;
	}

	public void OnUpgradesChanged(LandPlot plot)
	{
		if (Deregister(plot))
		{
			Register(plot);
		}
	}

	public LandPlotMetadata GetContaining(Identifiable source)
	{
		_003C_003Ec__DisplayClass11_0 _003C_003Ec__DisplayClass11_ = new _003C_003Ec__DisplayClass11_0();
		_003C_003Ec__DisplayClass11_.source = source;
		return plots.FirstOrDefault(_003C_003Ec__DisplayClass11_._003CGetContaining_003Eb__0);
	}

	private static IEnumerable<StorageMetadata> GetStorageMetadata(IEnumerable<SiloStorage> storages)
	{
		return storages.Select(_003C_003Ec._003C_003E9__12_0 ?? (_003C_003Ec._003C_003E9__12_0 = _003C_003Ec._003C_003E9._003CGetStorageMetadata_003Eb__12_0)).SelectMany(_003C_003Ec._003C_003E9__12_1 ?? (_003C_003Ec._003C_003E9__12_1 = _003C_003Ec._003C_003E9._003CGetStorageMetadata_003Eb__12_1));
	}

	public void Register(Drone drone)
	{
		drones.Add(drone);
	}

	public bool Deregister(Drone deregister)
	{
		_003C_003Ec__DisplayClass20_0 _003C_003Ec__DisplayClass20_ = new _003C_003Ec__DisplayClass20_0();
		_003C_003Ec__DisplayClass20_.deregister = deregister;
		return drones.RemoveAll(_003C_003Ec__DisplayClass20_._003CDeregister_003Eb__0) >= 1;
	}

	public void Register(SiloCatcher catcher)
	{
		if (catcher.type == SiloCatcher.Type.REFINERY)
		{
			refineryCatchers.Add(catcher);
		}
	}

	public bool Deregister(SiloCatcher catcher)
	{
		_003C_003Ec__DisplayClass25_0 _003C_003Ec__DisplayClass25_ = new _003C_003Ec__DisplayClass25_0();
		_003C_003Ec__DisplayClass25_.catcher = catcher;
		if (_003C_003Ec__DisplayClass25_.catcher.type == SiloCatcher.Type.REFINERY)
		{
			return refineryCatchers.RemoveAll(_003C_003Ec__DisplayClass25_._003CDeregister_003Eb__0) >= 1;
		}
		return true;
	}

	public void Register(ScorePlort market)
	{
		markets.Add(market);
	}

	public bool Deregister(ScorePlort market)
	{
		_003C_003Ec__DisplayClass30_0 _003C_003Ec__DisplayClass30_ = new _003C_003Ec__DisplayClass30_0();
		_003C_003Ec__DisplayClass30_.market = market;
		return markets.RemoveAll(_003C_003Ec__DisplayClass30_._003CDeregister_003Eb__0) >= 1;
	}

	public static bool IsResourceReady(GameObject go)
	{
		ResourceCycle component = go.GetComponent<ResourceCycle>();
		if (!(component == null) && component.GetState() != ResourceCycle.State.RIPE)
		{
			return component.GetState() == ResourceCycle.State.EDIBLE;
		}
		return true;
	}

	public static DroneNetwork Find(GameObject gameObject)
	{
		CellDirector componentInParent = gameObject.GetComponentInParent<CellDirector>();
		if (!(componentInParent == null))
		{
			return componentInParent.GetComponent<DroneNetwork>();
		}
		return null;
	}
}
