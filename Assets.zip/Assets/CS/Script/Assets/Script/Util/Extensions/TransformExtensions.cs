using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using UnityEngine;

namespace Assets.Script.Util.Extensions
{
	public static class TransformExtensions
	{
		[Serializable]
		[CompilerGenerated]
		private sealed class _003C_003Ec
		{
			public static readonly _003C_003Ec _003C_003E9 = new _003C_003Ec();

			public static Func<Transform, string> _003C_003E9__0_0;

			internal string _003CGetHierarchyString_003Eb__0_0(Transform it)
			{
				return it.name;
			}
		}

		public static string GetHierarchyString(this Transform transform)
		{
			return string.Join("/", transform.GetHierarchy().Select(_003C_003Ec._003C_003E9__0_0 ?? (_003C_003Ec._003C_003E9__0_0 = _003C_003Ec._003C_003E9._003CGetHierarchyString_003Eb__0_0)).ToArray());
		}

		public static IEnumerable<Transform> GetHierarchy(this Transform transform)
		{
			return transform.GetAscendents().Reverse();
		}

		private static IEnumerable<Transform> GetAscendents(this Transform transform)
		{
			Transform current = transform;
			while (current != null)
			{
				yield return current;
				current = current.parent;
			}
		}
	}
}
