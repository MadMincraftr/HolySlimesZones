using System;
using System.Runtime.CompilerServices;
using UnityEngine;

namespace Assets.Script.Util.Extensions
{
	public static class ComponentExtensions
	{
		[Serializable]
		[CompilerGenerated]
		private sealed class _003C_003Ec
		{
			public static readonly _003C_003Ec _003C_003E9 = new _003C_003Ec();

			public static Predicate<GameObject> _003C_003E9__4_0;

			internal bool _003CDestroyChildren_003Eb__4_0(GameObject go)
			{
				return true;
			}
		}

		public static T GetComponentInParent<T>(this Component component, bool includeInactive = false) where T : Component
		{
			return component.gameObject.GetComponentInParent<T>(includeInactive);
		}

		public static T GetRequiredComponent<T>(this Component component) where T : Component
		{
			return component.gameObject.GetRequiredComponent<T>();
		}

		public static T GetRequiredComponentInParent<T>(this Component component, bool includeInactive = false) where T : Component
		{
			return component.gameObject.GetRequiredComponentInParent<T>(includeInactive);
		}

		public static T GetRequiredComponentInChildren<T>(this Component component, bool includeInactive = false) where T : Component
		{
			return component.gameObject.GetRequiredComponentInChildren<T>(includeInactive);
		}

		public static void DestroyChildren(this Component parent, string source)
		{
			parent.DestroyChildren(_003C_003Ec._003C_003E9__4_0 ?? (_003C_003Ec._003C_003E9__4_0 = _003C_003Ec._003C_003E9._003CDestroyChildren_003Eb__4_0), source);
		}

		public static void DestroyChildren(this Component parent, Predicate<GameObject> predicate, string source)
		{
			for (int i = 0; i < parent.transform.childCount; i++)
			{
				GameObject gameObject = parent.transform.GetChild(i).gameObject;
				if (predicate(gameObject))
				{
					if (gameObject.GetComponent<Identifiable>() != null)
					{
						Destroyer.DestroyActor(gameObject, source);
					}
					else
					{
						Destroyer.Destroy(gameObject, source);
					}
				}
			}
		}
	}
}
