using UnityEngine;

public class AshSafetyZone : MonoBehaviour
{
}
