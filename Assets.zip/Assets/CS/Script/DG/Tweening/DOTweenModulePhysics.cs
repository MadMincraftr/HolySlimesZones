using System.Runtime.CompilerServices;
using DG.Tweening.Core;
using DG.Tweening.Core.Enums;
using DG.Tweening.Plugins;
using DG.Tweening.Plugins.Core.PathCore;
using DG.Tweening.Plugins.Options;
using UnityEngine;

namespace DG.Tweening
{
	public static class DOTweenModulePhysics
	{
		[CompilerGenerated]
		private sealed class _003C_003Ec__DisplayClass0_0
		{
			public Rigidbody target;

			internal Vector3 _003CDOMove_003Eb__0()
			{
				return target.position;
			}
		}

		[CompilerGenerated]
		private sealed class _003C_003Ec__DisplayClass1_0
		{
			public Rigidbody target;

			internal Vector3 _003CDOMoveX_003Eb__0()
			{
				return target.position;
			}
		}

		[CompilerGenerated]
		private sealed class _003C_003Ec__DisplayClass2_0
		{
			public Rigidbody target;

			internal Vector3 _003CDOMoveY_003Eb__0()
			{
				return target.position;
			}
		}

		[CompilerGenerated]
		private sealed class _003C_003Ec__DisplayClass3_0
		{
			public Rigidbody target;

			internal Vector3 _003CDOMoveZ_003Eb__0()
			{
				return target.position;
			}
		}

		[CompilerGenerated]
		private sealed class _003C_003Ec__DisplayClass4_0
		{
			public Rigidbody target;

			internal Quaternion _003CDORotate_003Eb__0()
			{
				return target.rotation;
			}
		}

		[CompilerGenerated]
		private sealed class _003C_003Ec__DisplayClass5_0
		{
			public Rigidbody target;

			internal Quaternion _003CDOLookAt_003Eb__0()
			{
				return target.rotation;
			}
		}

		[CompilerGenerated]
		private sealed class _003C_003Ec__DisplayClass6_0
		{
			public Rigidbody target;

			public float startPosY;

			public bool offsetYSet;

			public float offsetY;

			public Sequence s;

			public Vector3 endValue;

			public Tween yTween;

			internal Vector3 _003CDOJump_003Eb__0()
			{
				return target.position;
			}

			internal void _003CDOJump_003Eb__1()
			{
				startPosY = target.position.y;
			}

			internal Vector3 _003CDOJump_003Eb__2()
			{
				return target.position;
			}

			internal Vector3 _003CDOJump_003Eb__3()
			{
				return target.position;
			}

			internal void _003CDOJump_003Eb__4()
			{
				if (!offsetYSet)
				{
					offsetYSet = true;
					offsetY = (s.isRelative ? endValue.y : (endValue.y - startPosY));
				}
				Vector3 position = target.position;
				position.y += DOVirtual.EasedValue(0f, offsetY, yTween.ElapsedPercentage(), Ease.OutQuad);
				target.MovePosition(position);
			}
		}

		[CompilerGenerated]
		private sealed class _003C_003Ec__DisplayClass7_0
		{
			public Rigidbody target;

			internal Vector3 _003CDOPath_003Eb__0()
			{
				return target.position;
			}
		}

		[CompilerGenerated]
		private sealed class _003C_003Ec__DisplayClass8_0
		{
			public Transform trans;

			public Rigidbody target;

			internal Vector3 _003CDOLocalPath_003Eb__0()
			{
				return trans.localPosition;
			}

			internal void _003CDOLocalPath_003Eb__1(Vector3 x)
			{
				target.MovePosition((trans.parent == null) ? x : trans.parent.TransformPoint(x));
			}
		}

		[CompilerGenerated]
		private sealed class _003C_003Ec__DisplayClass9_0
		{
			public Rigidbody target;

			internal Vector3 _003CDOPath_003Eb__0()
			{
				return target.position;
			}
		}

		[CompilerGenerated]
		private sealed class _003C_003Ec__DisplayClass10_0
		{
			public Transform trans;

			public Rigidbody target;

			internal Vector3 _003CDOLocalPath_003Eb__0()
			{
				return trans.localPosition;
			}

			internal void _003CDOLocalPath_003Eb__1(Vector3 x)
			{
				target.MovePosition((trans.parent == null) ? x : trans.parent.TransformPoint(x));
			}
		}

		public static TweenerCore<Vector3, Vector3, VectorOptions> DOMove(this Rigidbody target, Vector3 endValue, float duration, bool snapping = false)
		{
			_003C_003Ec__DisplayClass0_0 _003C_003Ec__DisplayClass0_ = new _003C_003Ec__DisplayClass0_0();
			_003C_003Ec__DisplayClass0_.target = target;
			TweenerCore<Vector3, Vector3, VectorOptions> tweenerCore = DOTween.To(_003C_003Ec__DisplayClass0_._003CDOMove_003Eb__0, _003C_003Ec__DisplayClass0_.target.MovePosition, endValue, duration);
			tweenerCore.SetOptions(snapping).SetTarget(_003C_003Ec__DisplayClass0_.target);
			return tweenerCore;
		}

		public static TweenerCore<Vector3, Vector3, VectorOptions> DOMoveX(this Rigidbody target, float endValue, float duration, bool snapping = false)
		{
			_003C_003Ec__DisplayClass1_0 _003C_003Ec__DisplayClass1_ = new _003C_003Ec__DisplayClass1_0();
			_003C_003Ec__DisplayClass1_.target = target;
			TweenerCore<Vector3, Vector3, VectorOptions> tweenerCore = DOTween.To(_003C_003Ec__DisplayClass1_._003CDOMoveX_003Eb__0, _003C_003Ec__DisplayClass1_.target.MovePosition, new Vector3(endValue, 0f, 0f), duration);
			tweenerCore.SetOptions(AxisConstraint.X, snapping).SetTarget(_003C_003Ec__DisplayClass1_.target);
			return tweenerCore;
		}

		public static TweenerCore<Vector3, Vector3, VectorOptions> DOMoveY(this Rigidbody target, float endValue, float duration, bool snapping = false)
		{
			_003C_003Ec__DisplayClass2_0 _003C_003Ec__DisplayClass2_ = new _003C_003Ec__DisplayClass2_0();
			_003C_003Ec__DisplayClass2_.target = target;
			TweenerCore<Vector3, Vector3, VectorOptions> tweenerCore = DOTween.To(_003C_003Ec__DisplayClass2_._003CDOMoveY_003Eb__0, _003C_003Ec__DisplayClass2_.target.MovePosition, new Vector3(0f, endValue, 0f), duration);
			tweenerCore.SetOptions(AxisConstraint.Y, snapping).SetTarget(_003C_003Ec__DisplayClass2_.target);
			return tweenerCore;
		}

		public static TweenerCore<Vector3, Vector3, VectorOptions> DOMoveZ(this Rigidbody target, float endValue, float duration, bool snapping = false)
		{
			_003C_003Ec__DisplayClass3_0 _003C_003Ec__DisplayClass3_ = new _003C_003Ec__DisplayClass3_0();
			_003C_003Ec__DisplayClass3_.target = target;
			TweenerCore<Vector3, Vector3, VectorOptions> tweenerCore = DOTween.To(_003C_003Ec__DisplayClass3_._003CDOMoveZ_003Eb__0, _003C_003Ec__DisplayClass3_.target.MovePosition, new Vector3(0f, 0f, endValue), duration);
			tweenerCore.SetOptions(AxisConstraint.Z, snapping).SetTarget(_003C_003Ec__DisplayClass3_.target);
			return tweenerCore;
		}

		public static TweenerCore<Quaternion, Vector3, QuaternionOptions> DORotate(this Rigidbody target, Vector3 endValue, float duration, RotateMode mode = RotateMode.Fast)
		{
			_003C_003Ec__DisplayClass4_0 _003C_003Ec__DisplayClass4_ = new _003C_003Ec__DisplayClass4_0();
			_003C_003Ec__DisplayClass4_.target = target;
			TweenerCore<Quaternion, Vector3, QuaternionOptions> tweenerCore = DOTween.To(_003C_003Ec__DisplayClass4_._003CDORotate_003Eb__0, _003C_003Ec__DisplayClass4_.target.MoveRotation, endValue, duration);
			tweenerCore.SetTarget(_003C_003Ec__DisplayClass4_.target);
			tweenerCore.plugOptions.rotateMode = mode;
			return tweenerCore;
		}

		public static TweenerCore<Quaternion, Vector3, QuaternionOptions> DOLookAt(this Rigidbody target, Vector3 towards, float duration, AxisConstraint axisConstraint = AxisConstraint.None, Vector3? up = null)
		{
			_003C_003Ec__DisplayClass5_0 _003C_003Ec__DisplayClass5_ = new _003C_003Ec__DisplayClass5_0();
			_003C_003Ec__DisplayClass5_.target = target;
			TweenerCore<Quaternion, Vector3, QuaternionOptions> tweenerCore = DOTween.To(_003C_003Ec__DisplayClass5_._003CDOLookAt_003Eb__0, _003C_003Ec__DisplayClass5_.target.MoveRotation, towards, duration).SetTarget(_003C_003Ec__DisplayClass5_.target).SetSpecialStartupMode(SpecialStartupMode.SetLookAt);
			tweenerCore.plugOptions.axisConstraint = axisConstraint;
			tweenerCore.plugOptions.up = ((!up.HasValue) ? Vector3.up : up.Value);
			return tweenerCore;
		}

		public static Sequence DOJump(this Rigidbody target, Vector3 endValue, float jumpPower, int numJumps, float duration, bool snapping = false)
		{
			_003C_003Ec__DisplayClass6_0 _003C_003Ec__DisplayClass6_ = new _003C_003Ec__DisplayClass6_0();
			_003C_003Ec__DisplayClass6_.target = target;
			_003C_003Ec__DisplayClass6_.endValue = endValue;
			if (numJumps < 1)
			{
				numJumps = 1;
			}
			_003C_003Ec__DisplayClass6_.startPosY = 0f;
			_003C_003Ec__DisplayClass6_.offsetY = -1f;
			_003C_003Ec__DisplayClass6_.offsetYSet = false;
			_003C_003Ec__DisplayClass6_.s = DOTween.Sequence();
			_003C_003Ec__DisplayClass6_.yTween = DOTween.To(_003C_003Ec__DisplayClass6_._003CDOJump_003Eb__0, _003C_003Ec__DisplayClass6_.target.MovePosition, new Vector3(0f, jumpPower, 0f), duration / (float)(numJumps * 2)).SetOptions(AxisConstraint.Y, snapping).SetEase(Ease.OutQuad)
				.SetRelative()
				.SetLoops(numJumps * 2, LoopType.Yoyo)
				.OnStart(_003C_003Ec__DisplayClass6_._003CDOJump_003Eb__1);
			_003C_003Ec__DisplayClass6_.s.Append(DOTween.To(_003C_003Ec__DisplayClass6_._003CDOJump_003Eb__2, _003C_003Ec__DisplayClass6_.target.MovePosition, new Vector3(_003C_003Ec__DisplayClass6_.endValue.x, 0f, 0f), duration).SetOptions(AxisConstraint.X, snapping).SetEase(Ease.Linear)).Join(DOTween.To(_003C_003Ec__DisplayClass6_._003CDOJump_003Eb__3, _003C_003Ec__DisplayClass6_.target.MovePosition, new Vector3(0f, 0f, _003C_003Ec__DisplayClass6_.endValue.z), duration).SetOptions(AxisConstraint.Z, snapping).SetEase(Ease.Linear)).Join(_003C_003Ec__DisplayClass6_.yTween)
				.SetTarget(_003C_003Ec__DisplayClass6_.target)
				.SetEase(DOTween.defaultEaseType);
			_003C_003Ec__DisplayClass6_.yTween.OnUpdate(_003C_003Ec__DisplayClass6_._003CDOJump_003Eb__4);
			return _003C_003Ec__DisplayClass6_.s;
		}

		public static TweenerCore<Vector3, Path, PathOptions> DOPath(this Rigidbody target, Vector3[] path, float duration, PathType pathType = PathType.Linear, PathMode pathMode = PathMode.Full3D, int resolution = 10, Color? gizmoColor = null)
		{
			_003C_003Ec__DisplayClass7_0 _003C_003Ec__DisplayClass7_ = new _003C_003Ec__DisplayClass7_0();
			_003C_003Ec__DisplayClass7_.target = target;
			if (resolution < 1)
			{
				resolution = 1;
			}
			TweenerCore<Vector3, Path, PathOptions> tweenerCore = DOTween.To(PathPlugin.Get(), _003C_003Ec__DisplayClass7_._003CDOPath_003Eb__0, _003C_003Ec__DisplayClass7_.target.MovePosition, new Path(pathType, path, resolution, gizmoColor), duration).SetTarget(_003C_003Ec__DisplayClass7_.target).SetUpdate(UpdateType.Fixed);
			tweenerCore.plugOptions.isRigidbody = true;
			tweenerCore.plugOptions.mode = pathMode;
			return tweenerCore;
		}

		public static TweenerCore<Vector3, Path, PathOptions> DOLocalPath(this Rigidbody target, Vector3[] path, float duration, PathType pathType = PathType.Linear, PathMode pathMode = PathMode.Full3D, int resolution = 10, Color? gizmoColor = null)
		{
			_003C_003Ec__DisplayClass8_0 _003C_003Ec__DisplayClass8_ = new _003C_003Ec__DisplayClass8_0();
			_003C_003Ec__DisplayClass8_.target = target;
			if (resolution < 1)
			{
				resolution = 1;
			}
			_003C_003Ec__DisplayClass8_.trans = _003C_003Ec__DisplayClass8_.target.transform;
			TweenerCore<Vector3, Path, PathOptions> tweenerCore = DOTween.To(PathPlugin.Get(), _003C_003Ec__DisplayClass8_._003CDOLocalPath_003Eb__0, _003C_003Ec__DisplayClass8_._003CDOLocalPath_003Eb__1, new Path(pathType, path, resolution, gizmoColor), duration).SetTarget(_003C_003Ec__DisplayClass8_.target).SetUpdate(UpdateType.Fixed);
			tweenerCore.plugOptions.isRigidbody = true;
			tweenerCore.plugOptions.mode = pathMode;
			tweenerCore.plugOptions.useLocalPosition = true;
			return tweenerCore;
		}

		internal static TweenerCore<Vector3, Path, PathOptions> DOPath(this Rigidbody target, Path path, float duration, PathMode pathMode = PathMode.Full3D)
		{
			_003C_003Ec__DisplayClass9_0 _003C_003Ec__DisplayClass9_ = new _003C_003Ec__DisplayClass9_0();
			_003C_003Ec__DisplayClass9_.target = target;
			TweenerCore<Vector3, Path, PathOptions> tweenerCore = DOTween.To(PathPlugin.Get(), _003C_003Ec__DisplayClass9_._003CDOPath_003Eb__0, _003C_003Ec__DisplayClass9_.target.MovePosition, path, duration).SetTarget(_003C_003Ec__DisplayClass9_.target);
			tweenerCore.plugOptions.isRigidbody = true;
			tweenerCore.plugOptions.mode = pathMode;
			return tweenerCore;
		}

		internal static TweenerCore<Vector3, Path, PathOptions> DOLocalPath(this Rigidbody target, Path path, float duration, PathMode pathMode = PathMode.Full3D)
		{
			_003C_003Ec__DisplayClass10_0 _003C_003Ec__DisplayClass10_ = new _003C_003Ec__DisplayClass10_0();
			_003C_003Ec__DisplayClass10_.target = target;
			_003C_003Ec__DisplayClass10_.trans = _003C_003Ec__DisplayClass10_.target.transform;
			TweenerCore<Vector3, Path, PathOptions> tweenerCore = DOTween.To(PathPlugin.Get(), _003C_003Ec__DisplayClass10_._003CDOLocalPath_003Eb__0, _003C_003Ec__DisplayClass10_._003CDOLocalPath_003Eb__1, path, duration).SetTarget(_003C_003Ec__DisplayClass10_.target);
			tweenerCore.plugOptions.isRigidbody = true;
			tweenerCore.plugOptions.mode = pathMode;
			tweenerCore.plugOptions.useLocalPosition = true;
			return tweenerCore;
		}
	}
}
