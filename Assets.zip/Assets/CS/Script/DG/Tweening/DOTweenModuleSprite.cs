using System.Runtime.CompilerServices;
using DG.Tweening.Core;
using DG.Tweening.Plugins.Options;
using UnityEngine;

namespace DG.Tweening
{
	public static class DOTweenModuleSprite
	{
		[CompilerGenerated]
		private sealed class _003C_003Ec__DisplayClass0_0
		{
			public SpriteRenderer target;

			internal Color _003CDOColor_003Eb__0()
			{
				return target.color;
			}

			internal void _003CDOColor_003Eb__1(Color x)
			{
				target.color = x;
			}
		}

		[CompilerGenerated]
		private sealed class _003C_003Ec__DisplayClass1_0
		{
			public SpriteRenderer target;

			internal Color _003CDOFade_003Eb__0()
			{
				return target.color;
			}

			internal void _003CDOFade_003Eb__1(Color x)
			{
				target.color = x;
			}
		}

		[CompilerGenerated]
		private sealed class _003C_003Ec__DisplayClass3_0
		{
			public Color to;

			public SpriteRenderer target;

			internal Color _003CDOBlendableColor_003Eb__0()
			{
				return to;
			}

			internal void _003CDOBlendableColor_003Eb__1(Color x)
			{
				Color color = x - to;
				to = x;
				target.color += color;
			}
		}

		public static TweenerCore<Color, Color, ColorOptions> DOColor(this SpriteRenderer target, Color endValue, float duration)
		{
			_003C_003Ec__DisplayClass0_0 _003C_003Ec__DisplayClass0_ = new _003C_003Ec__DisplayClass0_0();
			_003C_003Ec__DisplayClass0_.target = target;
			TweenerCore<Color, Color, ColorOptions> tweenerCore = DOTween.To(_003C_003Ec__DisplayClass0_._003CDOColor_003Eb__0, _003C_003Ec__DisplayClass0_._003CDOColor_003Eb__1, endValue, duration);
			tweenerCore.SetTarget(_003C_003Ec__DisplayClass0_.target);
			return tweenerCore;
		}

		public static TweenerCore<Color, Color, ColorOptions> DOFade(this SpriteRenderer target, float endValue, float duration)
		{
			_003C_003Ec__DisplayClass1_0 _003C_003Ec__DisplayClass1_ = new _003C_003Ec__DisplayClass1_0();
			_003C_003Ec__DisplayClass1_.target = target;
			TweenerCore<Color, Color, ColorOptions> tweenerCore = DOTween.ToAlpha(_003C_003Ec__DisplayClass1_._003CDOFade_003Eb__0, _003C_003Ec__DisplayClass1_._003CDOFade_003Eb__1, endValue, duration);
			tweenerCore.SetTarget(_003C_003Ec__DisplayClass1_.target);
			return tweenerCore;
		}

		public static Sequence DOGradientColor(this SpriteRenderer target, Gradient gradient, float duration)
		{
			Sequence sequence = DOTween.Sequence();
			GradientColorKey[] colorKeys = gradient.colorKeys;
			int num = colorKeys.Length;
			for (int i = 0; i < num; i++)
			{
				GradientColorKey gradientColorKey = colorKeys[i];
				if (i == 0 && gradientColorKey.time <= 0f)
				{
					target.color = gradientColorKey.color;
					continue;
				}
				float duration2 = ((i == num - 1) ? (duration - sequence.Duration(false)) : (duration * ((i == 0) ? gradientColorKey.time : (gradientColorKey.time - colorKeys[i - 1].time))));
				sequence.Append(target.DOColor(gradientColorKey.color, duration2).SetEase(Ease.Linear));
			}
			return sequence;
		}

		public static Tweener DOBlendableColor(this SpriteRenderer target, Color endValue, float duration)
		{
			_003C_003Ec__DisplayClass3_0 _003C_003Ec__DisplayClass3_ = new _003C_003Ec__DisplayClass3_0();
			_003C_003Ec__DisplayClass3_.target = target;
			endValue -= _003C_003Ec__DisplayClass3_.target.color;
			_003C_003Ec__DisplayClass3_.to = new Color(0f, 0f, 0f, 0f);
			return DOTween.To(_003C_003Ec__DisplayClass3_._003CDOBlendableColor_003Eb__0, _003C_003Ec__DisplayClass3_._003CDOBlendableColor_003Eb__1, endValue, duration).Blendable().SetTarget(_003C_003Ec__DisplayClass3_.target);
		}
	}
}
