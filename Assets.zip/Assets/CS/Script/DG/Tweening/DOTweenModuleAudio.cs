using System.Runtime.CompilerServices;
using DG.Tweening.Core;
using DG.Tweening.Plugins.Options;
using UnityEngine;
using UnityEngine.Audio;

namespace DG.Tweening
{
	public static class DOTweenModuleAudio
	{
		[CompilerGenerated]
		private sealed class _003C_003Ec__DisplayClass0_0
		{
			public AudioSource target;

			internal float _003CDOFade_003Eb__0()
			{
				return target.volume;
			}

			internal void _003CDOFade_003Eb__1(float x)
			{
				target.volume = x;
			}
		}

		[CompilerGenerated]
		private sealed class _003C_003Ec__DisplayClass1_0
		{
			public AudioSource target;

			internal float _003CDOPitch_003Eb__0()
			{
				return target.pitch;
			}

			internal void _003CDOPitch_003Eb__1(float x)
			{
				target.pitch = x;
			}
		}

		[CompilerGenerated]
		private sealed class _003C_003Ec__DisplayClass2_0
		{
			public AudioMixer target;

			public string floatName;

			internal float _003CDOSetFloat_003Eb__0()
			{
				float value;
				target.GetFloat(floatName, out value);
				return value;
			}

			internal void _003CDOSetFloat_003Eb__1(float x)
			{
				target.SetFloat(floatName, x);
			}
		}

		public static TweenerCore<float, float, FloatOptions> DOFade(this AudioSource target, float endValue, float duration)
		{
			_003C_003Ec__DisplayClass0_0 _003C_003Ec__DisplayClass0_ = new _003C_003Ec__DisplayClass0_0();
			_003C_003Ec__DisplayClass0_.target = target;
			if (endValue < 0f)
			{
				endValue = 0f;
			}
			else if (endValue > 1f)
			{
				endValue = 1f;
			}
			TweenerCore<float, float, FloatOptions> tweenerCore = DOTween.To(_003C_003Ec__DisplayClass0_._003CDOFade_003Eb__0, _003C_003Ec__DisplayClass0_._003CDOFade_003Eb__1, endValue, duration);
			tweenerCore.SetTarget(_003C_003Ec__DisplayClass0_.target);
			return tweenerCore;
		}

		public static TweenerCore<float, float, FloatOptions> DOPitch(this AudioSource target, float endValue, float duration)
		{
			_003C_003Ec__DisplayClass1_0 _003C_003Ec__DisplayClass1_ = new _003C_003Ec__DisplayClass1_0();
			_003C_003Ec__DisplayClass1_.target = target;
			TweenerCore<float, float, FloatOptions> tweenerCore = DOTween.To(_003C_003Ec__DisplayClass1_._003CDOPitch_003Eb__0, _003C_003Ec__DisplayClass1_._003CDOPitch_003Eb__1, endValue, duration);
			tweenerCore.SetTarget(_003C_003Ec__DisplayClass1_.target);
			return tweenerCore;
		}

		public static TweenerCore<float, float, FloatOptions> DOSetFloat(this AudioMixer target, string floatName, float endValue, float duration)
		{
			_003C_003Ec__DisplayClass2_0 _003C_003Ec__DisplayClass2_ = new _003C_003Ec__DisplayClass2_0();
			_003C_003Ec__DisplayClass2_.target = target;
			_003C_003Ec__DisplayClass2_.floatName = floatName;
			TweenerCore<float, float, FloatOptions> tweenerCore = DOTween.To(_003C_003Ec__DisplayClass2_._003CDOSetFloat_003Eb__0, _003C_003Ec__DisplayClass2_._003CDOSetFloat_003Eb__1, endValue, duration);
			tweenerCore.SetTarget(_003C_003Ec__DisplayClass2_.target);
			return tweenerCore;
		}

		public static int DOComplete(this AudioMixer target, bool withCallbacks = false)
		{
			return DOTween.Complete(target, withCallbacks);
		}

		public static int DOKill(this AudioMixer target, bool complete = false)
		{
			return DOTween.Kill(target, complete);
		}

		public static int DOFlip(this AudioMixer target)
		{
			return DOTween.Flip(target);
		}

		public static int DOGoto(this AudioMixer target, float to, bool andPlay = false)
		{
			return DOTween.Goto(target, to, andPlay);
		}

		public static int DOPause(this AudioMixer target)
		{
			return DOTween.Pause(target);
		}

		public static int DOPlay(this AudioMixer target)
		{
			return DOTween.Play(target);
		}

		public static int DOPlayBackwards(this AudioMixer target)
		{
			return DOTween.PlayBackwards(target);
		}

		public static int DOPlayForward(this AudioMixer target)
		{
			return DOTween.PlayForward(target);
		}

		public static int DORestart(this AudioMixer target)
		{
			return DOTween.Restart(target);
		}

		public static int DORewind(this AudioMixer target)
		{
			return DOTween.Rewind(target);
		}

		public static int DOSmoothRewind(this AudioMixer target)
		{
			return DOTween.SmoothRewind(target);
		}

		public static int DOTogglePause(this AudioMixer target)
		{
			return DOTween.TogglePause(target);
		}
	}
}
