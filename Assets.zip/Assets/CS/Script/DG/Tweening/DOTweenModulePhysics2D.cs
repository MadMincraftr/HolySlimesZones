using System.Runtime.CompilerServices;
using DG.Tweening.Core;
using DG.Tweening.Plugins.Options;
using UnityEngine;

namespace DG.Tweening
{
	public static class DOTweenModulePhysics2D
	{
		[CompilerGenerated]
		private sealed class _003C_003Ec__DisplayClass0_0
		{
			public Rigidbody2D target;

			internal Vector2 _003CDOMove_003Eb__0()
			{
				return target.position;
			}
		}

		[CompilerGenerated]
		private sealed class _003C_003Ec__DisplayClass1_0
		{
			public Rigidbody2D target;

			internal Vector2 _003CDOMoveX_003Eb__0()
			{
				return target.position;
			}
		}

		[CompilerGenerated]
		private sealed class _003C_003Ec__DisplayClass2_0
		{
			public Rigidbody2D target;

			internal Vector2 _003CDOMoveY_003Eb__0()
			{
				return target.position;
			}
		}

		[CompilerGenerated]
		private sealed class _003C_003Ec__DisplayClass3_0
		{
			public Rigidbody2D target;

			internal float _003CDORotate_003Eb__0()
			{
				return target.rotation;
			}
		}

		[CompilerGenerated]
		private sealed class _003C_003Ec__DisplayClass4_0
		{
			public Rigidbody2D target;

			public float startPosY;

			public bool offsetYSet;

			public float offsetY;

			public Sequence s;

			public Vector2 endValue;

			public Tween yTween;

			internal Vector2 _003CDOJump_003Eb__0()
			{
				return target.position;
			}

			internal void _003CDOJump_003Eb__1(Vector2 x)
			{
				target.position = x;
			}

			internal void _003CDOJump_003Eb__2()
			{
				startPosY = target.position.y;
			}

			internal Vector2 _003CDOJump_003Eb__3()
			{
				return target.position;
			}

			internal void _003CDOJump_003Eb__4(Vector2 x)
			{
				target.position = x;
			}

			internal void _003CDOJump_003Eb__5()
			{
				if (!offsetYSet)
				{
					offsetYSet = true;
					offsetY = (s.isRelative ? endValue.y : (endValue.y - startPosY));
				}
				Vector3 vector = target.position;
				vector.y += DOVirtual.EasedValue(0f, offsetY, yTween.ElapsedPercentage(), Ease.OutQuad);
				target.MovePosition(vector);
			}
		}

		public static TweenerCore<Vector2, Vector2, VectorOptions> DOMove(this Rigidbody2D target, Vector2 endValue, float duration, bool snapping = false)
		{
			_003C_003Ec__DisplayClass0_0 _003C_003Ec__DisplayClass0_ = new _003C_003Ec__DisplayClass0_0();
			_003C_003Ec__DisplayClass0_.target = target;
			TweenerCore<Vector2, Vector2, VectorOptions> tweenerCore = DOTween.To(_003C_003Ec__DisplayClass0_._003CDOMove_003Eb__0, _003C_003Ec__DisplayClass0_.target.MovePosition, endValue, duration);
			tweenerCore.SetOptions(snapping).SetTarget(_003C_003Ec__DisplayClass0_.target);
			return tweenerCore;
		}

		public static TweenerCore<Vector2, Vector2, VectorOptions> DOMoveX(this Rigidbody2D target, float endValue, float duration, bool snapping = false)
		{
			_003C_003Ec__DisplayClass1_0 _003C_003Ec__DisplayClass1_ = new _003C_003Ec__DisplayClass1_0();
			_003C_003Ec__DisplayClass1_.target = target;
			TweenerCore<Vector2, Vector2, VectorOptions> tweenerCore = DOTween.To(_003C_003Ec__DisplayClass1_._003CDOMoveX_003Eb__0, _003C_003Ec__DisplayClass1_.target.MovePosition, new Vector2(endValue, 0f), duration);
			tweenerCore.SetOptions(AxisConstraint.X, snapping).SetTarget(_003C_003Ec__DisplayClass1_.target);
			return tweenerCore;
		}

		public static TweenerCore<Vector2, Vector2, VectorOptions> DOMoveY(this Rigidbody2D target, float endValue, float duration, bool snapping = false)
		{
			_003C_003Ec__DisplayClass2_0 _003C_003Ec__DisplayClass2_ = new _003C_003Ec__DisplayClass2_0();
			_003C_003Ec__DisplayClass2_.target = target;
			TweenerCore<Vector2, Vector2, VectorOptions> tweenerCore = DOTween.To(_003C_003Ec__DisplayClass2_._003CDOMoveY_003Eb__0, _003C_003Ec__DisplayClass2_.target.MovePosition, new Vector2(0f, endValue), duration);
			tweenerCore.SetOptions(AxisConstraint.Y, snapping).SetTarget(_003C_003Ec__DisplayClass2_.target);
			return tweenerCore;
		}

		public static TweenerCore<float, float, FloatOptions> DORotate(this Rigidbody2D target, float endValue, float duration)
		{
			_003C_003Ec__DisplayClass3_0 _003C_003Ec__DisplayClass3_ = new _003C_003Ec__DisplayClass3_0();
			_003C_003Ec__DisplayClass3_.target = target;
			TweenerCore<float, float, FloatOptions> tweenerCore = DOTween.To(_003C_003Ec__DisplayClass3_._003CDORotate_003Eb__0, _003C_003Ec__DisplayClass3_.target.MoveRotation, endValue, duration);
			tweenerCore.SetTarget(_003C_003Ec__DisplayClass3_.target);
			return tweenerCore;
		}

		public static Sequence DOJump(this Rigidbody2D target, Vector2 endValue, float jumpPower, int numJumps, float duration, bool snapping = false)
		{
			_003C_003Ec__DisplayClass4_0 _003C_003Ec__DisplayClass4_ = new _003C_003Ec__DisplayClass4_0();
			_003C_003Ec__DisplayClass4_.target = target;
			_003C_003Ec__DisplayClass4_.endValue = endValue;
			if (numJumps < 1)
			{
				numJumps = 1;
			}
			_003C_003Ec__DisplayClass4_.startPosY = 0f;
			_003C_003Ec__DisplayClass4_.offsetY = -1f;
			_003C_003Ec__DisplayClass4_.offsetYSet = false;
			_003C_003Ec__DisplayClass4_.s = DOTween.Sequence();
			_003C_003Ec__DisplayClass4_.yTween = DOTween.To(_003C_003Ec__DisplayClass4_._003CDOJump_003Eb__0, _003C_003Ec__DisplayClass4_._003CDOJump_003Eb__1, new Vector2(0f, jumpPower), duration / (float)(numJumps * 2)).SetOptions(AxisConstraint.Y, snapping).SetEase(Ease.OutQuad)
				.SetRelative()
				.SetLoops(numJumps * 2, LoopType.Yoyo)
				.OnStart(_003C_003Ec__DisplayClass4_._003CDOJump_003Eb__2);
			_003C_003Ec__DisplayClass4_.s.Append(DOTween.To(_003C_003Ec__DisplayClass4_._003CDOJump_003Eb__3, _003C_003Ec__DisplayClass4_._003CDOJump_003Eb__4, new Vector2(_003C_003Ec__DisplayClass4_.endValue.x, 0f), duration).SetOptions(AxisConstraint.X, snapping).SetEase(Ease.Linear)).Join(_003C_003Ec__DisplayClass4_.yTween).SetTarget(_003C_003Ec__DisplayClass4_.target)
				.SetEase(DOTween.defaultEaseType);
			_003C_003Ec__DisplayClass4_.yTween.OnUpdate(_003C_003Ec__DisplayClass4_._003CDOJump_003Eb__5);
			return _003C_003Ec__DisplayClass4_.s;
		}
	}
}
