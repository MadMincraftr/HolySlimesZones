using System.Runtime.CompilerServices;
using DG.Tweening.Core;
using DG.Tweening.Core.Enums;
using DG.Tweening.Plugins.Options;
using UnityEngine;
using UnityEngine.UI;

namespace DG.Tweening
{
	public static class DOTweenModuleUI
	{
		public static class Utils
		{
			public static Vector2 SwitchToRectTransform(RectTransform from, RectTransform to)
			{
				Vector2 vector = new Vector2(from.rect.width * 0.5f + from.rect.xMin, from.rect.height * 0.5f + from.rect.yMin);
				Vector2 screenPoint = RectTransformUtility.WorldToScreenPoint(null, from.position);
				screenPoint += vector;
				Vector2 localPoint;
				RectTransformUtility.ScreenPointToLocalPointInRectangle(to, screenPoint, null, out localPoint);
				Vector2 vector2 = new Vector2(to.rect.width * 0.5f + to.rect.xMin, to.rect.height * 0.5f + to.rect.yMin);
				return to.anchoredPosition + localPoint - vector2;
			}
		}

		[CompilerGenerated]
		private sealed class _003C_003Ec__DisplayClass0_0
		{
			public CanvasGroup target;

			internal float _003CDOFade_003Eb__0()
			{
				return target.alpha;
			}

			internal void _003CDOFade_003Eb__1(float x)
			{
				target.alpha = x;
			}
		}

		[CompilerGenerated]
		private sealed class _003C_003Ec__DisplayClass1_0
		{
			public Graphic target;

			internal Color _003CDOColor_003Eb__0()
			{
				return target.color;
			}

			internal void _003CDOColor_003Eb__1(Color x)
			{
				target.color = x;
			}
		}

		[CompilerGenerated]
		private sealed class _003C_003Ec__DisplayClass2_0
		{
			public Graphic target;

			internal Color _003CDOFade_003Eb__0()
			{
				return target.color;
			}

			internal void _003CDOFade_003Eb__1(Color x)
			{
				target.color = x;
			}
		}

		[CompilerGenerated]
		private sealed class _003C_003Ec__DisplayClass3_0
		{
			public Image target;

			internal Color _003CDOColor_003Eb__0()
			{
				return target.color;
			}

			internal void _003CDOColor_003Eb__1(Color x)
			{
				target.color = x;
			}
		}

		[CompilerGenerated]
		private sealed class _003C_003Ec__DisplayClass4_0
		{
			public Image target;

			internal Color _003CDOFade_003Eb__0()
			{
				return target.color;
			}

			internal void _003CDOFade_003Eb__1(Color x)
			{
				target.color = x;
			}
		}

		[CompilerGenerated]
		private sealed class _003C_003Ec__DisplayClass5_0
		{
			public Image target;

			internal float _003CDOFillAmount_003Eb__0()
			{
				return target.fillAmount;
			}

			internal void _003CDOFillAmount_003Eb__1(float x)
			{
				target.fillAmount = x;
			}
		}

		[CompilerGenerated]
		private sealed class _003C_003Ec__DisplayClass7_0
		{
			public LayoutElement target;

			internal Vector2 _003CDOFlexibleSize_003Eb__0()
			{
				return new Vector2(target.flexibleWidth, target.flexibleHeight);
			}

			internal void _003CDOFlexibleSize_003Eb__1(Vector2 x)
			{
				target.flexibleWidth = x.x;
				target.flexibleHeight = x.y;
			}
		}

		[CompilerGenerated]
		private sealed class _003C_003Ec__DisplayClass8_0
		{
			public LayoutElement target;

			internal Vector2 _003CDOMinSize_003Eb__0()
			{
				return new Vector2(target.minWidth, target.minHeight);
			}

			internal void _003CDOMinSize_003Eb__1(Vector2 x)
			{
				target.minWidth = x.x;
				target.minHeight = x.y;
			}
		}

		[CompilerGenerated]
		private sealed class _003C_003Ec__DisplayClass9_0
		{
			public LayoutElement target;

			internal Vector2 _003CDOPreferredSize_003Eb__0()
			{
				return new Vector2(target.preferredWidth, target.preferredHeight);
			}

			internal void _003CDOPreferredSize_003Eb__1(Vector2 x)
			{
				target.preferredWidth = x.x;
				target.preferredHeight = x.y;
			}
		}

		[CompilerGenerated]
		private sealed class _003C_003Ec__DisplayClass10_0
		{
			public Outline target;

			internal Color _003CDOColor_003Eb__0()
			{
				return target.effectColor;
			}

			internal void _003CDOColor_003Eb__1(Color x)
			{
				target.effectColor = x;
			}
		}

		[CompilerGenerated]
		private sealed class _003C_003Ec__DisplayClass11_0
		{
			public Outline target;

			internal Color _003CDOFade_003Eb__0()
			{
				return target.effectColor;
			}

			internal void _003CDOFade_003Eb__1(Color x)
			{
				target.effectColor = x;
			}
		}

		[CompilerGenerated]
		private sealed class _003C_003Ec__DisplayClass12_0
		{
			public Outline target;

			internal Vector2 _003CDOScale_003Eb__0()
			{
				return target.effectDistance;
			}

			internal void _003CDOScale_003Eb__1(Vector2 x)
			{
				target.effectDistance = x;
			}
		}

		[CompilerGenerated]
		private sealed class _003C_003Ec__DisplayClass13_0
		{
			public RectTransform target;

			internal Vector2 _003CDOAnchorPos_003Eb__0()
			{
				return target.anchoredPosition;
			}

			internal void _003CDOAnchorPos_003Eb__1(Vector2 x)
			{
				target.anchoredPosition = x;
			}
		}

		[CompilerGenerated]
		private sealed class _003C_003Ec__DisplayClass14_0
		{
			public RectTransform target;

			internal Vector2 _003CDOAnchorPosX_003Eb__0()
			{
				return target.anchoredPosition;
			}

			internal void _003CDOAnchorPosX_003Eb__1(Vector2 x)
			{
				target.anchoredPosition = x;
			}
		}

		[CompilerGenerated]
		private sealed class _003C_003Ec__DisplayClass15_0
		{
			public RectTransform target;

			internal Vector2 _003CDOAnchorPosY_003Eb__0()
			{
				return target.anchoredPosition;
			}

			internal void _003CDOAnchorPosY_003Eb__1(Vector2 x)
			{
				target.anchoredPosition = x;
			}
		}

		[CompilerGenerated]
		private sealed class _003C_003Ec__DisplayClass16_0
		{
			public RectTransform target;

			internal Vector3 _003CDOAnchorPos3D_003Eb__0()
			{
				return target.anchoredPosition3D;
			}

			internal void _003CDOAnchorPos3D_003Eb__1(Vector3 x)
			{
				target.anchoredPosition3D = x;
			}
		}

		[CompilerGenerated]
		private sealed class _003C_003Ec__DisplayClass17_0
		{
			public RectTransform target;

			internal Vector3 _003CDOAnchorPos3DX_003Eb__0()
			{
				return target.anchoredPosition3D;
			}

			internal void _003CDOAnchorPos3DX_003Eb__1(Vector3 x)
			{
				target.anchoredPosition3D = x;
			}
		}

		[CompilerGenerated]
		private sealed class _003C_003Ec__DisplayClass18_0
		{
			public RectTransform target;

			internal Vector3 _003CDOAnchorPos3DY_003Eb__0()
			{
				return target.anchoredPosition3D;
			}

			internal void _003CDOAnchorPos3DY_003Eb__1(Vector3 x)
			{
				target.anchoredPosition3D = x;
			}
		}

		[CompilerGenerated]
		private sealed class _003C_003Ec__DisplayClass19_0
		{
			public RectTransform target;

			internal Vector3 _003CDOAnchorPos3DZ_003Eb__0()
			{
				return target.anchoredPosition3D;
			}

			internal void _003CDOAnchorPos3DZ_003Eb__1(Vector3 x)
			{
				target.anchoredPosition3D = x;
			}
		}

		[CompilerGenerated]
		private sealed class _003C_003Ec__DisplayClass20_0
		{
			public RectTransform target;

			internal Vector2 _003CDOAnchorMax_003Eb__0()
			{
				return target.anchorMax;
			}

			internal void _003CDOAnchorMax_003Eb__1(Vector2 x)
			{
				target.anchorMax = x;
			}
		}

		[CompilerGenerated]
		private sealed class _003C_003Ec__DisplayClass21_0
		{
			public RectTransform target;

			internal Vector2 _003CDOAnchorMin_003Eb__0()
			{
				return target.anchorMin;
			}

			internal void _003CDOAnchorMin_003Eb__1(Vector2 x)
			{
				target.anchorMin = x;
			}
		}

		[CompilerGenerated]
		private sealed class _003C_003Ec__DisplayClass22_0
		{
			public RectTransform target;

			internal Vector2 _003CDOPivot_003Eb__0()
			{
				return target.pivot;
			}

			internal void _003CDOPivot_003Eb__1(Vector2 x)
			{
				target.pivot = x;
			}
		}

		[CompilerGenerated]
		private sealed class _003C_003Ec__DisplayClass23_0
		{
			public RectTransform target;

			internal Vector2 _003CDOPivotX_003Eb__0()
			{
				return target.pivot;
			}

			internal void _003CDOPivotX_003Eb__1(Vector2 x)
			{
				target.pivot = x;
			}
		}

		[CompilerGenerated]
		private sealed class _003C_003Ec__DisplayClass24_0
		{
			public RectTransform target;

			internal Vector2 _003CDOPivotY_003Eb__0()
			{
				return target.pivot;
			}

			internal void _003CDOPivotY_003Eb__1(Vector2 x)
			{
				target.pivot = x;
			}
		}

		[CompilerGenerated]
		private sealed class _003C_003Ec__DisplayClass25_0
		{
			public RectTransform target;

			internal Vector2 _003CDOSizeDelta_003Eb__0()
			{
				return target.sizeDelta;
			}

			internal void _003CDOSizeDelta_003Eb__1(Vector2 x)
			{
				target.sizeDelta = x;
			}
		}

		[CompilerGenerated]
		private sealed class _003C_003Ec__DisplayClass26_0
		{
			public RectTransform target;

			internal Vector3 _003CDOPunchAnchorPos_003Eb__0()
			{
				return target.anchoredPosition;
			}

			internal void _003CDOPunchAnchorPos_003Eb__1(Vector3 x)
			{
				target.anchoredPosition = x;
			}
		}

		[CompilerGenerated]
		private sealed class _003C_003Ec__DisplayClass27_0
		{
			public RectTransform target;

			internal Vector3 _003CDOShakeAnchorPos_003Eb__0()
			{
				return target.anchoredPosition;
			}

			internal void _003CDOShakeAnchorPos_003Eb__1(Vector3 x)
			{
				target.anchoredPosition = x;
			}
		}

		[CompilerGenerated]
		private sealed class _003C_003Ec__DisplayClass28_0
		{
			public RectTransform target;

			internal Vector3 _003CDOShakeAnchorPos_003Eb__0()
			{
				return target.anchoredPosition;
			}

			internal void _003CDOShakeAnchorPos_003Eb__1(Vector3 x)
			{
				target.anchoredPosition = x;
			}
		}

		[CompilerGenerated]
		private sealed class _003C_003Ec__DisplayClass29_0
		{
			public RectTransform target;

			public float startPosY;

			public bool offsetYSet;

			public float offsetY;

			public Sequence s;

			public Vector2 endValue;

			internal Vector2 _003CDOJumpAnchorPos_003Eb__0()
			{
				return target.anchoredPosition;
			}

			internal void _003CDOJumpAnchorPos_003Eb__1(Vector2 x)
			{
				target.anchoredPosition = x;
			}

			internal void _003CDOJumpAnchorPos_003Eb__2()
			{
				startPosY = target.anchoredPosition.y;
			}

			internal Vector2 _003CDOJumpAnchorPos_003Eb__3()
			{
				return target.anchoredPosition;
			}

			internal void _003CDOJumpAnchorPos_003Eb__4(Vector2 x)
			{
				target.anchoredPosition = x;
			}

			internal void _003CDOJumpAnchorPos_003Eb__5()
			{
				if (!offsetYSet)
				{
					offsetYSet = true;
					offsetY = (s.isRelative ? endValue.y : (endValue.y - startPosY));
				}
				Vector2 anchoredPosition = target.anchoredPosition;
				anchoredPosition.y += DOVirtual.EasedValue(0f, offsetY, s.ElapsedDirectionalPercentage(), Ease.OutQuad);
				target.anchoredPosition = anchoredPosition;
			}
		}

		[CompilerGenerated]
		private sealed class _003C_003Ec__DisplayClass30_0
		{
			public ScrollRect target;

			internal Vector2 _003CDONormalizedPos_003Eb__0()
			{
				return new Vector2(target.horizontalNormalizedPosition, target.verticalNormalizedPosition);
			}

			internal void _003CDONormalizedPos_003Eb__1(Vector2 x)
			{
				target.horizontalNormalizedPosition = x.x;
				target.verticalNormalizedPosition = x.y;
			}
		}

		[CompilerGenerated]
		private sealed class _003C_003Ec__DisplayClass31_0
		{
			public ScrollRect target;

			internal float _003CDOHorizontalNormalizedPos_003Eb__0()
			{
				return target.horizontalNormalizedPosition;
			}

			internal void _003CDOHorizontalNormalizedPos_003Eb__1(float x)
			{
				target.horizontalNormalizedPosition = x;
			}
		}

		[CompilerGenerated]
		private sealed class _003C_003Ec__DisplayClass32_0
		{
			public ScrollRect target;

			internal float _003CDOVerticalNormalizedPos_003Eb__0()
			{
				return target.verticalNormalizedPosition;
			}

			internal void _003CDOVerticalNormalizedPos_003Eb__1(float x)
			{
				target.verticalNormalizedPosition = x;
			}
		}

		[CompilerGenerated]
		private sealed class _003C_003Ec__DisplayClass33_0
		{
			public Slider target;

			internal float _003CDOValue_003Eb__0()
			{
				return target.value;
			}

			internal void _003CDOValue_003Eb__1(float x)
			{
				target.value = x;
			}
		}

		[CompilerGenerated]
		private sealed class _003C_003Ec__DisplayClass34_0
		{
			public Text target;

			internal Color _003CDOColor_003Eb__0()
			{
				return target.color;
			}

			internal void _003CDOColor_003Eb__1(Color x)
			{
				target.color = x;
			}
		}

		[CompilerGenerated]
		private sealed class _003C_003Ec__DisplayClass35_0
		{
			public Text target;

			internal Color _003CDOFade_003Eb__0()
			{
				return target.color;
			}

			internal void _003CDOFade_003Eb__1(Color x)
			{
				target.color = x;
			}
		}

		[CompilerGenerated]
		private sealed class _003C_003Ec__DisplayClass36_0
		{
			public Text target;

			internal string _003CDOText_003Eb__0()
			{
				return target.text;
			}

			internal void _003CDOText_003Eb__1(string x)
			{
				target.text = x;
			}
		}

		[CompilerGenerated]
		private sealed class _003C_003Ec__DisplayClass37_0
		{
			public Color to;

			public Graphic target;

			internal Color _003CDOBlendableColor_003Eb__0()
			{
				return to;
			}

			internal void _003CDOBlendableColor_003Eb__1(Color x)
			{
				Color color = x - to;
				to = x;
				target.color += color;
			}
		}

		[CompilerGenerated]
		private sealed class _003C_003Ec__DisplayClass38_0
		{
			public Color to;

			public Image target;

			internal Color _003CDOBlendableColor_003Eb__0()
			{
				return to;
			}

			internal void _003CDOBlendableColor_003Eb__1(Color x)
			{
				Color color = x - to;
				to = x;
				target.color += color;
			}
		}

		[CompilerGenerated]
		private sealed class _003C_003Ec__DisplayClass39_0
		{
			public Color to;

			public Text target;

			internal Color _003CDOBlendableColor_003Eb__0()
			{
				return to;
			}

			internal void _003CDOBlendableColor_003Eb__1(Color x)
			{
				Color color = x - to;
				to = x;
				target.color += color;
			}
		}

		public static TweenerCore<float, float, FloatOptions> DOFade(this CanvasGroup target, float endValue, float duration)
		{
			_003C_003Ec__DisplayClass0_0 _003C_003Ec__DisplayClass0_ = new _003C_003Ec__DisplayClass0_0();
			_003C_003Ec__DisplayClass0_.target = target;
			TweenerCore<float, float, FloatOptions> tweenerCore = DOTween.To(_003C_003Ec__DisplayClass0_._003CDOFade_003Eb__0, _003C_003Ec__DisplayClass0_._003CDOFade_003Eb__1, endValue, duration);
			tweenerCore.SetTarget(_003C_003Ec__DisplayClass0_.target);
			return tweenerCore;
		}

		public static TweenerCore<Color, Color, ColorOptions> DOColor(this Graphic target, Color endValue, float duration)
		{
			_003C_003Ec__DisplayClass1_0 _003C_003Ec__DisplayClass1_ = new _003C_003Ec__DisplayClass1_0();
			_003C_003Ec__DisplayClass1_.target = target;
			TweenerCore<Color, Color, ColorOptions> tweenerCore = DOTween.To(_003C_003Ec__DisplayClass1_._003CDOColor_003Eb__0, _003C_003Ec__DisplayClass1_._003CDOColor_003Eb__1, endValue, duration);
			tweenerCore.SetTarget(_003C_003Ec__DisplayClass1_.target);
			return tweenerCore;
		}

		public static TweenerCore<Color, Color, ColorOptions> DOFade(this Graphic target, float endValue, float duration)
		{
			_003C_003Ec__DisplayClass2_0 _003C_003Ec__DisplayClass2_ = new _003C_003Ec__DisplayClass2_0();
			_003C_003Ec__DisplayClass2_.target = target;
			TweenerCore<Color, Color, ColorOptions> tweenerCore = DOTween.ToAlpha(_003C_003Ec__DisplayClass2_._003CDOFade_003Eb__0, _003C_003Ec__DisplayClass2_._003CDOFade_003Eb__1, endValue, duration);
			tweenerCore.SetTarget(_003C_003Ec__DisplayClass2_.target);
			return tweenerCore;
		}

		public static TweenerCore<Color, Color, ColorOptions> DOColor(this Image target, Color endValue, float duration)
		{
			_003C_003Ec__DisplayClass3_0 _003C_003Ec__DisplayClass3_ = new _003C_003Ec__DisplayClass3_0();
			_003C_003Ec__DisplayClass3_.target = target;
			TweenerCore<Color, Color, ColorOptions> tweenerCore = DOTween.To(_003C_003Ec__DisplayClass3_._003CDOColor_003Eb__0, _003C_003Ec__DisplayClass3_._003CDOColor_003Eb__1, endValue, duration);
			tweenerCore.SetTarget(_003C_003Ec__DisplayClass3_.target);
			return tweenerCore;
		}

		public static TweenerCore<Color, Color, ColorOptions> DOFade(this Image target, float endValue, float duration)
		{
			_003C_003Ec__DisplayClass4_0 _003C_003Ec__DisplayClass4_ = new _003C_003Ec__DisplayClass4_0();
			_003C_003Ec__DisplayClass4_.target = target;
			TweenerCore<Color, Color, ColorOptions> tweenerCore = DOTween.ToAlpha(_003C_003Ec__DisplayClass4_._003CDOFade_003Eb__0, _003C_003Ec__DisplayClass4_._003CDOFade_003Eb__1, endValue, duration);
			tweenerCore.SetTarget(_003C_003Ec__DisplayClass4_.target);
			return tweenerCore;
		}

		public static TweenerCore<float, float, FloatOptions> DOFillAmount(this Image target, float endValue, float duration)
		{
			_003C_003Ec__DisplayClass5_0 _003C_003Ec__DisplayClass5_ = new _003C_003Ec__DisplayClass5_0();
			_003C_003Ec__DisplayClass5_.target = target;
			if (endValue > 1f)
			{
				endValue = 1f;
			}
			else if (endValue < 0f)
			{
				endValue = 0f;
			}
			TweenerCore<float, float, FloatOptions> tweenerCore = DOTween.To(_003C_003Ec__DisplayClass5_._003CDOFillAmount_003Eb__0, _003C_003Ec__DisplayClass5_._003CDOFillAmount_003Eb__1, endValue, duration);
			tweenerCore.SetTarget(_003C_003Ec__DisplayClass5_.target);
			return tweenerCore;
		}

		public static Sequence DOGradientColor(this Image target, Gradient gradient, float duration)
		{
			Sequence sequence = DOTween.Sequence();
			GradientColorKey[] colorKeys = gradient.colorKeys;
			int num = colorKeys.Length;
			for (int i = 0; i < num; i++)
			{
				GradientColorKey gradientColorKey = colorKeys[i];
				if (i == 0 && gradientColorKey.time <= 0f)
				{
					target.color = gradientColorKey.color;
					continue;
				}
				float duration2 = ((i == num - 1) ? (duration - sequence.Duration(false)) : (duration * ((i == 0) ? gradientColorKey.time : (gradientColorKey.time - colorKeys[i - 1].time))));
				sequence.Append(target.DOColor(gradientColorKey.color, duration2).SetEase(Ease.Linear));
			}
			return sequence;
		}

		public static TweenerCore<Vector2, Vector2, VectorOptions> DOFlexibleSize(this LayoutElement target, Vector2 endValue, float duration, bool snapping = false)
		{
			_003C_003Ec__DisplayClass7_0 _003C_003Ec__DisplayClass7_ = new _003C_003Ec__DisplayClass7_0();
			_003C_003Ec__DisplayClass7_.target = target;
			TweenerCore<Vector2, Vector2, VectorOptions> tweenerCore = DOTween.To(_003C_003Ec__DisplayClass7_._003CDOFlexibleSize_003Eb__0, _003C_003Ec__DisplayClass7_._003CDOFlexibleSize_003Eb__1, endValue, duration);
			tweenerCore.SetOptions(snapping).SetTarget(_003C_003Ec__DisplayClass7_.target);
			return tweenerCore;
		}

		public static TweenerCore<Vector2, Vector2, VectorOptions> DOMinSize(this LayoutElement target, Vector2 endValue, float duration, bool snapping = false)
		{
			_003C_003Ec__DisplayClass8_0 _003C_003Ec__DisplayClass8_ = new _003C_003Ec__DisplayClass8_0();
			_003C_003Ec__DisplayClass8_.target = target;
			TweenerCore<Vector2, Vector2, VectorOptions> tweenerCore = DOTween.To(_003C_003Ec__DisplayClass8_._003CDOMinSize_003Eb__0, _003C_003Ec__DisplayClass8_._003CDOMinSize_003Eb__1, endValue, duration);
			tweenerCore.SetOptions(snapping).SetTarget(_003C_003Ec__DisplayClass8_.target);
			return tweenerCore;
		}

		public static TweenerCore<Vector2, Vector2, VectorOptions> DOPreferredSize(this LayoutElement target, Vector2 endValue, float duration, bool snapping = false)
		{
			_003C_003Ec__DisplayClass9_0 _003C_003Ec__DisplayClass9_ = new _003C_003Ec__DisplayClass9_0();
			_003C_003Ec__DisplayClass9_.target = target;
			TweenerCore<Vector2, Vector2, VectorOptions> tweenerCore = DOTween.To(_003C_003Ec__DisplayClass9_._003CDOPreferredSize_003Eb__0, _003C_003Ec__DisplayClass9_._003CDOPreferredSize_003Eb__1, endValue, duration);
			tweenerCore.SetOptions(snapping).SetTarget(_003C_003Ec__DisplayClass9_.target);
			return tweenerCore;
		}

		public static TweenerCore<Color, Color, ColorOptions> DOColor(this Outline target, Color endValue, float duration)
		{
			_003C_003Ec__DisplayClass10_0 _003C_003Ec__DisplayClass10_ = new _003C_003Ec__DisplayClass10_0();
			_003C_003Ec__DisplayClass10_.target = target;
			TweenerCore<Color, Color, ColorOptions> tweenerCore = DOTween.To(_003C_003Ec__DisplayClass10_._003CDOColor_003Eb__0, _003C_003Ec__DisplayClass10_._003CDOColor_003Eb__1, endValue, duration);
			tweenerCore.SetTarget(_003C_003Ec__DisplayClass10_.target);
			return tweenerCore;
		}

		public static TweenerCore<Color, Color, ColorOptions> DOFade(this Outline target, float endValue, float duration)
		{
			_003C_003Ec__DisplayClass11_0 _003C_003Ec__DisplayClass11_ = new _003C_003Ec__DisplayClass11_0();
			_003C_003Ec__DisplayClass11_.target = target;
			TweenerCore<Color, Color, ColorOptions> tweenerCore = DOTween.ToAlpha(_003C_003Ec__DisplayClass11_._003CDOFade_003Eb__0, _003C_003Ec__DisplayClass11_._003CDOFade_003Eb__1, endValue, duration);
			tweenerCore.SetTarget(_003C_003Ec__DisplayClass11_.target);
			return tweenerCore;
		}

		public static TweenerCore<Vector2, Vector2, VectorOptions> DOScale(this Outline target, Vector2 endValue, float duration)
		{
			_003C_003Ec__DisplayClass12_0 _003C_003Ec__DisplayClass12_ = new _003C_003Ec__DisplayClass12_0();
			_003C_003Ec__DisplayClass12_.target = target;
			TweenerCore<Vector2, Vector2, VectorOptions> tweenerCore = DOTween.To(_003C_003Ec__DisplayClass12_._003CDOScale_003Eb__0, _003C_003Ec__DisplayClass12_._003CDOScale_003Eb__1, endValue, duration);
			tweenerCore.SetTarget(_003C_003Ec__DisplayClass12_.target);
			return tweenerCore;
		}

		public static TweenerCore<Vector2, Vector2, VectorOptions> DOAnchorPos(this RectTransform target, Vector2 endValue, float duration, bool snapping = false)
		{
			_003C_003Ec__DisplayClass13_0 _003C_003Ec__DisplayClass13_ = new _003C_003Ec__DisplayClass13_0();
			_003C_003Ec__DisplayClass13_.target = target;
			TweenerCore<Vector2, Vector2, VectorOptions> tweenerCore = DOTween.To(_003C_003Ec__DisplayClass13_._003CDOAnchorPos_003Eb__0, _003C_003Ec__DisplayClass13_._003CDOAnchorPos_003Eb__1, endValue, duration);
			tweenerCore.SetOptions(snapping).SetTarget(_003C_003Ec__DisplayClass13_.target);
			return tweenerCore;
		}

		public static TweenerCore<Vector2, Vector2, VectorOptions> DOAnchorPosX(this RectTransform target, float endValue, float duration, bool snapping = false)
		{
			_003C_003Ec__DisplayClass14_0 _003C_003Ec__DisplayClass14_ = new _003C_003Ec__DisplayClass14_0();
			_003C_003Ec__DisplayClass14_.target = target;
			TweenerCore<Vector2, Vector2, VectorOptions> tweenerCore = DOTween.To(_003C_003Ec__DisplayClass14_._003CDOAnchorPosX_003Eb__0, _003C_003Ec__DisplayClass14_._003CDOAnchorPosX_003Eb__1, new Vector2(endValue, 0f), duration);
			tweenerCore.SetOptions(AxisConstraint.X, snapping).SetTarget(_003C_003Ec__DisplayClass14_.target);
			return tweenerCore;
		}

		public static TweenerCore<Vector2, Vector2, VectorOptions> DOAnchorPosY(this RectTransform target, float endValue, float duration, bool snapping = false)
		{
			_003C_003Ec__DisplayClass15_0 _003C_003Ec__DisplayClass15_ = new _003C_003Ec__DisplayClass15_0();
			_003C_003Ec__DisplayClass15_.target = target;
			TweenerCore<Vector2, Vector2, VectorOptions> tweenerCore = DOTween.To(_003C_003Ec__DisplayClass15_._003CDOAnchorPosY_003Eb__0, _003C_003Ec__DisplayClass15_._003CDOAnchorPosY_003Eb__1, new Vector2(0f, endValue), duration);
			tweenerCore.SetOptions(AxisConstraint.Y, snapping).SetTarget(_003C_003Ec__DisplayClass15_.target);
			return tweenerCore;
		}

		public static TweenerCore<Vector3, Vector3, VectorOptions> DOAnchorPos3D(this RectTransform target, Vector3 endValue, float duration, bool snapping = false)
		{
			_003C_003Ec__DisplayClass16_0 _003C_003Ec__DisplayClass16_ = new _003C_003Ec__DisplayClass16_0();
			_003C_003Ec__DisplayClass16_.target = target;
			TweenerCore<Vector3, Vector3, VectorOptions> tweenerCore = DOTween.To(_003C_003Ec__DisplayClass16_._003CDOAnchorPos3D_003Eb__0, _003C_003Ec__DisplayClass16_._003CDOAnchorPos3D_003Eb__1, endValue, duration);
			tweenerCore.SetOptions(snapping).SetTarget(_003C_003Ec__DisplayClass16_.target);
			return tweenerCore;
		}

		public static TweenerCore<Vector3, Vector3, VectorOptions> DOAnchorPos3DX(this RectTransform target, float endValue, float duration, bool snapping = false)
		{
			_003C_003Ec__DisplayClass17_0 _003C_003Ec__DisplayClass17_ = new _003C_003Ec__DisplayClass17_0();
			_003C_003Ec__DisplayClass17_.target = target;
			TweenerCore<Vector3, Vector3, VectorOptions> tweenerCore = DOTween.To(_003C_003Ec__DisplayClass17_._003CDOAnchorPos3DX_003Eb__0, _003C_003Ec__DisplayClass17_._003CDOAnchorPos3DX_003Eb__1, new Vector3(endValue, 0f, 0f), duration);
			tweenerCore.SetOptions(AxisConstraint.X, snapping).SetTarget(_003C_003Ec__DisplayClass17_.target);
			return tweenerCore;
		}

		public static TweenerCore<Vector3, Vector3, VectorOptions> DOAnchorPos3DY(this RectTransform target, float endValue, float duration, bool snapping = false)
		{
			_003C_003Ec__DisplayClass18_0 _003C_003Ec__DisplayClass18_ = new _003C_003Ec__DisplayClass18_0();
			_003C_003Ec__DisplayClass18_.target = target;
			TweenerCore<Vector3, Vector3, VectorOptions> tweenerCore = DOTween.To(_003C_003Ec__DisplayClass18_._003CDOAnchorPos3DY_003Eb__0, _003C_003Ec__DisplayClass18_._003CDOAnchorPos3DY_003Eb__1, new Vector3(0f, endValue, 0f), duration);
			tweenerCore.SetOptions(AxisConstraint.Y, snapping).SetTarget(_003C_003Ec__DisplayClass18_.target);
			return tweenerCore;
		}

		public static TweenerCore<Vector3, Vector3, VectorOptions> DOAnchorPos3DZ(this RectTransform target, float endValue, float duration, bool snapping = false)
		{
			_003C_003Ec__DisplayClass19_0 _003C_003Ec__DisplayClass19_ = new _003C_003Ec__DisplayClass19_0();
			_003C_003Ec__DisplayClass19_.target = target;
			TweenerCore<Vector3, Vector3, VectorOptions> tweenerCore = DOTween.To(_003C_003Ec__DisplayClass19_._003CDOAnchorPos3DZ_003Eb__0, _003C_003Ec__DisplayClass19_._003CDOAnchorPos3DZ_003Eb__1, new Vector3(0f, 0f, endValue), duration);
			tweenerCore.SetOptions(AxisConstraint.Z, snapping).SetTarget(_003C_003Ec__DisplayClass19_.target);
			return tweenerCore;
		}

		public static TweenerCore<Vector2, Vector2, VectorOptions> DOAnchorMax(this RectTransform target, Vector2 endValue, float duration, bool snapping = false)
		{
			_003C_003Ec__DisplayClass20_0 _003C_003Ec__DisplayClass20_ = new _003C_003Ec__DisplayClass20_0();
			_003C_003Ec__DisplayClass20_.target = target;
			TweenerCore<Vector2, Vector2, VectorOptions> tweenerCore = DOTween.To(_003C_003Ec__DisplayClass20_._003CDOAnchorMax_003Eb__0, _003C_003Ec__DisplayClass20_._003CDOAnchorMax_003Eb__1, endValue, duration);
			tweenerCore.SetOptions(snapping).SetTarget(_003C_003Ec__DisplayClass20_.target);
			return tweenerCore;
		}

		public static TweenerCore<Vector2, Vector2, VectorOptions> DOAnchorMin(this RectTransform target, Vector2 endValue, float duration, bool snapping = false)
		{
			_003C_003Ec__DisplayClass21_0 _003C_003Ec__DisplayClass21_ = new _003C_003Ec__DisplayClass21_0();
			_003C_003Ec__DisplayClass21_.target = target;
			TweenerCore<Vector2, Vector2, VectorOptions> tweenerCore = DOTween.To(_003C_003Ec__DisplayClass21_._003CDOAnchorMin_003Eb__0, _003C_003Ec__DisplayClass21_._003CDOAnchorMin_003Eb__1, endValue, duration);
			tweenerCore.SetOptions(snapping).SetTarget(_003C_003Ec__DisplayClass21_.target);
			return tweenerCore;
		}

		public static TweenerCore<Vector2, Vector2, VectorOptions> DOPivot(this RectTransform target, Vector2 endValue, float duration)
		{
			_003C_003Ec__DisplayClass22_0 _003C_003Ec__DisplayClass22_ = new _003C_003Ec__DisplayClass22_0();
			_003C_003Ec__DisplayClass22_.target = target;
			TweenerCore<Vector2, Vector2, VectorOptions> tweenerCore = DOTween.To(_003C_003Ec__DisplayClass22_._003CDOPivot_003Eb__0, _003C_003Ec__DisplayClass22_._003CDOPivot_003Eb__1, endValue, duration);
			tweenerCore.SetTarget(_003C_003Ec__DisplayClass22_.target);
			return tweenerCore;
		}

		public static TweenerCore<Vector2, Vector2, VectorOptions> DOPivotX(this RectTransform target, float endValue, float duration)
		{
			_003C_003Ec__DisplayClass23_0 _003C_003Ec__DisplayClass23_ = new _003C_003Ec__DisplayClass23_0();
			_003C_003Ec__DisplayClass23_.target = target;
			TweenerCore<Vector2, Vector2, VectorOptions> tweenerCore = DOTween.To(_003C_003Ec__DisplayClass23_._003CDOPivotX_003Eb__0, _003C_003Ec__DisplayClass23_._003CDOPivotX_003Eb__1, new Vector2(endValue, 0f), duration);
			tweenerCore.SetOptions(AxisConstraint.X).SetTarget(_003C_003Ec__DisplayClass23_.target);
			return tweenerCore;
		}

		public static TweenerCore<Vector2, Vector2, VectorOptions> DOPivotY(this RectTransform target, float endValue, float duration)
		{
			_003C_003Ec__DisplayClass24_0 _003C_003Ec__DisplayClass24_ = new _003C_003Ec__DisplayClass24_0();
			_003C_003Ec__DisplayClass24_.target = target;
			TweenerCore<Vector2, Vector2, VectorOptions> tweenerCore = DOTween.To(_003C_003Ec__DisplayClass24_._003CDOPivotY_003Eb__0, _003C_003Ec__DisplayClass24_._003CDOPivotY_003Eb__1, new Vector2(0f, endValue), duration);
			tweenerCore.SetOptions(AxisConstraint.Y).SetTarget(_003C_003Ec__DisplayClass24_.target);
			return tweenerCore;
		}

		public static TweenerCore<Vector2, Vector2, VectorOptions> DOSizeDelta(this RectTransform target, Vector2 endValue, float duration, bool snapping = false)
		{
			_003C_003Ec__DisplayClass25_0 _003C_003Ec__DisplayClass25_ = new _003C_003Ec__DisplayClass25_0();
			_003C_003Ec__DisplayClass25_.target = target;
			TweenerCore<Vector2, Vector2, VectorOptions> tweenerCore = DOTween.To(_003C_003Ec__DisplayClass25_._003CDOSizeDelta_003Eb__0, _003C_003Ec__DisplayClass25_._003CDOSizeDelta_003Eb__1, endValue, duration);
			tweenerCore.SetOptions(snapping).SetTarget(_003C_003Ec__DisplayClass25_.target);
			return tweenerCore;
		}

		public static Tweener DOPunchAnchorPos(this RectTransform target, Vector2 punch, float duration, int vibrato = 10, float elasticity = 1f, bool snapping = false)
		{
			_003C_003Ec__DisplayClass26_0 _003C_003Ec__DisplayClass26_ = new _003C_003Ec__DisplayClass26_0();
			_003C_003Ec__DisplayClass26_.target = target;
			return DOTween.Punch(_003C_003Ec__DisplayClass26_._003CDOPunchAnchorPos_003Eb__0, _003C_003Ec__DisplayClass26_._003CDOPunchAnchorPos_003Eb__1, punch, duration, vibrato, elasticity).SetTarget(_003C_003Ec__DisplayClass26_.target).SetOptions(snapping);
		}

		public static Tweener DOShakeAnchorPos(this RectTransform target, float duration, float strength = 100f, int vibrato = 10, float randomness = 90f, bool snapping = false, bool fadeOut = true)
		{
			_003C_003Ec__DisplayClass27_0 _003C_003Ec__DisplayClass27_ = new _003C_003Ec__DisplayClass27_0();
			_003C_003Ec__DisplayClass27_.target = target;
			return DOTween.Shake(_003C_003Ec__DisplayClass27_._003CDOShakeAnchorPos_003Eb__0, _003C_003Ec__DisplayClass27_._003CDOShakeAnchorPos_003Eb__1, duration, strength, vibrato, randomness, true, fadeOut).SetTarget(_003C_003Ec__DisplayClass27_.target).SetSpecialStartupMode(SpecialStartupMode.SetShake)
				.SetOptions(snapping);
		}

		public static Tweener DOShakeAnchorPos(this RectTransform target, float duration, Vector2 strength, int vibrato = 10, float randomness = 90f, bool snapping = false, bool fadeOut = true)
		{
			_003C_003Ec__DisplayClass28_0 _003C_003Ec__DisplayClass28_ = new _003C_003Ec__DisplayClass28_0();
			_003C_003Ec__DisplayClass28_.target = target;
			return DOTween.Shake(_003C_003Ec__DisplayClass28_._003CDOShakeAnchorPos_003Eb__0, _003C_003Ec__DisplayClass28_._003CDOShakeAnchorPos_003Eb__1, duration, strength, vibrato, randomness, fadeOut).SetTarget(_003C_003Ec__DisplayClass28_.target).SetSpecialStartupMode(SpecialStartupMode.SetShake)
				.SetOptions(snapping);
		}

		public static Sequence DOJumpAnchorPos(this RectTransform target, Vector2 endValue, float jumpPower, int numJumps, float duration, bool snapping = false)
		{
			_003C_003Ec__DisplayClass29_0 _003C_003Ec__DisplayClass29_ = new _003C_003Ec__DisplayClass29_0();
			_003C_003Ec__DisplayClass29_.target = target;
			_003C_003Ec__DisplayClass29_.endValue = endValue;
			if (numJumps < 1)
			{
				numJumps = 1;
			}
			_003C_003Ec__DisplayClass29_.startPosY = 0f;
			_003C_003Ec__DisplayClass29_.offsetY = -1f;
			_003C_003Ec__DisplayClass29_.offsetYSet = false;
			_003C_003Ec__DisplayClass29_.s = DOTween.Sequence();
			Tween t = DOTween.To(_003C_003Ec__DisplayClass29_._003CDOJumpAnchorPos_003Eb__0, _003C_003Ec__DisplayClass29_._003CDOJumpAnchorPos_003Eb__1, new Vector2(0f, jumpPower), duration / (float)(numJumps * 2)).SetOptions(AxisConstraint.Y, snapping).SetEase(Ease.OutQuad)
				.SetRelative()
				.SetLoops(numJumps * 2, LoopType.Yoyo)
				.OnStart(_003C_003Ec__DisplayClass29_._003CDOJumpAnchorPos_003Eb__2);
			_003C_003Ec__DisplayClass29_.s.Append(DOTween.To(_003C_003Ec__DisplayClass29_._003CDOJumpAnchorPos_003Eb__3, _003C_003Ec__DisplayClass29_._003CDOJumpAnchorPos_003Eb__4, new Vector2(_003C_003Ec__DisplayClass29_.endValue.x, 0f), duration).SetOptions(AxisConstraint.X, snapping).SetEase(Ease.Linear)).Join(t).SetTarget(_003C_003Ec__DisplayClass29_.target)
				.SetEase(DOTween.defaultEaseType);
			_003C_003Ec__DisplayClass29_.s.OnUpdate(_003C_003Ec__DisplayClass29_._003CDOJumpAnchorPos_003Eb__5);
			return _003C_003Ec__DisplayClass29_.s;
		}

		public static Tweener DONormalizedPos(this ScrollRect target, Vector2 endValue, float duration, bool snapping = false)
		{
			_003C_003Ec__DisplayClass30_0 _003C_003Ec__DisplayClass30_ = new _003C_003Ec__DisplayClass30_0();
			_003C_003Ec__DisplayClass30_.target = target;
			return DOTween.To(_003C_003Ec__DisplayClass30_._003CDONormalizedPos_003Eb__0, _003C_003Ec__DisplayClass30_._003CDONormalizedPos_003Eb__1, endValue, duration).SetOptions(snapping).SetTarget(_003C_003Ec__DisplayClass30_.target);
		}

		public static Tweener DOHorizontalNormalizedPos(this ScrollRect target, float endValue, float duration, bool snapping = false)
		{
			_003C_003Ec__DisplayClass31_0 _003C_003Ec__DisplayClass31_ = new _003C_003Ec__DisplayClass31_0();
			_003C_003Ec__DisplayClass31_.target = target;
			return DOTween.To(_003C_003Ec__DisplayClass31_._003CDOHorizontalNormalizedPos_003Eb__0, _003C_003Ec__DisplayClass31_._003CDOHorizontalNormalizedPos_003Eb__1, endValue, duration).SetOptions(snapping).SetTarget(_003C_003Ec__DisplayClass31_.target);
		}

		public static Tweener DOVerticalNormalizedPos(this ScrollRect target, float endValue, float duration, bool snapping = false)
		{
			_003C_003Ec__DisplayClass32_0 _003C_003Ec__DisplayClass32_ = new _003C_003Ec__DisplayClass32_0();
			_003C_003Ec__DisplayClass32_.target = target;
			return DOTween.To(_003C_003Ec__DisplayClass32_._003CDOVerticalNormalizedPos_003Eb__0, _003C_003Ec__DisplayClass32_._003CDOVerticalNormalizedPos_003Eb__1, endValue, duration).SetOptions(snapping).SetTarget(_003C_003Ec__DisplayClass32_.target);
		}

		public static TweenerCore<float, float, FloatOptions> DOValue(this Slider target, float endValue, float duration, bool snapping = false)
		{
			_003C_003Ec__DisplayClass33_0 _003C_003Ec__DisplayClass33_ = new _003C_003Ec__DisplayClass33_0();
			_003C_003Ec__DisplayClass33_.target = target;
			TweenerCore<float, float, FloatOptions> tweenerCore = DOTween.To(_003C_003Ec__DisplayClass33_._003CDOValue_003Eb__0, _003C_003Ec__DisplayClass33_._003CDOValue_003Eb__1, endValue, duration);
			tweenerCore.SetOptions(snapping).SetTarget(_003C_003Ec__DisplayClass33_.target);
			return tweenerCore;
		}

		public static TweenerCore<Color, Color, ColorOptions> DOColor(this Text target, Color endValue, float duration)
		{
			_003C_003Ec__DisplayClass34_0 _003C_003Ec__DisplayClass34_ = new _003C_003Ec__DisplayClass34_0();
			_003C_003Ec__DisplayClass34_.target = target;
			TweenerCore<Color, Color, ColorOptions> tweenerCore = DOTween.To(_003C_003Ec__DisplayClass34_._003CDOColor_003Eb__0, _003C_003Ec__DisplayClass34_._003CDOColor_003Eb__1, endValue, duration);
			tweenerCore.SetTarget(_003C_003Ec__DisplayClass34_.target);
			return tweenerCore;
		}

		public static TweenerCore<Color, Color, ColorOptions> DOFade(this Text target, float endValue, float duration)
		{
			_003C_003Ec__DisplayClass35_0 _003C_003Ec__DisplayClass35_ = new _003C_003Ec__DisplayClass35_0();
			_003C_003Ec__DisplayClass35_.target = target;
			TweenerCore<Color, Color, ColorOptions> tweenerCore = DOTween.ToAlpha(_003C_003Ec__DisplayClass35_._003CDOFade_003Eb__0, _003C_003Ec__DisplayClass35_._003CDOFade_003Eb__1, endValue, duration);
			tweenerCore.SetTarget(_003C_003Ec__DisplayClass35_.target);
			return tweenerCore;
		}

		public static TweenerCore<string, string, StringOptions> DOText(this Text target, string endValue, float duration, bool richTextEnabled = true, ScrambleMode scrambleMode = ScrambleMode.None, string scrambleChars = null)
		{
			_003C_003Ec__DisplayClass36_0 _003C_003Ec__DisplayClass36_ = new _003C_003Ec__DisplayClass36_0();
			_003C_003Ec__DisplayClass36_.target = target;
			TweenerCore<string, string, StringOptions> tweenerCore = DOTween.To(_003C_003Ec__DisplayClass36_._003CDOText_003Eb__0, _003C_003Ec__DisplayClass36_._003CDOText_003Eb__1, endValue, duration);
			tweenerCore.SetOptions(richTextEnabled, scrambleMode, scrambleChars).SetTarget(_003C_003Ec__DisplayClass36_.target);
			return tweenerCore;
		}

		public static Tweener DOBlendableColor(this Graphic target, Color endValue, float duration)
		{
			_003C_003Ec__DisplayClass37_0 _003C_003Ec__DisplayClass37_ = new _003C_003Ec__DisplayClass37_0();
			_003C_003Ec__DisplayClass37_.target = target;
			endValue -= _003C_003Ec__DisplayClass37_.target.color;
			_003C_003Ec__DisplayClass37_.to = new Color(0f, 0f, 0f, 0f);
			return DOTween.To(_003C_003Ec__DisplayClass37_._003CDOBlendableColor_003Eb__0, _003C_003Ec__DisplayClass37_._003CDOBlendableColor_003Eb__1, endValue, duration).Blendable().SetTarget(_003C_003Ec__DisplayClass37_.target);
		}

		public static Tweener DOBlendableColor(this Image target, Color endValue, float duration)
		{
			_003C_003Ec__DisplayClass38_0 _003C_003Ec__DisplayClass38_ = new _003C_003Ec__DisplayClass38_0();
			_003C_003Ec__DisplayClass38_.target = target;
			endValue -= _003C_003Ec__DisplayClass38_.target.color;
			_003C_003Ec__DisplayClass38_.to = new Color(0f, 0f, 0f, 0f);
			return DOTween.To(_003C_003Ec__DisplayClass38_._003CDOBlendableColor_003Eb__0, _003C_003Ec__DisplayClass38_._003CDOBlendableColor_003Eb__1, endValue, duration).Blendable().SetTarget(_003C_003Ec__DisplayClass38_.target);
		}

		public static Tweener DOBlendableColor(this Text target, Color endValue, float duration)
		{
			_003C_003Ec__DisplayClass39_0 _003C_003Ec__DisplayClass39_ = new _003C_003Ec__DisplayClass39_0();
			_003C_003Ec__DisplayClass39_.target = target;
			endValue -= _003C_003Ec__DisplayClass39_.target.color;
			_003C_003Ec__DisplayClass39_.to = new Color(0f, 0f, 0f, 0f);
			return DOTween.To(_003C_003Ec__DisplayClass39_._003CDOBlendableColor_003Eb__0, _003C_003Ec__DisplayClass39_._003CDOBlendableColor_003Eb__1, endValue, duration).Blendable().SetTarget(_003C_003Ec__DisplayClass39_.target);
		}
	}
}
