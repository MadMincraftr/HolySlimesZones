using UnityEngine;

public abstract class DLCContentMetadata : ScriptableObject
{
	public abstract void Register();
}
