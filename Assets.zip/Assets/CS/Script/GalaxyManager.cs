using UnityEngine;

[DisallowMultipleComponent]
internal class GalaxyManager : MonoBehaviour
{
}
