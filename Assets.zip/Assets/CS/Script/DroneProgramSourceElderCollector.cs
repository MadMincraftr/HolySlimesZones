using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;

public class DroneProgramSourceElderCollector : DroneProgramSourceSiloStorage
{
	[CompilerGenerated]
	private sealed class _003C_003Ec__DisplayClass0_0
	{
		public Predicate<Identifiable.Id> predicate;

		internal bool _003CGetSources_003Eb__1(DroneNetwork.StorageMetadata s)
		{
			return predicate(s.id);
		}
	}

	[Serializable]
	[CompilerGenerated]
	private sealed class _003C_003Ec
	{
		public static readonly _003C_003Ec _003C_003E9 = new _003C_003Ec();

		public static Func<DroneNetwork.LandPlotMetadata, IEnumerable<DroneNetwork.StorageMetadata>> _003C_003E9__0_0;

		public static Func<DroneNetwork.StorageMetadata, int> _003C_003E9__0_2;

		internal IEnumerable<DroneNetwork.StorageMetadata> _003CGetSources_003Eb__0_0(DroneNetwork.LandPlotMetadata m)
		{
			return m.elderCollectors;
		}

		internal int _003CGetSources_003Eb__0_2(DroneNetwork.StorageMetadata s)
		{
			return s.count;
		}
	}

	protected override IEnumerable<DroneNetwork.StorageMetadata> GetSources(Predicate<Identifiable.Id> predicate)
	{
		_003C_003Ec__DisplayClass0_0 _003C_003Ec__DisplayClass0_ = new _003C_003Ec__DisplayClass0_0();
		_003C_003Ec__DisplayClass0_.predicate = predicate;
		return drone.network.Plots.SelectMany(_003C_003Ec._003C_003E9__0_0 ?? (_003C_003Ec._003C_003E9__0_0 = _003C_003Ec._003C_003E9._003CGetSources_003Eb__0_0)).Where(_003C_003Ec__DisplayClass0_._003CGetSources_003Eb__1).OrderByDescending(_003C_003Ec._003C_003E9__0_2 ?? (_003C_003Ec._003C_003E9__0_2 = _003C_003Ec._003C_003E9._003CGetSources_003Eb__0_2));
	}
}
