using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using UnityEngine;

public class FabricateGadgetUI : BaseUI
{
	[CompilerGenerated]
	private sealed class _003C_003Ec__DisplayClass7_0
	{
		public FabricateGadgetUI _003C_003E4__this;

		public GadgetDirector gadgetDir;
	}

	[CompilerGenerated]
	private sealed class _003C_003Ec__DisplayClass7_1
	{
		public Gadget.Id finalId;

		public GadgetDefinition finalDefinition;

		public _003C_003Ec__DisplayClass7_0 CS_0024_003C_003E8__locals1;

		internal void _003CCreatePurchaseUI_003Eb__0()
		{
			CS_0024_003C_003E8__locals1._003C_003E4__this.Fabricate(finalId);
		}

		internal bool _003CCreatePurchaseUI_003Eb__1()
		{
			return CS_0024_003C_003E8__locals1.gadgetDir.HasBlueprint(finalId);
		}

		internal bool _003CCreatePurchaseUI_003Eb__2()
		{
			return CS_0024_003C_003E8__locals1.gadgetDir.CanAddGadget(finalDefinition);
		}

		internal int _003CCreatePurchaseUI_003Eb__3()
		{
			return CS_0024_003C_003E8__locals1.gadgetDir.GetGadgetCount(finalId);
		}
	}

	public Sprite titleIcon;

	private PurchaseUI purchaseUI;

	private Dictionary<string, string> categoryMap = new Dictionary<string, string>();

	private const string ERR_INSUF_CRAFT_RESOURCES = "e.insuf_craft_resources";

	private const string ERR_CANNOT_ADD_GADGET = "e.cannot_add_gagdget";

	public override void Awake()
	{
		base.Awake();
		BuildUI();
		SRSingleton<SceneContext>.Instance.TutorialDirector.OnFabricatorOpen();
	}

	public void BuildUI()
	{
		if (purchaseUI != null && purchaseUI.gameObject != null)
		{
			Destroyer.Destroy(purchaseUI.gameObject, "FabricateGadgetUI.BuildUI");
		}
		GameObject gameObject = CreatePurchaseUI();
		gameObject.transform.SetParent(base.transform, false);
		purchaseUI = gameObject.GetComponent<PurchaseUI>();
		statusArea = purchaseUI.statusArea;
	}

	protected GameObject CreatePurchaseUI()
	{
		_003C_003Ec__DisplayClass7_0 _003C_003Ec__DisplayClass7_ = new _003C_003Ec__DisplayClass7_0();
		_003C_003Ec__DisplayClass7_._003C_003E4__this = this;
		categoryMap.Clear();
		_003C_003Ec__DisplayClass7_.gadgetDir = SRSingleton<SceneContext>.Instance.GadgetDirector;
		List<PurchaseUI.Purchasable> list = new List<PurchaseUI.Purchasable>();
		Dictionary<PediaDirector.Id, List<PurchaseUI.Purchasable>> dictionary = new Dictionary<PediaDirector.Id, List<PurchaseUI.Purchasable>>();
		foreach (GadgetDefinition gadgetDefinition in SRSingleton<GameContext>.Instance.LookupDirector.GadgetDefinitions)
		{
			_003C_003Ec__DisplayClass7_1 _003C_003Ec__DisplayClass7_2 = new _003C_003Ec__DisplayClass7_1();
			_003C_003Ec__DisplayClass7_2.CS_0024_003C_003E8__locals1 = _003C_003Ec__DisplayClass7_;
			string text = Enum.GetName(typeof(Gadget.Id), gadgetDefinition.id).ToLowerInvariant();
			_003C_003Ec__DisplayClass7_2.finalDefinition = gadgetDefinition;
			_003C_003Ec__DisplayClass7_2.finalId = gadgetDefinition.id;
			string descKey = "m.gadget.desc." + text;
			string text2 = "m.gadget.name." + text;
			PurchaseUI.Purchasable item = new PurchaseUI.Purchasable(text2, gadgetDefinition.icon, gadgetDefinition.icon, descKey, 0, gadgetDefinition.pediaLink, _003C_003Ec__DisplayClass7_2._003CCreatePurchaseUI_003Eb__0, _003C_003Ec__DisplayClass7_2._003CCreatePurchaseUI_003Eb__1, _003C_003Ec__DisplayClass7_2._003CCreatePurchaseUI_003Eb__2, null, null, _003C_003Ec__DisplayClass7_2._003CCreatePurchaseUI_003Eb__3, gadgetDefinition.craftCosts);
			list.Add(item);
			categoryMap[text2] = gadgetDefinition.pediaLink.ToString().ToLowerInvariant();
			List<PurchaseUI.Purchasable> list2 = dictionary.Get(gadgetDefinition.pediaLink);
			if (list2 == null)
			{
				list2 = new List<PurchaseUI.Purchasable>();
			}
			list2.Add(item);
			dictionary[gadgetDefinition.pediaLink] = list2;
		}
		GameObject gameObject = SRSingleton<GameContext>.Instance.UITemplates.CreatePurchaseUI(titleIcon, MessageUtil.Qualify("ui", "t.fabricate_gadget"), list.ToArray(), true, Close);
		List<PurchaseUI.Category> list3 = new List<PurchaseUI.Category>();
		PediaDirector.Id[] sCIENCE_ENTRIES = PediaUI.SCIENCE_ENTRIES;
		for (int i = 0; i < sCIENCE_ENTRIES.Length; i++)
		{
			PediaDirector.Id key = sCIENCE_ENTRIES[i];
			if (dictionary.ContainsKey(key))
			{
				list3.Add(new PurchaseUI.Category(key.ToString().ToLowerInvariant(), dictionary[key].ToArray()));
			}
		}
		gameObject.GetComponent<PurchaseUI>().SetCategories(list3);
		gameObject.GetComponent<PurchaseUI>().SetPurchaseMsgs("b.fabricate", "b.sold_out");
		return gameObject;
	}

	public void Fabricate(Gadget.Id id)
	{
		GadgetDirector gadgetDirector = SRSingleton<SceneContext>.Instance.GadgetDirector;
		AchievementsDirector achievementsDirector = SRSingleton<SceneContext>.Instance.AchievementsDirector;
		GadgetDefinition gadgetDefinition = SRSingleton<GameContext>.Instance.LookupDirector.GetGadgetDefinition(id);
		if (!gadgetDirector.CanAddGadget(gadgetDefinition))
		{
			PlayErrorCue();
			Error("e.cannot_add_gagdget");
		}
		else if (TrySpendResources(gadgetDefinition.craftCosts))
		{
			ClearStatus();
			PlayPurchaseCue();
			gadgetDirector.AddGadget(id);
			achievementsDirector.AddToStat(AchievementsDirector.GameIntStat.FABRICATED_GADGETS, 1);
			if (gadgetDefinition.buyInPairs)
			{
				gadgetDirector.AddGadget(id);
			}
			AnalyticsUtil.CustomEvent("Fabricate", new Dictionary<string, object> { 
			{
				"id",
				id.ToString()
			} });
			purchaseUI.PlayPurchaseFX();
			purchaseUI.Rebuild(false);
		}
		else
		{
			PlayErrorCue();
			Error("e.insuf_craft_resources");
		}
	}

	private bool TrySpendResources(GadgetDefinition.CraftCost[] costs)
	{
		return SRSingleton<SceneContext>.Instance.GadgetDirector.TryToSpendFromRefinery(costs);
	}

	protected void PlayPurchaseCue()
	{
		Play(SRSingleton<GameContext>.Instance.UITemplates.purchaseBlueprintCue);
	}
}
