using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using UnityEngine;

public class GadgetBlueprintUI : BaseUI
{
	[CompilerGenerated]
	private sealed class _003C_003Ec__DisplayClass3_0
	{
		public GadgetBlueprintUI _003C_003E4__this;

		public GadgetDirector gadgetDir;
	}

	[CompilerGenerated]
	private sealed class _003C_003Ec__DisplayClass3_1
	{
		public GadgetDefinition entry;

		public _003C_003Ec__DisplayClass3_0 CS_0024_003C_003E8__locals1;

		internal void _003CCreatePurchaseUI_003Eb__0()
		{
			CS_0024_003C_003E8__locals1._003C_003E4__this.BuyBlueprint(entry.id);
		}

		internal bool _003CCreatePurchaseUI_003Eb__1()
		{
			if (!CS_0024_003C_003E8__locals1.gadgetDir.HasBlueprint(entry.id))
			{
				return CS_0024_003C_003E8__locals1.gadgetDir.IsBlueprintUnlocked(entry.id);
			}
			return true;
		}

		internal bool _003CCreatePurchaseUI_003Eb__2()
		{
			return !CS_0024_003C_003E8__locals1.gadgetDir.HasBlueprint(entry.id);
		}
	}

	public Sprite titleIcon;

	public override void Awake()
	{
		base.Awake();
		RebuildUI();
		SRSingleton<SceneContext>.Instance.TutorialDirector.OnBuilderShopOpen();
	}

	public void RebuildUI()
	{
		for (int i = 0; i < base.transform.childCount; i++)
		{
			Destroyer.Destroy(base.transform.GetChild(i).gameObject, "GadgetBlueprintUI.RebuildUI");
		}
		GameObject gameObject = CreatePurchaseUI();
		gameObject.transform.SetParent(base.transform, false);
		statusArea = gameObject.GetComponent<PurchaseUI>().statusArea;
	}

	protected GameObject CreatePurchaseUI()
	{
		_003C_003Ec__DisplayClass3_0 _003C_003Ec__DisplayClass3_ = new _003C_003Ec__DisplayClass3_0();
		_003C_003Ec__DisplayClass3_._003C_003E4__this = this;
		_003C_003Ec__DisplayClass3_.gadgetDir = SRSingleton<SceneContext>.Instance.GadgetDirector;
		List<PurchaseUI.Purchasable> list = new List<PurchaseUI.Purchasable>();
		using (IEnumerator<GadgetDefinition> enumerator = SRSingleton<GameContext>.Instance.LookupDirector.GadgetDefinitions.GetEnumerator())
		{
			while (enumerator.MoveNext())
			{
				_003C_003Ec__DisplayClass3_1 _003C_003Ec__DisplayClass3_2 = new _003C_003Ec__DisplayClass3_1();
				_003C_003Ec__DisplayClass3_2.CS_0024_003C_003E8__locals1 = _003C_003Ec__DisplayClass3_;
				_003C_003Ec__DisplayClass3_2.entry = enumerator.Current;
				string arg = Enum.GetName(typeof(Gadget.Id), _003C_003Ec__DisplayClass3_2.entry.id).ToLowerInvariant();
				list.Add(new PurchaseUI.Purchasable(string.Format("m.gadget.name.{0}", arg), descKey: string.Format("m.gadget.desc.{0}", arg), icon: _003C_003Ec__DisplayClass3_2.entry.icon, mainImg: _003C_003Ec__DisplayClass3_2.entry.icon, cost: _003C_003Ec__DisplayClass3_2.entry.blueprintCost, pediaId: _003C_003Ec__DisplayClass3_2.entry.pediaLink, onPurchase: _003C_003Ec__DisplayClass3_2._003CCreatePurchaseUI_003Eb__0, unlocked: _003C_003Ec__DisplayClass3_2._003CCreatePurchaseUI_003Eb__1, avail: _003C_003Ec__DisplayClass3_2._003CCreatePurchaseUI_003Eb__2));
			}
		}
		return SRSingleton<GameContext>.Instance.UITemplates.CreatePurchaseUI(titleIcon, MessageUtil.Qualify("ui", "t.purchase_blueprint"), list.ToArray(), false, Close);
	}

	public void BuyBlueprint(Gadget.Id id)
	{
		PlayerState playerState = SRSingleton<SceneContext>.Instance.PlayerState;
		GadgetDefinition gadgetDefinition = SRSingleton<GameContext>.Instance.LookupDirector.GetGadgetDefinition(id);
		if (playerState.GetCurrency() >= gadgetDefinition.blueprintCost)
		{
			playerState.SpendCurrency(gadgetDefinition.blueprintCost);
			SRSingleton<SceneContext>.Instance.GadgetDirector.AddBlueprint(id);
			PlayPurchaseCue();
			Close();
		}
		else
		{
			PlayErrorCue();
			Error("e.insuf_coins");
		}
	}

	protected void PlayPurchaseCue()
	{
		Play(SRSingleton<GameContext>.Instance.UITemplates.purchaseBlueprintCue);
	}
}
