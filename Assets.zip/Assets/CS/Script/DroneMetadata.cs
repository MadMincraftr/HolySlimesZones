using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using MonomiPark.SlimeRancher.Regions;
using UnityEngine;

public class DroneMetadata : ScriptableObject
{
	public class Program
	{
		public abstract class BaseComponent
		{
			public BaseComponent()
			{
			}
			public string id;

			public Sprite image;

			public virtual string GetName()
			{
				return SRSingleton<GameContext>.Instance.MessageDirector.GetBundle("ui").Get(id);
			}

			public virtual Sprite GetImage()
			{
				return image;
			}
		}

		public class Target : BaseComponent
		{
			public Target()
			{
			}

			public class Basic : Target
			{
				[CompilerGenerated]
				private sealed class _003C_003Ec__DisplayClass0_0
				{
					public Identifiable.Id ident;

					internal bool _003C_002Ector_003Eb__0(Identifiable.Id rhs)
					{
						return rhs == ident;
					}
				}

				public Basic(Identifiable.Id ident)
				{
					_003C_003Ec__DisplayClass0_0 _003C_003Ec__DisplayClass0_ = new _003C_003Ec__DisplayClass0_0();
					_003C_003Ec__DisplayClass0_.ident = ident;
					new Target();
					id = string.Format("m.drone.target.identifiable.{0}", Enum.GetName(typeof(Identifiable.Id), _003C_003Ec__DisplayClass0_.ident).ToLowerInvariant());
					base.ident = _003C_003Ec__DisplayClass0_.ident;
					predicate = _003C_003Ec__DisplayClass0_._003C_002Ector_003Eb__0;
				}

				public override string GetName()
				{
					return Identifiable.GetName(ident);
				}

				public override Sprite GetImage()
				{
					return SRSingleton<GameContext>.Instance.LookupDirector.GetIcon(ident);
				}
			}

			public class Collection : Target
			{
				[CompilerGenerated]
				private sealed class _003C_003Ec__DisplayClass1_0
				{
					public HashSet<Identifiable.Id> collection;

					internal bool _003C_002Ector_003Eb__0(Identifiable.Id rhs)
					{
						return collection.Contains(rhs);
					}
				}

				public HashSet<Identifiable.Id> collection;

				public Collection(string id, HashSet<Identifiable.Id> collection, Sprite image)
				{
					_003C_003Ec__DisplayClass1_0 _003C_003Ec__DisplayClass1_ = new _003C_003Ec__DisplayClass1_0();
					_003C_003Ec__DisplayClass1_.collection = collection;
					new Target();
					base.id = string.Format("m.drone.target.name.category_{0}", id);
					ident = _003C_003Ec__DisplayClass1_.collection.First();
					predicate = _003C_003Ec__DisplayClass1_._003C_002Ector_003Eb__0;
					this.collection = _003C_003Ec__DisplayClass1_.collection;
					base.image = image;
				}
			}

			public Identifiable.Id ident;

			public Predicate<Identifiable.Id> predicate;
		}

		public class Behaviour : BaseComponent
		{
			[Serializable]
			[CompilerGenerated]
			private sealed class _003C_003Ec
			{
				public static readonly _003C_003Ec _003C_003E9 = new _003C_003Ec();

				public static Predicate<Program> _003C_003E9__2_0;

				internal bool _003C_002Ector_003Eb__2_0(Program p)
				{
					return true;
				}
			}

			public Type[] types;

			public Predicate<Program> isCompatible = _003C_003Ec._003C_003E9__2_0 ?? (_003C_003Ec._003C_003E9__2_0 = _003C_003Ec._003C_003E9._003C_002Ector_003Eb__2_0);
		}

		public class GadgetBehaviour : Behaviour
		{
			public Func<bool> gadgetPredicate;

			public Gadget.Id gadget;

			public override string GetName()
			{
				if (gadgetPredicate())
				{
					return SRSingleton<GameContext>.Instance.MessageDirector.GetBundle("pedia").Get(string.Format("m.gadget.name.{0}", gadget.ToString().ToLowerInvariant()));
				}
				return base.GetName();
			}

			public override Sprite GetImage()
			{
				if (gadgetPredicate())
				{
					return SRSingleton<GameContext>.Instance.LookupDirector.GetGadgetDefinition(gadget).icon;
				}
				return base.GetImage();
			}
		}

		public Target target;

		public Behaviour source;

		public Behaviour destination;

		public Program()
		{
		}

		public Program(Target target, Behaviour source, Behaviour destination)
		{
			this.target = target;
			this.source = source;
			this.destination = destination;
		}

		public Program Clone()
		{
			return new Program(target, source, destination);
		}

		public bool IsComplete()
		{
			if (target.id != "drone.target.none" && source.id != "drone.behaviour.none")
			{
				return destination.id != "drone.behaviour.none";
			}
			return false;
		}

		public bool IsReset()
		{
			if (target.id == "drone.target.none" && source.id == "drone.behaviour.none")
			{
				return destination.id == "drone.behaviour.none";
			}
			return false;
		}
	}

	[Serializable]
	[CompilerGenerated]
	private sealed class _003C_003Ec
	{
		public static readonly _003C_003Ec _003C_003E9 = new _003C_003Ec();

		public static Predicate<Program> _003C_003E9__55_0;

		public static Predicate<Program> _003C_003E9__55_1;

		public static Predicate<Program> _003C_003E9__55_2;

		public static Predicate<Program> _003C_003E9__55_3;

		public static Predicate<Program> _003C_003E9__55_4;

		public static Predicate<Program> _003C_003E9__55_5;

		public static Predicate<Program> _003C_003E9__55_6;

		public static Predicate<Program> _003C_003E9__55_7;

		public static Predicate<Program> _003C_003E9__55_8;

		public static Predicate<Program> _003C_003E9__55_9;

		public static Predicate<Program> _003C_003E9__55_10;

		public static Predicate<Program> _003C_003E9__55_11;

		public static Func<Region, bool> _003C_003E9__55_13;

		public static Func<bool> _003C_003E9__55_12;

		public static Predicate<Program> _003C_003E9__55_14;

		public static Func<Region, bool> _003C_003E9__55_16;

		public static Func<bool> _003C_003E9__55_15;

		public static Predicate<Identifiable.Id> _003C_003E9__58_0;

		internal bool _003COnEnable_003Eb__55_0(Program p)
		{
			return Identifiable.IsPlort(p.target.ident);
		}

		internal bool _003COnEnable_003Eb__55_1(Program p)
		{
			return Identifiable.IsPlort(p.target.ident);
		}

		internal bool _003COnEnable_003Eb__55_2(Program p)
		{
			return Identifiable.IsPlort(p.target.ident);
		}

		internal bool _003COnEnable_003Eb__55_3(Program p)
		{
			if (!Identifiable.IsFruit(p.target.ident))
			{
				return Identifiable.IsVeggie(p.target.ident);
			}
			return true;
		}

		internal bool _003COnEnable_003Eb__55_4(Program p)
		{
			return Identifiable.IsAnimal(p.target.ident);
		}

		internal bool _003COnEnable_003Eb__55_5(Program p)
		{
			return Identifiable.IsPlort(p.target.ident);
		}

		internal bool _003COnEnable_003Eb__55_6(Program p)
		{
			return !Identifiable.IsPlort(p.target.ident);
		}

		internal bool _003COnEnable_003Eb__55_7(Program p)
		{
			return Identifiable.IsPlort(p.target.ident);
		}

		internal bool _003COnEnable_003Eb__55_8(Program p)
		{
			return Identifiable.IsFood(p.target.ident);
		}

		internal bool _003COnEnable_003Eb__55_9(Program p)
		{
			return Identifiable.IsFood(p.target.ident);
		}

		internal bool _003COnEnable_003Eb__55_10(Program p)
		{
			return Identifiable.IsFood(p.target.ident);
		}

		internal bool _003COnEnable_003Eb__55_11(Program p)
		{
			return Identifiable.IsPlort(p.target.ident);
		}

		internal bool _003COnEnable_003Eb__55_12()
		{
			return SRSingleton<SceneContext>.Instance.Player.GetComponent<RegionMember>().regions.All(_003C_003E9__55_13 ?? (_003C_003E9__55_13 = _003C_003E9._003COnEnable_003Eb__55_13));
		}

		internal bool _003COnEnable_003Eb__55_13(Region r)
		{
			return r.gameObject.name != "cellRanch_Home";
		}

		internal bool _003COnEnable_003Eb__55_14(Program p)
		{
			return Identifiable.IsPlort(p.target.ident);
		}

		internal bool _003COnEnable_003Eb__55_15()
		{
			return SRSingleton<SceneContext>.Instance.Player.GetComponent<RegionMember>().regions.All(_003C_003E9__55_16 ?? (_003C_003E9__55_16 = _003C_003E9._003COnEnable_003Eb__55_16));
		}

		internal bool _003COnEnable_003Eb__55_16(Region r)
		{
			return r.gameObject.name != "cellRanch_Lab";
		}

		internal bool _003CGetDefaultTarget_003Eb__58_0(Identifiable.Id id)
		{
			return false;
		}
	}

	[Header("GameObject Prefabs")]
	public DroneUI droneUI;

	public DroneUIProgram droneUIProgram;

	public DroneUIProgramPicker droneUIProgramPicker;

	public DroneUIProgramButton droneUIProgramButton;

	[Header("Program Component Images")]
	public Sprite imageTargetCollectionPlorts;

	public Sprite imageTargetCollectionFruits;

	public Sprite imageTargetCollectionVeggies;

	public Sprite imageTargetCollectionMeats;

	public Sprite imageTargetCollectionElders;

	public Sprite imageSourceCorral;

	public Sprite imageSourcePond;

	public Sprite imageSourceIncinerator;

	public Sprite imageSourceGarden;

	public Sprite imageSourceCoop;

	public Sprite imageSourceSilo;

	public Sprite imageSourcePlortCollector;

	public Sprite imageSourceOutsidePlots;

	public Sprite imageSourceFreeRange;

	public Sprite imageDestinationCorral;

	public Sprite imageDestinationSilo;

	public Sprite imageDestinationFeeder;

	public Sprite imageDestinationIncinerator;

	public Sprite imageDestinationPlortMarket;

	public Sprite imageDestinationRefinery;

	public Sprite imageNone;

	public Sprite pickTargetIcon;

	public Sprite pickSourceIcon;

	public Sprite pickDestinationIcon;

	[Header("SFX")]
	public SECTR_AudioCue onActiveCue;

	public SECTR_AudioCue onGatherBeginCue;

	public SECTR_AudioCue onGatherLoopCue;

	public SECTR_AudioCue onGatherEndCue;

	public SECTR_AudioCue onDepositBeginCue;

	public SECTR_AudioCue onDepositLoopCue;

	public SECTR_AudioCue onDepositEndCue;

	public SECTR_AudioCue onRestBeginCue;

	public SECTR_AudioCue onRestLoopCue;

	public SECTR_AudioCue onRestEndCue;

	public SECTR_AudioCue onHappyCue;

	public SECTR_AudioCue onGrumpyCue;

	public SECTR_AudioCue onBoppedCue;

	public SECTR_AudioCue onBatteryFilledCue;

	public SECTR_AudioCue onGuiEnableCue;

	public SECTR_AudioCue onGuiDisableCue;

	public SECTR_AudioCue onGuiButtonTargetCue;

	public SECTR_AudioCue onGuiButtonSourceCue;

	public SECTR_AudioCue onGuiButtonDestinationCue;

	public SECTR_AudioCue onGuiButtonActivateCue;

	public SECTR_AudioCue onGuiButtonResetCue;

	[Header("FX")]
	public GameObject onBatteryFilledFX;

	public GameObject onTeleportFX;

	[Header("Coins Override")]
	public Sprite coinsIcon;

	public Color coinsColor;

	public SECTR_AudioCue coinsCue;

	public const string TARGET_NONE_ID = "drone.target.none";

	public const string BEHAVIOUR_NONE_ID = "drone.behaviour.none";

	public Program.Target[] targets { get; private set; }

	public Program.Behaviour[] sources { get; private set; }

	public Program.Behaviour[] destinations { get; private set; }

	public void OnEnable()
	{
		targets = new Program.Target[39]
		{
			new Program.Target.Collection("plorts", Identifiable.PLORT_CLASS, imageTargetCollectionPlorts),
			new Program.Target.Collection("veggies", Identifiable.VEGGIE_CLASS, imageTargetCollectionVeggies),
			new Program.Target.Collection("fruits", Identifiable.FRUIT_CLASS, imageTargetCollectionFruits),
			new Program.Target.Collection("meats", Identifiable.MEAT_CLASS, imageTargetCollectionMeats),
			new Program.Target.Collection("elders", Identifiable.ELDER_CLASS, imageTargetCollectionElders),
			new Program.Target.Basic(Identifiable.Id.PINK_PLORT),
			new Program.Target.Basic(Identifiable.Id.ROCK_PLORT),
			new Program.Target.Basic(Identifiable.Id.TABBY_PLORT),
			new Program.Target.Basic(Identifiable.Id.PHOSPHOR_PLORT),
			new Program.Target.Basic(Identifiable.Id.RAD_PLORT),
			new Program.Target.Basic(Identifiable.Id.BOOM_PLORT),
			new Program.Target.Basic(Identifiable.Id.HONEY_PLORT),
			new Program.Target.Basic(Identifiable.Id.PUDDLE_PLORT),
			new Program.Target.Basic(Identifiable.Id.CRYSTAL_PLORT),
			new Program.Target.Basic(Identifiable.Id.HUNTER_PLORT),
			new Program.Target.Basic(Identifiable.Id.QUANTUM_PLORT),
			new Program.Target.Basic(Identifiable.Id.MOSAIC_PLORT),
			new Program.Target.Basic(Identifiable.Id.DERVISH_PLORT),
			new Program.Target.Basic(Identifiable.Id.TANGLE_PLORT),
			new Program.Target.Basic(Identifiable.Id.FIRE_PLORT),
			new Program.Target.Basic(Identifiable.Id.SABER_PLORT),
			new Program.Target.Basic(Identifiable.Id.CARROT_VEGGIE),
			new Program.Target.Basic(Identifiable.Id.OCAOCA_VEGGIE),
			new Program.Target.Basic(Identifiable.Id.BEET_VEGGIE),
			new Program.Target.Basic(Identifiable.Id.PARSNIP_VEGGIE),
			new Program.Target.Basic(Identifiable.Id.ONION_VEGGIE),
			new Program.Target.Basic(Identifiable.Id.POGO_FRUIT),
			new Program.Target.Basic(Identifiable.Id.MANGO_FRUIT),
			new Program.Target.Basic(Identifiable.Id.CUBERRY_FRUIT),
			new Program.Target.Basic(Identifiable.Id.LEMON_FRUIT),
			new Program.Target.Basic(Identifiable.Id.PEAR_FRUIT),
			new Program.Target.Basic(Identifiable.Id.HEN),
			new Program.Target.Basic(Identifiable.Id.ROOSTER),
			new Program.Target.Basic(Identifiable.Id.STONY_HEN),
			new Program.Target.Basic(Identifiable.Id.BRIAR_HEN),
			new Program.Target.Basic(Identifiable.Id.PAINTED_HEN),
			new Program.Target.Basic(Identifiable.Id.ELDER_HEN),
			new Program.Target.Basic(Identifiable.Id.ELDER_ROOSTER),
			new Program.Target.Basic(Identifiable.Id.SPICY_TOFU)
		};
		sources = new Program.Behaviour[9]
		{
			new Program.Behaviour
			{
				id = "m.drone.source.name.corral",
				image = imageSourceCorral,
				types = new Type[1] { typeof(DroneProgramSourceCorral) },
				isCompatible = (_003C_003Ec._003C_003E9__55_0 ?? (_003C_003Ec._003C_003E9__55_0 = _003C_003Ec._003C_003E9._003COnEnable_003Eb__55_0))
			},
			new Program.Behaviour
			{
				id = "m.drone.source.name.pond",
				image = imageSourcePond,
				types = new Type[1] { typeof(DroneProgramSourcePond) },
				isCompatible = (_003C_003Ec._003C_003E9__55_1 ?? (_003C_003Ec._003C_003E9__55_1 = _003C_003Ec._003C_003E9._003COnEnable_003Eb__55_1))
			},
			new Program.Behaviour
			{
				id = "m.drone.source.name.incinerator",
				image = imageSourceIncinerator,
				types = new Type[1] { typeof(DroneProgramSourceIncinerator) },
				isCompatible = (_003C_003Ec._003C_003E9__55_2 ?? (_003C_003Ec._003C_003E9__55_2 = _003C_003Ec._003C_003E9._003COnEnable_003Eb__55_2))
			},
			new Program.Behaviour
			{
				id = "m.drone.source.name.garden",
				image = imageSourceGarden,
				types = new Type[1] { typeof(DroneProgramSourceGarden) },
				isCompatible = (_003C_003Ec._003C_003E9__55_3 ?? (_003C_003Ec._003C_003E9__55_3 = _003C_003Ec._003C_003E9._003COnEnable_003Eb__55_3))
			},
			new Program.Behaviour
			{
				id = "m.drone.source.name.coop",
				image = imageSourceCoop,
				isCompatible = (_003C_003Ec._003C_003E9__55_4 ?? (_003C_003Ec._003C_003E9__55_4 = _003C_003Ec._003C_003E9._003COnEnable_003Eb__55_4)),
				types = new Type[2]
				{
					typeof(DroneProgramSourceElderCollector),
					typeof(DroneProgramSourceCoop)
				}
			},
			new Program.Behaviour
			{
				id = "m.drone.source.name.silo",
				image = imageSourceSilo,
				types = new Type[1] { typeof(DroneProgramSourceSilo) }
			},
			new Program.Behaviour
			{
				id = "m.drone.source.name.plort_collector",
				image = imageSourcePlortCollector,
				types = new Type[1] { typeof(DroneProgramSourcePlortCollector) },
				isCompatible = (_003C_003Ec._003C_003E9__55_5 ?? (_003C_003Ec._003C_003E9__55_5 = _003C_003Ec._003C_003E9._003COnEnable_003Eb__55_5))
			},
			new Program.Behaviour
			{
				id = "m.drone.source.name.dynamic",
				image = imageSourceOutsidePlots,
				types = new Type[1] { typeof(DroneProgramSourceOutsidePlots) },
				isCompatible = (_003C_003Ec._003C_003E9__55_6 ?? (_003C_003Ec._003C_003E9__55_6 = _003C_003Ec._003C_003E9._003COnEnable_003Eb__55_6))
			},
			new Program.Behaviour
			{
				id = "m.drone.source.name.free_range",
				image = imageSourceFreeRange,
				types = new Type[1] { typeof(DroneProgramSourceFreeRange) },
				isCompatible = (_003C_003Ec._003C_003E9__55_7 ?? (_003C_003Ec._003C_003E9__55_7 = _003C_003Ec._003C_003E9._003COnEnable_003Eb__55_7))
			}
		};
		destinations = new Program.Behaviour[6]
		{
			new Program.Behaviour
			{
				id = "m.drone.destination.name.corral",
				image = imageDestinationCorral,
				types = new Type[1] { typeof(DroneProgramDestinationCorral) },
				isCompatible = (_003C_003Ec._003C_003E9__55_8 ?? (_003C_003Ec._003C_003E9__55_8 = _003C_003Ec._003C_003E9._003COnEnable_003Eb__55_8))
			},
			new Program.Behaviour
			{
				id = "m.drone.destination.name.silo",
				image = imageDestinationSilo,
				types = new Type[1] { typeof(DroneProgramDestinationSilo) }
			},
			new Program.Behaviour
			{
				id = "m.drone.destination.name.auto_feeder",
				image = imageDestinationFeeder,
				types = new Type[1] { typeof(DroneProgramDestinationFeeder) },
				isCompatible = (_003C_003Ec._003C_003E9__55_9 ?? (_003C_003Ec._003C_003E9__55_9 = _003C_003Ec._003C_003E9._003COnEnable_003Eb__55_9))
			},
			new Program.Behaviour
			{
				id = "m.drone.destination.name.incinerator",
				image = imageDestinationIncinerator,
				types = new Type[1] { typeof(DroneProgramDestinationIncinerator) },
				isCompatible = (_003C_003Ec._003C_003E9__55_10 ?? (_003C_003Ec._003C_003E9__55_10 = _003C_003Ec._003C_003E9._003COnEnable_003Eb__55_10))
			},
			new Program.GadgetBehaviour
			{
				id = "m.drone.destination.name.plort_market",
				image = imageDestinationPlortMarket,
				types = new Type[1] { typeof(DroneProgramDestinationPlortMarket) },
				isCompatible = (_003C_003Ec._003C_003E9__55_11 ?? (_003C_003Ec._003C_003E9__55_11 = _003C_003Ec._003C_003E9._003COnEnable_003Eb__55_11)),
				gadget = Gadget.Id.MARKET_LINK,
				gadgetPredicate = (_003C_003Ec._003C_003E9__55_12 ?? (_003C_003Ec._003C_003E9__55_12 = _003C_003Ec._003C_003E9._003COnEnable_003Eb__55_12))
			},
			new Program.GadgetBehaviour
			{
				id = "m.drone.destination.name.refinery",
				image = imageDestinationRefinery,
				types = new Type[1] { typeof(DroneProgramDestinationRefinery) },
				isCompatible = (_003C_003Ec._003C_003E9__55_14 ?? (_003C_003Ec._003C_003E9__55_14 = _003C_003Ec._003C_003E9._003COnEnable_003Eb__55_14)),
				gadget = Gadget.Id.REFINERY_LINK,
				gadgetPredicate = (_003C_003Ec._003C_003E9__55_15 ?? (_003C_003Ec._003C_003E9__55_15 = _003C_003Ec._003C_003E9._003COnEnable_003Eb__55_15))
			}
		};
	}

	public Program.Target GetDefaultTarget()
	{
		return new Program.Target
		{
			id = "drone.target.none",
			image = imageNone,
			predicate = (_003C_003Ec._003C_003E9__58_0 ?? (_003C_003Ec._003C_003E9__58_0 = _003C_003Ec._003C_003E9._003CGetDefaultTarget_003Eb__58_0))
		};
	}

	public Program.Behaviour GetDefaultBehaviour()
	{
		return new Program.Behaviour
		{
			id = "drone.behaviour.none",
			image = imageNone,
			types = new Type[0]
		};
	}
}
