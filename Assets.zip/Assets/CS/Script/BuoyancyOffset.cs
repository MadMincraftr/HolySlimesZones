using System.Collections.Generic;
using UnityEngine;

public class BuoyancyOffset : SRBehaviour
{
	public List<Vector3> centersOfBuoyancy;

	public float buoyancyFactor = 1f;
}
