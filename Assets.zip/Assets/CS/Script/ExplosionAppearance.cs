using System;
using UnityEngine;

[Serializable]
[CreateAssetMenu(menuName = "Slimes/Appearance Extras/Explosion Appearance")]
public class ExplosionAppearance : ScriptableObject
{
	public GameObject explodeFx;
}
