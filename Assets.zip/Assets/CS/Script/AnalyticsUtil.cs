using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using UnityEngine;

public static class AnalyticsUtil
{
	private interface IListener
	{
		void CustomEvent(string eventName, IDictionary<string, object> eventData);
	}

	[CompilerGenerated]
	private sealed class _003C_003Ec__DisplayClass1_0
	{
		public string eventName;

		public Dictionary<string, object> eventData;

		internal void _003CCustomEvent_003Eb__0(IListener instance)
		{
			instance.CustomEvent(eventName, eventData);
		}
	}

	public const string EVENT_SESSION_ENDED = "SessionEnded";

	public const string NULL = "null";

	private static List<IListener> Listeners = new List<IListener>();

	public static void CustomEvent(string eventName, IDictionary<string, object> customEventData = null, bool includeDefaultEventData = true)
	{
		_003C_003Ec__DisplayClass1_0 _003C_003Ec__DisplayClass1_ = new _003C_003Ec__DisplayClass1_0();
		_003C_003Ec__DisplayClass1_.eventName = eventName;
		_003C_003Ec__DisplayClass1_.eventData = ((customEventData != null) ? new Dictionary<string, object>(customEventData) : new Dictionary<string, object>());
		if (includeDefaultEventData)
		{
			foreach (KeyValuePair<string, object> defaultEventDatum in GetDefaultEventData())
			{
				if (!_003C_003Ec__DisplayClass1_.eventData.ContainsKey(defaultEventDatum.Key))
				{
					_003C_003Ec__DisplayClass1_.eventData[defaultEventDatum.Key] = defaultEventDatum.Value;
				}
			}
		}
		Listeners.ForEach(_003C_003Ec__DisplayClass1_._003CCustomEvent_003Eb__0);
	}

	private static Dictionary<string, object> GetDefaultEventData()
	{
		try
		{
			return new Dictionary<string, object>
			{
				{
					"Game.Id",
					SRSingleton<GameContext>.Instance.AutoSaveDirector.SavedGame.GetName()
				},
				{
					"Game.Mode",
					SRSingleton<SceneContext>.Instance.GameModel.currGameMode
				},
				{
					"Player.Position",
					GetEventData(SRSingleton<SceneContext>.Instance.Player.transform.position)
				},
				{
					"Player.Region",
					SRSingleton<SceneContext>.Instance.RegionRegistry.GetCurrentRegionSetId()
				},
				{
					"Player.Zone",
					SRSingleton<SceneContext>.Instance.Player.GetComponent<PlayerZoneTracker>().GetCurrentZone()
				},
				{
					"Time.WorldTime",
					GetEventData(SRSingleton<SceneContext>.Instance.TimeDirector.WorldTime(), 0)
				}
			};
		}
		catch (Exception ex)
		{
			Log.Warning("Failed to get default analytics event metadata.", "exception", ex);
		}
		return new Dictionary<string, object>();
	}

	public static string GetEventData(GameObject gameObject)
	{
		if (gameObject == null)
		{
			return "null";
		}
		Identifiable componentInParent = gameObject.GetComponentInParent<Identifiable>();
		if (componentInParent != null)
		{
			return componentInParent.id.ToString();
		}
		return gameObject.name;
	}

	public static string GetEventData(Vector3 vector3)
	{
		return string.Format("{{\"x\":{0},\"y\":{1},\"z\":{2}}}", GetEventData(vector3.x), GetEventData(vector3.y), GetEventData(vector3.z));
	}

	public static string GetEventData(double value, int decimals = 2)
	{
		return value.ToString(string.Format("F{0}", decimals));
	}

	public static string GetEventData(float value, int decimals = 2)
	{
		return value.ToString(string.Format("F{0}", decimals));
	}
}
