using System;

public interface IDateProvider
{
	DateTime GetToday();
}
