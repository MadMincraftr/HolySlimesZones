using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;

public class DroneProgramDestinationFeeder : DroneProgramDestinationSiloStorage<DroneProgramDestinationFeeder.Destination>
{
	public class Destination : DroneNetwork.StorageMetadata
	{
		public class Comparer : SRComparer<Destination>
		{
			[Serializable]
			[CompilerGenerated]
			private sealed class _003C_003Ec
			{
				public static readonly _003C_003Ec _003C_003E9 = new _003C_003Ec();

				internal bool _003C_002Ecctor_003Eb__2_0(Destination m)
				{
					return m.seeded;
				}

				internal int _003C_002Ecctor_003Eb__2_1(Destination m)
				{
					return m.count;
				}

				internal bool _003C_002Ecctor_003Eb__2_2(Destination m)
				{
					return m.corral.anyFavorite;
				}

				internal int _003C_002Ecctor_003Eb__2_3(Destination m)
				{
					return m.corral.available;
				}
			}

			public new static Comparer<Destination> Default = new Comparer().OrderByDescending<bool>(_003C_003Ec._003C_003E9._003C_002Ecctor_003Eb__2_0).OrderBy<int>(_003C_003Ec._003C_003E9._003C_002Ecctor_003Eb__2_1).OrderByDescending<bool>(_003C_003Ec._003C_003E9._003C_002Ecctor_003Eb__2_2)
				.OrderBy<int>(_003C_003Ec._003C_003E9._003C_002Ecctor_003Eb__2_3);
		}

		public readonly DroneProgramDestinationCorral.Destination corral;

		public readonly bool seeded;

		public Destination(DroneNetwork.StorageMetadata storage, DroneNetwork.LandPlotMetadata metadata, Identifiable.Id id)
			: base(storage)
		{
			corral = new DroneProgramDestinationCorral.Destination(metadata, id);
			seeded = storage.id == id;
		}
	}

	[CompilerGenerated]
	private sealed class _003C_003Ec__DisplayClass0_0
	{
		public Identifiable.Id id;

		public bool overflow;

		public Func<DroneNetwork.StorageMetadata, bool> _003C_003E9__2;

		internal IEnumerable<Destination> _003CGetDestinations_003Eb__0(DroneNetwork.LandPlotMetadata m)
		{
			_003C_003Ec__DisplayClass0_1 _003C_003Ec__DisplayClass0_ = new _003C_003Ec__DisplayClass0_1
			{
				CS_0024_003C_003E8__locals1 = this,
				m = m
			};
			return _003C_003Ec__DisplayClass0_.m.feeders.Where(_003C_003E9__2 ?? (_003C_003E9__2 = _003CGetDestinations_003Eb__2)).Select(_003C_003Ec__DisplayClass0_._003CGetDestinations_003Eb__3);
		}

		internal bool _003CGetDestinations_003Eb__2(DroneNetwork.StorageMetadata s)
		{
			return s.storage.CanAccept(id, s.index, overflow);
		}
	}

	[CompilerGenerated]
	private sealed class _003C_003Ec__DisplayClass0_1
	{
		public DroneNetwork.LandPlotMetadata m;

		public _003C_003Ec__DisplayClass0_0 CS_0024_003C_003E8__locals1;

		internal Destination _003CGetDestinations_003Eb__3(DroneNetwork.StorageMetadata s)
		{
			return new Destination(s, m, CS_0024_003C_003E8__locals1.id);
		}
	}

	[Serializable]
	[CompilerGenerated]
	private sealed class _003C_003Ec
	{
		public static readonly _003C_003Ec _003C_003E9 = new _003C_003Ec();

		public static Func<Destination, bool> _003C_003E9__0_1;

		public static Func<Destination, Destination> _003C_003E9__1_0;

		internal bool _003CGetDestinations_003Eb__0_1(Destination m)
		{
			if (!m.seeded)
			{
				return m.corral.anyEat;
			}
			return true;
		}

		internal Destination _003CPrioritize_003Eb__1_0(Destination d)
		{
			return d;
		}
	}

	protected override IEnumerable<Destination> GetDestinations(Identifiable.Id id, bool overflow)
	{
		_003C_003Ec__DisplayClass0_0 _003C_003Ec__DisplayClass0_ = new _003C_003Ec__DisplayClass0_0();
		_003C_003Ec__DisplayClass0_.id = id;
		_003C_003Ec__DisplayClass0_.overflow = overflow;
		return drone.network.Plots.SelectMany(_003C_003Ec__DisplayClass0_._003CGetDestinations_003Eb__0).Where(_003C_003Ec._003C_003E9__0_1 ?? (_003C_003Ec._003C_003E9__0_1 = _003C_003Ec._003C_003E9._003CGetDestinations_003Eb__0_1));
	}

	protected override IEnumerable<Destination> Prioritize(IEnumerable<Destination> destinations)
	{
		return destinations.OrderBy(_003C_003Ec._003C_003E9__1_0 ?? (_003C_003Ec._003C_003E9__1_0 = _003C_003Ec._003C_003E9._003CPrioritize_003Eb__1_0), Destination.Comparer.Default);
	}
}
