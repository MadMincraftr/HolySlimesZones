public enum eMoveMethod
{
	LeftRight = 0,
	UpDown = 1,
	CircularXY_Clockwise = 2,
	CircularXY_CounterClockwise = 3,
	CircularXZ_Clockwise = 4,
	CircularXZ_CounterClockwise = 5,
	CircularYZ_Clockwise = 6,
	CircularYZ_CounterClockwise = 7
}
