using System;
using System.Runtime.CompilerServices;

public class AmmoModel
{
	[CompilerGenerated]
	private sealed class _003C_003Ec__DisplayClass8_0
	{
		public int[] deprecatedMaxSlotCounts;

		internal int _003CReset_003Eb__0(Identifiable.Id id, int index)
		{
			return deprecatedMaxSlotCounts[index];
		}
	}

	public Ammo.Slot[] slots;

	public int usableSlots;

	private Func<Identifiable.Id, int, int> slotMaxCountFunction;

	public void IncreaseUsableSlots(int usableSlots)
	{
		this.usableSlots = Math.Max(this.usableSlots, usableSlots);
	}

	public int GetSlotMaxCount(Identifiable.Id id, int index)
	{
		return slotMaxCountFunction(id, index);
	}

	public void SetSlotMaxCountFunction(Func<Identifiable.Id, int, int> slotMaxCountFunction)
	{
		this.slotMaxCountFunction = slotMaxCountFunction;
	}

	public void Push(Ammo.Slot[] slots)
	{
		this.slots = slots;
	}

	public void Pull(out Ammo.Slot[] slots)
	{
		slots = this.slots;
	}

	public void Reset(int numSlots, int initUsableSlots, int[] deprecatedMaxSlotCounts)
	{
		_003C_003Ec__DisplayClass8_0 _003C_003Ec__DisplayClass8_ = new _003C_003Ec__DisplayClass8_0();
		_003C_003Ec__DisplayClass8_.deprecatedMaxSlotCounts = deprecatedMaxSlotCounts;
		Reset(numSlots, initUsableSlots, _003C_003Ec__DisplayClass8_._003CReset_003Eb__0);
	}

	public void Reset(int numSlots, int initUsableSlots, Func<Identifiable.Id, int, int> initSlotMaxCountFunction)
	{
		slots = new Ammo.Slot[numSlots];
		usableSlots = initUsableSlots;
		slotMaxCountFunction = initSlotMaxCountFunction;
	}
}
