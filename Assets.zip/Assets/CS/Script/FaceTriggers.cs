public class FaceTriggers
{
	public const string AWE = "triggerAwe";

	public const string LONG_AWE = "triggerLongAwe";

	public const string ALARM = "triggerAlarm";

	public const string WINCE = "triggerWince";

	public const string MINOR_WINCE = "triggerMinorWince";

	public const string ATTACK_TELEGRAPH = "triggerAttackTelegraph";

	public const string CHOMP_OPEN = "triggerChompOpen";

	public const string CHOMP_OPEN_QUICK = "triggerChompOpenQuick";

	public const string CHOMP_CLOSED = "triggerChompClosed";

	public const string INVOKE = "triggerConcentrate";

	public const string GRIMACE = "triggerGrimace";

	public const string FRIED = "triggerFried";

	public const string SNEEZE = "triggerSneeze";
}
