using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using UnityEngine;

public class ClearAreaFeralsOnHit : MonoBehaviour
{
	[Serializable]
	[CompilerGenerated]
	private sealed class _003C_003Ec
	{
		public static readonly _003C_003Ec _003C_003E9 = new _003C_003Ec();

		public static SphereOverlapTrigger.OnSphereOverlap _003C_003E9__9_0;

		internal void _003CHandleCollision_003Eb__9_0(IEnumerable<Collider> colliders)
		{
			foreach (Collider collider in colliders)
			{
				SlimeFeral component = collider.GetComponent<SlimeFeral>();
				if (component != null)
				{
					component.ClearFeral(true);
				}
			}
		}
	}

	public float radius = 20f;

	public float minTimeBetween = 1f;

	public SECTR_AudioCue hitCue;

	private float nextTime;

	private WaitForChargeup waiter;

	public void Awake()
	{
		waiter = GetComponentInParent<WaitForChargeup>();
	}

	public void OnCollisionEnter(Collision col)
	{
		MaybeHandleCollision();
	}

	public void OnControllerCollision(GameObject gameObj)
	{
		MaybeHandleCollision();
	}

	private void MaybeHandleCollision()
	{
		if (!waiter.IsWaiting() && Time.time >= nextTime)
		{
			HandleCollision();
			nextTime = Time.time + minTimeBetween;
		}
	}

	private void HandleCollision()
	{
		SphereOverlapTrigger.CreateGameObject(base.transform.position, radius, _003C_003Ec._003C_003E9__9_0 ?? (_003C_003Ec._003C_003E9__9_0 = _003C_003Ec._003C_003E9._003CHandleCollision_003Eb__9_0));
		if (hitCue != null)
		{
			SECTR_AudioSystem.Play(hitCue, base.transform.position, false);
		}
	}

	private void OnDrawGizmosSelected()
	{
		Gizmos.color = Color.white;
		Gizmos.DrawWireSphere(base.transform.position, radius);
	}
}
