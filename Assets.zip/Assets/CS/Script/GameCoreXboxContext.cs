using RichPresence;
using UnityEngine;

public class GameCoreXboxContext : MonoBehaviour, Handler
{
	public GameCoreEngagementPopupUI engagementPopupUIPrefab;

	public XboxUserChangePopupUI userChangePopupUIPrefab;

	public void SetRichPresence(MainMenuData data)
	{
	}

	public void SetRichPresence(InZoneData data)
	{
	}
}
