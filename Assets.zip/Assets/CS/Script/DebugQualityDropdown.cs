using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using UnityEngine;
using UnityEngine.UI;

public class DebugQualityDropdown : MonoBehaviour
{
	[CompilerGenerated]
	private sealed class _003C_003Ec__DisplayClass1_0
	{
		public List<SRQualitySettings.Level> levels;

		internal void _003CAwake_003Eb__1(int index)
		{
			SRQualitySettings.CurrentLevel = levels[index];
		}
	}

	[Serializable]
	[CompilerGenerated]
	private sealed class _003C_003Ec
	{
		public static readonly _003C_003Ec _003C_003E9 = new _003C_003Ec();

		public static Func<SRQualitySettings.Level, string> _003C_003E9__1_0;

		internal string _003CAwake_003Eb__1_0(SRQualitySettings.Level level)
		{
			return Enum.GetName(typeof(SRQualitySettings.Level), level);
		}
	}

	public Dropdown dropdown;

	public void Awake()
	{
		_003C_003Ec__DisplayClass1_0 _003C_003Ec__DisplayClass1_ = new _003C_003Ec__DisplayClass1_0();
		_003C_003Ec__DisplayClass1_.levels = new List<SRQualitySettings.Level>
		{
			SRQualitySettings.Level.LOWEST,
			SRQualitySettings.Level.LOW,
			SRQualitySettings.Level.DEFAULT,
			SRQualitySettings.Level.HIGH,
			SRQualitySettings.Level.VERY_HIGH
		};
		dropdown.ClearOptions();
		dropdown.AddOptions(_003C_003Ec__DisplayClass1_.levels.Select(_003C_003Ec._003C_003E9__1_0 ?? (_003C_003Ec._003C_003E9__1_0 = _003C_003Ec._003C_003E9._003CAwake_003Eb__1_0)).ToList());
		dropdown.onValueChanged.AddListener(_003C_003Ec__DisplayClass1_._003CAwake_003Eb__1);
		dropdown.value = 2;
	}
}
