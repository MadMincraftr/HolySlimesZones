using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using DLCPackage;

public abstract class DLCProvider
{
	[Serializable]
	[CompilerGenerated]
	private sealed class _003C_003Ec
	{
		public static readonly _003C_003Ec _003C_003E9 = new _003C_003Ec();

		public static Func<Id, Id> _003C_003E9__2_0;

		public static Func<Id, State> _003C_003E9__2_1;

		public static Func<Id, Id> _003C_003E9__3_0;

		public static Func<Id, State> _003C_003E9__3_1;

		internal Id _003C_002Ector_003Eb__2_0(Id id)
		{
			return id;
		}

		internal State _003C_002Ector_003Eb__2_1(Id id)
		{
			return State.AVAILABLE;
		}

		internal Id _003CResetAllPackageStates_003Eb__3_0(Id id)
		{
			return id;
		}

		internal State _003CResetAllPackageStates_003Eb__3_1(Id id)
		{
			return State.AVAILABLE;
		}
	}

	private HashSet<Id> supported;

	private Dictionary<Id, State> cache;

	public DLCProvider(IEnumerable<Id> supported)
	{
		this.supported = new HashSet<Id>(supported, IdComparer.Instance);
		cache = this.supported.ToDictionary(_003C_003Ec._003C_003E9__2_0 ?? (_003C_003Ec._003C_003E9__2_0 = _003C_003Ec._003C_003E9._003C_002Ector_003Eb__2_0), _003C_003Ec._003C_003E9__2_1 ?? (_003C_003Ec._003C_003E9__2_1 = _003C_003Ec._003C_003E9._003C_002Ector_003Eb__2_1), IdComparer.Instance);
	}

	protected void ResetAllPackageStates()
	{
		cache = supported.ToDictionary(_003C_003Ec._003C_003E9__3_0 ?? (_003C_003Ec._003C_003E9__3_0 = _003C_003Ec._003C_003E9._003CResetAllPackageStates_003Eb__3_0), _003C_003Ec._003C_003E9__3_1 ?? (_003C_003Ec._003C_003E9__3_1 = _003C_003Ec._003C_003E9._003CResetAllPackageStates_003Eb__3_1), IdComparer.Instance);
	}

	public abstract IEnumerator Refresh();

	public abstract void ShowInStore(Id id);

	public IEnumerable<Id> GetSupported()
	{
		return supported;
	}

	public State GetState(Id id)
	{
		State value;
		cache.TryGetValue(id, out value);
		return value;
	}

	protected bool SetState(Id id, State state)
	{
		State state2 = GetState(id);
		if (state2 > state)
		{
			Log.Error("Attempting to downgrade DLC state.", "id", id, "current", state2, "updated", state);
			return false;
		}
		cache[id] = state;
		return true;
	}
}
