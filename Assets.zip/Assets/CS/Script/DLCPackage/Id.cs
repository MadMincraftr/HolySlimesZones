namespace DLCPackage
{
	public enum Id
	{
		PLAYSET_PIRATE = 1,
		PLAYSET_HEROIC = 2,
		PLAYSET_SCIFI = 3,
		SECRET_STYLE = 100
	}
}
