namespace DLCPackage
{
	public enum State
	{
		UNDEFINED = 0,
		AVAILABLE = 1,
		REQUIRES_ASSETS = 2,
		INSTALLED = 3
	}
}
