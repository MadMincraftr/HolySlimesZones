using System;
using System.Runtime.CompilerServices;
using UnityEngine;

public class EmptyPlotUI : LandPlotUI
{
	[Serializable]
	[CompilerGenerated]
	private sealed class _003C_003Ec
	{
		public static readonly _003C_003Ec _003C_003E9 = new _003C_003Ec();

		public static Func<bool> _003C_003E9__7_0;

		public static Func<bool> _003C_003E9__7_1;

		public static Func<bool> _003C_003E9__7_2;

		public static Func<bool> _003C_003E9__7_3;

		public static Func<bool> _003C_003E9__7_4;

		public static Func<bool> _003C_003E9__7_5;

		public static Func<bool> _003C_003E9__7_6;

		public static Func<bool> _003C_003E9__7_7;

		public static Func<bool> _003C_003E9__7_8;

		public static Func<bool> _003C_003E9__7_9;

		public static Func<bool> _003C_003E9__7_10;

		public static Func<bool> _003C_003E9__7_11;

		internal bool _003CCreatePurchaseUI_003Eb__7_0()
		{
			return true;
		}

		internal bool _003CCreatePurchaseUI_003Eb__7_1()
		{
			return true;
		}

		internal bool _003CCreatePurchaseUI_003Eb__7_2()
		{
			return true;
		}

		internal bool _003CCreatePurchaseUI_003Eb__7_3()
		{
			return true;
		}

		internal bool _003CCreatePurchaseUI_003Eb__7_4()
		{
			return true;
		}

		internal bool _003CCreatePurchaseUI_003Eb__7_5()
		{
			return true;
		}

		internal bool _003CCreatePurchaseUI_003Eb__7_6()
		{
			return true;
		}

		internal bool _003CCreatePurchaseUI_003Eb__7_7()
		{
			return true;
		}

		internal bool _003CCreatePurchaseUI_003Eb__7_8()
		{
			return true;
		}

		internal bool _003CCreatePurchaseUI_003Eb__7_9()
		{
			return true;
		}

		internal bool _003CCreatePurchaseUI_003Eb__7_10()
		{
			return true;
		}

		internal bool _003CCreatePurchaseUI_003Eb__7_11()
		{
			return true;
		}
	}

	[Tooltip("The icon we show next to the overall title for the UI")]
	public Sprite titleIcon;

	[Tooltip("Specifies our info for the corral item")]
	public PlotPurchaseItem corral;

	[Tooltip("Specifies our info for the garden item")]
	public PlotPurchaseItem garden;

	[Tooltip("Specifies our info for the coop item")]
	public PlotPurchaseItem coop;

	[Tooltip("Specifies our info for the silo item")]
	public PlotPurchaseItem silo;

	[Tooltip("Specifies our info for the incinerator item")]
	public PlotPurchaseItem incinerator;

	[Tooltip("Specifies our info for the pond item")]
	public PlotPurchaseItem pond;

	protected override GameObject CreatePurchaseUI()
	{
		PurchaseUI.Purchasable[] purchasables = new PurchaseUI.Purchasable[6]
		{
			new PurchaseUI.Purchasable("t.corral", corral.icon, corral.img, "m.intro.corral", corral.cost, PediaDirector.Id.CORRAL, BuyCorral, _003C_003Ec._003C_003E9__7_0 ?? (_003C_003Ec._003C_003E9__7_0 = _003C_003Ec._003C_003E9._003CCreatePurchaseUI_003Eb__7_0), _003C_003Ec._003C_003E9__7_1 ?? (_003C_003Ec._003C_003E9__7_1 = _003C_003Ec._003C_003E9._003CCreatePurchaseUI_003Eb__7_1)),
			new PurchaseUI.Purchasable("t.garden", garden.icon, garden.img, "m.intro.garden", garden.cost, PediaDirector.Id.GARDEN, BuyGarden, _003C_003Ec._003C_003E9__7_2 ?? (_003C_003Ec._003C_003E9__7_2 = _003C_003Ec._003C_003E9._003CCreatePurchaseUI_003Eb__7_2), _003C_003Ec._003C_003E9__7_3 ?? (_003C_003Ec._003C_003E9__7_3 = _003C_003Ec._003C_003E9._003CCreatePurchaseUI_003Eb__7_3)),
			new PurchaseUI.Purchasable("t.coop", coop.icon, coop.img, "m.intro.coop", coop.cost, PediaDirector.Id.COOP, BuyCoop, _003C_003Ec._003C_003E9__7_4 ?? (_003C_003Ec._003C_003E9__7_4 = _003C_003Ec._003C_003E9._003CCreatePurchaseUI_003Eb__7_4), _003C_003Ec._003C_003E9__7_5 ?? (_003C_003Ec._003C_003E9__7_5 = _003C_003Ec._003C_003E9._003CCreatePurchaseUI_003Eb__7_5)),
			new PurchaseUI.Purchasable("t.silo", silo.icon, silo.img, "m.intro.silo", silo.cost, PediaDirector.Id.SILO, BuySilo, _003C_003Ec._003C_003E9__7_6 ?? (_003C_003Ec._003C_003E9__7_6 = _003C_003Ec._003C_003E9._003CCreatePurchaseUI_003Eb__7_6), _003C_003Ec._003C_003E9__7_7 ?? (_003C_003Ec._003C_003E9__7_7 = _003C_003Ec._003C_003E9._003CCreatePurchaseUI_003Eb__7_7)),
			new PurchaseUI.Purchasable("t.incinerator", incinerator.icon, incinerator.img, "m.intro.incinerator", incinerator.cost, PediaDirector.Id.INCINERATOR, BuyIncinerator, _003C_003Ec._003C_003E9__7_8 ?? (_003C_003Ec._003C_003E9__7_8 = _003C_003Ec._003C_003E9._003CCreatePurchaseUI_003Eb__7_8), _003C_003Ec._003C_003E9__7_9 ?? (_003C_003Ec._003C_003E9__7_9 = _003C_003Ec._003C_003E9._003CCreatePurchaseUI_003Eb__7_9)),
			new PurchaseUI.Purchasable("t.pond", pond.icon, pond.img, "m.intro.pond", pond.cost, PediaDirector.Id.POND, BuyPond, _003C_003Ec._003C_003E9__7_10 ?? (_003C_003Ec._003C_003E9__7_10 = _003C_003Ec._003C_003E9._003CCreatePurchaseUI_003Eb__7_10), _003C_003Ec._003C_003E9__7_11 ?? (_003C_003Ec._003C_003E9__7_11 = _003C_003Ec._003C_003E9._003CCreatePurchaseUI_003Eb__7_11))
		};
		return SRSingleton<GameContext>.Instance.UITemplates.CreatePurchaseUI(titleIcon, MessageUtil.Qualify("ui", "t.empty_plot"), purchasables, false, Close);
	}

	public void BuyCorral()
	{
		BuyPlot(corral);
	}

	public void BuyGarden()
	{
		if (BuyPlot(garden))
		{
			SRSingleton<SceneContext>.Instance.TutorialDirector.MaybeShowPopup(TutorialDirector.Id.GARDEN);
		}
	}

	public void BuyCoop()
	{
		BuyPlot(coop);
	}

	public void BuySilo()
	{
		BuyPlot(silo);
	}

	public void BuyIncinerator()
	{
		BuyPlot(incinerator);
	}

	public void BuyPond()
	{
		BuyPlot(pond);
	}
}
