using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using MonomiPark.SlimeRancher.DataModel;
using UnityEngine;

public class EchoNoteGordoRanchTeleporter : SRBehaviour
{
	[CompilerGenerated]
	private sealed class _003C_003Ec__DisplayClass1_0
	{
		public HolidayModel holiday;

		internal bool _003COnEnable_003Eb__0(KeyValuePair<string, EchoNoteGordoModel> pair)
		{
			_003C_003Ec__DisplayClass1_1 _003C_003Ec__DisplayClass1_ = new _003C_003Ec__DisplayClass1_1
			{
				pair = pair
			};
			if (_003C_003Ec__DisplayClass1_.pair.Value.state == EchoNoteGordoModel.State.POPPED)
			{
				return holiday.eventEchoNoteGordos.Any(_003C_003Ec__DisplayClass1_._003COnEnable_003Eb__1);
			}
			return false;
		}
	}

	[CompilerGenerated]
	private sealed class _003C_003Ec__DisplayClass1_1
	{
		public KeyValuePair<string, EchoNoteGordoModel> pair;

		internal bool _003COnEnable_003Eb__1(HolidayModel.EventEchoNoteGordo e)
		{
			return e.objectId == pair.Key;
		}
	}

	[Tooltip("Parent GameObject containing the portal ring.")]
	public GameObject ring;

	public void OnEnable()
	{
		_003C_003Ec__DisplayClass1_0 _003C_003Ec__DisplayClass1_ = new _003C_003Ec__DisplayClass1_0();
		_003C_003Ec__DisplayClass1_.holiday = SRSingleton<SceneContext>.Instance.GameModel.GetHolidayModel();
		ring.SetActive(SRSingleton<SceneContext>.Instance.GameModel.AllEchoNoteGordos().Any(_003C_003Ec__DisplayClass1_._003COnEnable_003Eb__0));
	}
}
