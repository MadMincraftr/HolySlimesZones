public enum eCloudFlowBehavior
{
	SwitchLeftRight = 0,
	FlowTheSameWay = 1
}
