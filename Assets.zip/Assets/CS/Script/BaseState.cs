public abstract class BaseState
{
	public string name;

	public bool Enabled;

	public BaseState(string name)
	{
		this.name = name;
	}
}
