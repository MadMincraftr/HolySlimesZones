using UnityEngine;

public class GalaxyDirector : MonoBehaviour
{
}
