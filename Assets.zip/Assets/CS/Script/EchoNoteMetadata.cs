using UnityEngine;

public class EchoNoteMetadata : SRBehaviour
{
	[Tooltip("Echo note identifiable id.")]
	public Identifiable.Id id;
}
