using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;

public class AppearanceSelections
{
	public delegate void OnAppearanceUnlockedForSlimeDelegate(SlimeDefinition slime, SlimeAppearance appearance);

	public delegate void OnAppearanceSelectedForSlimeDelegate(SlimeDefinition slime, SlimeAppearance appearance);

	public delegate void OnAppearanceLockedForSlimeDelegate(SlimeDefinition slime, SlimeAppearance appearance);

	[Serializable]
	[CompilerGenerated]
	private sealed class _003C_003Ec
	{
		public static readonly _003C_003Ec _003C_003E9 = new _003C_003Ec();

		public static OnAppearanceUnlockedForSlimeDelegate _003C_003E9__22_0;

		public static OnAppearanceSelectedForSlimeDelegate _003C_003E9__22_1;

		public static OnAppearanceLockedForSlimeDelegate _003C_003E9__22_2;

		internal void _003C_002Ector_003Eb__22_0(SlimeDefinition _003Cp0_003E, SlimeAppearance _003Cp1_003E)
		{
		}

		internal void _003C_002Ector_003Eb__22_1(SlimeDefinition _003Cp0_003E, SlimeAppearance _003Cp1_003E)
		{
		}

		internal void _003C_002Ector_003Eb__22_2(SlimeDefinition _003Cp0_003E, SlimeAppearance _003Cp1_003E)
		{
		}
	}

	private readonly Dictionary<Identifiable.Id, HashSet<SlimeAppearance>> unlocks = new Dictionary<Identifiable.Id, HashSet<SlimeAppearance>>();

	private readonly Dictionary<Identifiable.Id, SlimeAppearance> selections = new Dictionary<Identifiable.Id, SlimeAppearance>();

	private readonly HashSet<SlimeAppearance> allSelectedAppearances = new HashSet<SlimeAppearance>(SlimeAppearanceEqualityComparer.Default);

	public event OnAppearanceUnlockedForSlimeDelegate onAppearanceUnlocked = _003C_003Ec._003C_003E9__22_0 ?? (_003C_003Ec._003C_003E9__22_0 = _003C_003Ec._003C_003E9._003C_002Ector_003Eb__22_0);

	public event OnAppearanceSelectedForSlimeDelegate onAppearanceSelected = _003C_003Ec._003C_003E9__22_1 ?? (_003C_003Ec._003C_003E9__22_1 = _003C_003Ec._003C_003E9._003C_002Ector_003Eb__22_1);

	public event OnAppearanceLockedForSlimeDelegate onAppearanceLocked = _003C_003Ec._003C_003E9__22_2 ?? (_003C_003Ec._003C_003E9__22_2 = _003C_003Ec._003C_003E9._003C_002Ector_003Eb__22_2);

	public void UnlockAppearanceForSlime(SlimeDefinition slime, SlimeAppearance appearance)
	{
		if (!slime.Appearances.Contains(appearance))
		{
			Log.Error(string.Format("Trying to unlock appearance {0} not attached to a slime definition {1}.", appearance.name, slime.Name));
			return;
		}
		GetOrCreateUnlockSetForSlime(slime).Add(appearance);
		this.onAppearanceUnlocked(slime, appearance);
	}

	public void LockAppearanceForSlime(SlimeDefinition slime, SlimeAppearance appearance)
	{
		HashSet<SlimeAppearance> value;
		if (unlocks.TryGetValue(slime.IdentifiableId, out value))
		{
			value.Remove(appearance);
		}
		this.onAppearanceLocked(slime, appearance);
	}

	public void SelectAppearanceForSlime(SlimeDefinition slime, SlimeAppearance appearance)
	{
		SlimeAppearance selectedAppearance = GetSelectedAppearance(slime);
		if (selectedAppearance != null)
		{
			allSelectedAppearances.Remove(selectedAppearance);
		}
		allSelectedAppearances.Add(appearance);
		selections[slime.IdentifiableId] = appearance;
		this.onAppearanceSelected(slime, appearance);
	}

	public SlimeAppearance GetSelectedAppearance(SlimeDefinition slime)
	{
		SlimeAppearance value;
		if (!selections.TryGetValue(slime.IdentifiableId, out value))
		{
			return null;
		}
		return value;
	}

	public List<SlimeAppearance> GetUnlockedAppearances(SlimeDefinition slime)
	{
		return GetOrCreateUnlockSetForSlime(slime).ToList();
	}

	public HashSet<SlimeAppearance> GetAllSelectedAppearances()
	{
		return allSelectedAppearances;
	}

	private HashSet<SlimeAppearance> GetOrCreateUnlockSetForSlime(SlimeDefinition slime)
	{
		HashSet<SlimeAppearance> value;
		if (!unlocks.TryGetValue(slime.IdentifiableId, out value))
		{
			value = new HashSet<SlimeAppearance>();
			unlocks[slime.IdentifiableId] = value;
		}
		return value;
	}
}
