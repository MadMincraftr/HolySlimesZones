using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;

public abstract class DroneProgramSourceLandPlot : DroneProgramSourceDynamic
{
	private class Intermediate
	{
		public class Comparer : SRComparer<Intermediate>
		{
		}

		public DroneNetwork.LandPlotMetadata metadata;

		public IEnumerable<Identifiable> sources;
	}

	[CompilerGenerated]
	private sealed class _003C_003Ec__DisplayClass5_0
	{
		public DroneProgramSourceLandPlot _003C_003E4__this;

		public Predicate<Identifiable.Id> predicate;

		internal bool _003CGetSources_003Eb__0(DroneNetwork.LandPlotMetadata m)
		{
			return m.plot.typeId == _003C_003E4__this.GetLandPlotID();
		}

		internal Intermediate _003CGetSources_003Eb__1(DroneNetwork.LandPlotMetadata m)
		{
			return new Intermediate
			{
				metadata = m,
				sources = _003C_003E4__this.GetSources(predicate, m)
			};
		}

		internal bool _003CGetSources_003Eb__3(Intermediate o)
		{
			return o.metadata == _003C_003E4__this.currentLandPlot;
		}
	}

	[Serializable]
	[CompilerGenerated]
	private sealed class _003C_003Ec
	{
		public static readonly _003C_003Ec _003C_003E9 = new _003C_003Ec();

		public static Func<Intermediate, Intermediate> _003C_003E9__5_2;

		public static Func<Intermediate, bool> _003C_003E9__5_4;

		public static Func<Intermediate, int> _003C_003E9__5_5;

		public static Func<Intermediate, IEnumerable<Identifiable>> _003C_003E9__5_6;

		public static Func<KeyValuePair<Identifiable.Id, HashSet<Identifiable>>, IEnumerable<Identifiable>> _003C_003E9__6_2;

		internal Intermediate _003CGetSources_003Eb__5_2(Intermediate o)
		{
			return o;
		}

		internal bool _003CGetSources_003Eb__5_4(Intermediate o)
		{
			return GRAYLIST.ContainsKey(o.metadata.GetHashCode());
		}

		internal int _003CGetSources_003Eb__5_5(Intermediate o)
		{
			return o.sources.Count();
		}

		internal IEnumerable<Identifiable> _003CGetSources_003Eb__5_6(Intermediate o)
		{
			return o.sources;
		}

		internal IEnumerable<Identifiable> _003CGetSources_003Eb__6_2(KeyValuePair<Identifiable.Id, HashSet<Identifiable>> kv)
		{
			return kv.Value;
		}
	}

	[CompilerGenerated]
	private sealed class _003C_003Ec__DisplayClass6_0
	{
		public Predicate<Identifiable.Id> predicate;

		public DroneProgramSourceLandPlot _003C_003E4__this;

		public DroneNetwork.LandPlotMetadata metadata;

		public Func<KeyValuePair<Identifiable.Id, HashSet<Identifiable>>, bool> _003C_003E9__1;

		public Func<Identifiable, bool> _003C_003E9__3;

		internal IEnumerable<Identifiable> _003CGetSources_003Eb__0(TrackContainedIdentifiables tracker)
		{
			return tracker.GetAllTracked().Where(_003C_003E9__1 ?? (_003C_003E9__1 = _003CGetSources_003Eb__1)).SelectMany(_003C_003Ec._003C_003E9__6_2 ?? (_003C_003Ec._003C_003E9__6_2 = _003C_003Ec._003C_003E9._003CGetSources_003Eb__6_2))
				.Where(_003C_003E9__3 ?? (_003C_003E9__3 = _003CGetSources_003Eb__3));
		}

		internal bool _003CGetSources_003Eb__1(KeyValuePair<Identifiable.Id, HashSet<Identifiable>> kv)
		{
			return predicate(kv.Key);
		}

		internal bool _003CGetSources_003Eb__3(Identifiable id)
		{
			return _003C_003E4__this.SourcePredicate(metadata, id);
		}
	}

	protected DroneNetwork.LandPlotMetadata currentLandPlot;

	private static ReferenceCount<int> GRAYLIST = new ReferenceCount<int>();

	private int? grayListHashCode;

	public override void Awake()
	{
		base.Awake();
		base.plexer.onSubbehaviourSelected += OnDroneSubbehaviourSelected;
	}

	public override void OnDestroy()
	{
		base.OnDestroy();
		base.plexer.onSubbehaviourSelected -= OnDroneSubbehaviourSelected;
	}

	public override bool Relevancy()
	{
		if (base.Relevancy())
		{
			currentLandPlot = drone.network.GetContaining(source);
			if (currentLandPlot != null)
			{
				grayListHashCode = currentLandPlot.GetHashCode();
				GRAYLIST.Increment(grayListHashCode.Value);
			}
			return true;
		}
		return false;
	}

	public override void Deselected()
	{
		base.Deselected();
		if (grayListHashCode.HasValue)
		{
			GRAYLIST.Decrement(grayListHashCode.Value);
			grayListHashCode = null;
		}
	}

	protected override bool CanCancel()
	{
		if (!base.CanCancel() && currentLandPlot != null)
		{
			return !currentLandPlot.Contains(source);
		}
		return true;
	}

	protected override IEnumerable<Identifiable> GetSources(Predicate<Identifiable.Id> predicate)
	{
		_003C_003Ec__DisplayClass5_0 _003C_003Ec__DisplayClass5_ = new _003C_003Ec__DisplayClass5_0();
		_003C_003Ec__DisplayClass5_._003C_003E4__this = this;
		_003C_003Ec__DisplayClass5_.predicate = predicate;
		return drone.network.Plots.Where(_003C_003Ec__DisplayClass5_._003CGetSources_003Eb__0).Select(_003C_003Ec__DisplayClass5_._003CGetSources_003Eb__1).OrderBy(_003C_003Ec._003C_003E9__5_2 ?? (_003C_003Ec._003C_003E9__5_2 = _003C_003Ec._003C_003E9._003CGetSources_003Eb__5_2), new Intermediate.Comparer().OrderByDescending<bool>(_003C_003Ec__DisplayClass5_._003CGetSources_003Eb__3).OrderBy(_003C_003Ec._003C_003E9__5_4 ?? (_003C_003Ec._003C_003E9__5_4 = _003C_003Ec._003C_003E9._003CGetSources_003Eb__5_4)).OrderByDescending(_003C_003Ec._003C_003E9__5_5 ?? (_003C_003Ec._003C_003E9__5_5 = _003C_003Ec._003C_003E9._003CGetSources_003Eb__5_5)))
			.SelectMany(_003C_003Ec._003C_003E9__5_6 ?? (_003C_003Ec._003C_003E9__5_6 = _003C_003Ec._003C_003E9._003CGetSources_003Eb__5_6));
	}

	protected virtual IEnumerable<Identifiable> GetSources(Predicate<Identifiable.Id> predicate, DroneNetwork.LandPlotMetadata metadata)
	{
		_003C_003Ec__DisplayClass6_0 _003C_003Ec__DisplayClass6_ = new _003C_003Ec__DisplayClass6_0();
		_003C_003Ec__DisplayClass6_.predicate = predicate;
		_003C_003Ec__DisplayClass6_._003C_003E4__this = this;
		_003C_003Ec__DisplayClass6_.metadata = metadata;
		return _003C_003Ec__DisplayClass6_.metadata.trackers.SelectMany(_003C_003Ec__DisplayClass6_._003CGetSources_003Eb__0);
	}

	protected override bool SourcePredicate(DroneNetwork.LandPlotMetadata metadata, Identifiable source)
	{
		if (base.SourcePredicate(metadata, source) && metadata != null)
		{
			return metadata.plot.typeId == GetLandPlotID();
		}
		return false;
	}

	private void OnDroneSubbehaviourSelected(DroneSubbehaviour subbehaviour)
	{
		if (subbehaviour != this && !(subbehaviour is DroneSubbehaviourIdle))
		{
			currentLandPlot = null;
		}
	}

	protected override GardenDroneSubnetwork GetSubnetwork()
	{
		if (currentLandPlot == null)
		{
			return null;
		}
		return currentLandPlot.subnetwork;
	}

	protected abstract LandPlot.Id GetLandPlotID();
}
