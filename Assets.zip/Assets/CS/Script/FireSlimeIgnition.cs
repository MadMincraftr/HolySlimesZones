using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using UnityEngine;

public class FireSlimeIgnition : RegisteredActorBehaviour, Ignitable, LiquidConsumer, RegistryUpdateable, ControllerCollisionListener
{
	[Serializable]
	[CompilerGenerated]
	private sealed class _003C_003Ec
	{
		public static readonly _003C_003Ec _003C_003E9 = new _003C_003Ec();

		public static Predicate<LiquidSource> _003C_003E9__14_0;

		internal bool _003CIgnite_003Eb__14_0(LiquidSource w)
		{
			if (!(w == null))
			{
				return w.gameObject == null;
			}
			return true;
		}
	}

	private bool isIgnited;

	private GameObject fireFXObj;

	private double reigniteAtTime = double.PositiveInfinity;

	private TimeDirector timeDir;

	private List<LiquidSource> waterSources = new List<LiquidSource>();

	private const float EXTINGUISH_HRS = 0.5f;

	public void Awake()
	{
		timeDir = SRSingleton<SceneContext>.Instance.TimeDirector;
	}

	public override void Start()
	{
		base.Start();
		ExtractFire();
		GetComponent<SlimeAppearanceApplicator>().OnAppearanceChanged += _003CStart_003Eb__7_0;
		Ignite(base.gameObject);
	}

	private void ExtractFire()
	{
		FireIndicatorMarker componentInChildren = GetComponentInChildren<FireIndicatorMarker>();
		if (componentInChildren != null)
		{
			fireFXObj = componentInChildren.gameObject;
			fireFXObj.SetActive(isIgnited);
		}
	}

	public void OnCollisionEnter(Collision col)
	{
		if (isIgnited)
		{
			Ignitable component = col.gameObject.GetComponent<Ignitable>();
			if (component != null)
			{
				component.Ignite(base.gameObject);
			}
		}
	}

	public void OnControllerCollision(GameObject gameObj)
	{
		if (isIgnited)
		{
			Ignitable component = gameObj.GetComponent<Ignitable>();
			if (component != null)
			{
				component.Ignite(base.gameObject);
			}
		}
	}

	public void OnTriggerEnter(Collider col)
	{
		LiquidSource component = col.gameObject.GetComponent<LiquidSource>();
		if (component != null && Identifiable.IsWater(component.liquidId))
		{
			waterSources.Add(component);
			Extinguish();
		}
	}

	public void OnTriggerExit(Collider col)
	{
		LiquidSource component = col.gameObject.GetComponent<LiquidSource>();
		if (component != null && Identifiable.IsWater(component.liquidId))
		{
			waterSources.Remove(component);
		}
	}

	public void RegistryUpdate()
	{
		if (!isIgnited && timeDir.HasReached(reigniteAtTime))
		{
			Ignite(base.gameObject);
		}
	}

	public void Ignite(GameObject igniter)
	{
		waterSources.RemoveAll(_003C_003Ec._003C_003E9__14_0 ?? (_003C_003Ec._003C_003E9__14_0 = _003C_003Ec._003C_003E9._003CIgnite_003Eb__14_0));
		if (waterSources.Count <= 0)
		{
			isIgnited = true;
			if (fireFXObj != null)
			{
				fireFXObj.SetActive(true);
			}
		}
	}

	public void Extinguish()
	{
		isIgnited = false;
		if (fireFXObj != null)
		{
			fireFXObj.SetActive(false);
		}
		reigniteAtTime = timeDir.HoursFromNow(0.5f);
	}

	public void AddLiquid(Identifiable.Id liquidId, float units)
	{
		if (Identifiable.IsWater(liquidId))
		{
			Extinguish();
		}
	}

	[CompilerGenerated]
	private void _003CStart_003Eb__7_0(SlimeAppearance appearance)
	{
		ExtractFire();
	}
}
