using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using Assets.Script.Util.Extensions;
using MonomiPark.SlimeRancher.DataModel;
using MonomiPark.SlimeRancher.Regions;
using UnityEngine;

public class GlitchRegionHelper : SRSingleton<GlitchRegionHelper>, AmbianceDirector.TimeOfDay, PlayerModel.Participant
{
	private class GlitchTarrNodeGroupComparer : SRComparer<GlitchTarrNode.Group>
	{
	}

	[Serializable]
	[CompilerGenerated]
	private sealed class _003C_003Ec
	{
		public static readonly _003C_003Ec _003C_003E9 = new _003C_003Ec();

		public static Func<GlitchTeleportDestination, string> _003C_003E9__27_0;

		public static Func<GlitchTeleportDestination, GlitchTeleportDestination> _003C_003E9__27_1;

		public static Predicate<GameObject> _003C_003E9__31_0;

		public static Func<GlitchTarrNode.Group, int> _003C_003E9__31_1;

		public static Func<GlitchTeleportDestination, bool> _003C_003E9__31_2;

		public static Predicate<GameObject> _003C_003E9__31_3;

		internal string _003CAwake_003Eb__27_0(GlitchTeleportDestination d)
		{
			return d.id;
		}

		internal GlitchTeleportDestination _003CAwake_003Eb__27_1(GlitchTeleportDestination d)
		{
			return d;
		}

		internal bool _003CRegionSetChanged_003Eb__31_0(GameObject go)
		{
			RegionMember component = go.GetComponent<RegionMember>();
			if (component != null)
			{
				return component.IsInRegion(RegionRegistry.RegionSetId.SLIMULATIONS);
			}
			return false;
		}

		internal int _003CRegionSetChanged_003Eb__31_1(GlitchTarrNode.Group it)
		{
			return Randoms.SHARED.GetInt();
		}

		internal bool _003CRegionSetChanged_003Eb__31_2(GlitchTeleportDestination e)
		{
			return e.isPotentialExitDestination;
		}

		internal bool _003CRegionSetChanged_003Eb__31_3(GameObject go)
		{
			RegionMember component = go.GetComponent<RegionMember>();
			if (component != null)
			{
				return component.IsInRegion(RegionRegistry.RegionSetId.SLIMULATIONS);
			}
			return false;
		}
	}

	[CompilerGenerated]
	private sealed class _003C_003Ec__DisplayClass31_0
	{
		public PlayerState player;

		internal bool _003CRegionSetChanged_003Eb__4(int ii)
		{
			return player.Ammo.GetSlotName(ii) != Identifiable.Id.GLITCH_BUG_REPORT;
		}
	}

	[Tooltip("Renderer to update the material on death in SLIMULATIONS region.")]
	public Renderer seaRenderer;

	private GameObject exitHudInstance;

	public GlitchImpostoDirector[] impostoDirectors { get; private set; }

	public CellDirector[] cellDirectors { get; private set; }

	public GlitchLiquidSource[] stations { get; private set; }

	public GlitchTarrNode[] nodes { get; private set; }

	public GlitchBreadcrumbNetwork breadcrumbs { get; private set; }

	public Dictionary<string, GlitchTeleportDestination> destinationsDict { get; private set; }

	public IEnumerable<GlitchTeleportDestination> destinations
	{
		get
		{
			return destinationsDict.Values;
		}
	}

	public override void Awake()
	{
		base.Awake();
		SRSingleton<SceneContext>.Instance.GameModel.RegisterPlayerParticipant(this);
		SRSingleton<SceneContext>.Instance.RegionRegistry.ManageWithRegionSet(base.gameObject, RegionRegistry.RegionSetId.SLIMULATIONS);
		ZoneDirector componentInParent = GetComponentInParent<ZoneDirector>();
		impostoDirectors = componentInParent.GetComponentsInChildren<GlitchImpostoDirector>(true);
		cellDirectors = componentInParent.GetComponentsInChildren<CellDirector>(true);
		stations = componentInParent.GetComponentsInChildren<GlitchLiquidSource>(true);
		nodes = componentInParent.GetComponentsInChildren<GlitchTarrNode>(true);
		breadcrumbs = componentInParent.GetRequiredComponentInChildren<GlitchBreadcrumbNetwork>(true);
		destinationsDict = componentInParent.GetComponentsInChildren<GlitchTeleportDestination>(true).ToDictionary(_003C_003Ec._003C_003E9__27_0 ?? (_003C_003Ec._003C_003E9__27_0 = _003C_003Ec._003C_003E9._003CAwake_003Eb__27_0), _003C_003Ec._003C_003E9__27_1 ?? (_003C_003Ec._003C_003E9__27_1 = _003C_003Ec._003C_003E9._003CAwake_003Eb__27_1));
		breadcrumbs.OnGlitchRegionLoaded();
	}

	public override void OnDestroy()
	{
		base.OnDestroy();
		if (SRSingleton<SceneContext>.Instance != null && SRSingleton<SceneContext>.Instance.RegionRegistry != null)
		{
			SRSingleton<SceneContext>.Instance.RegionRegistry.ReleaseFromRegionSet(base.gameObject, RegionRegistry.RegionSetId.SLIMULATIONS);
		}
	}

	public void OnEnable()
	{
		SRSingleton<SceneContext>.Instance.AmbianceDirector.Register(this);
	}

	public void OnDisable()
	{
		if (SRSingleton<SceneContext>.Instance != null && SRSingleton<SceneContext>.Instance.AmbianceDirector != null)
		{
			SRSingleton<SceneContext>.Instance.AmbianceDirector.Deregister(this);
		}
	}

	public void RegionSetChanged(RegionRegistry.RegionSetId previous, RegionRegistry.RegionSetId current)
	{
		if (current == RegionRegistry.RegionSetId.SLIMULATIONS)
		{
			TimeDirector timeDirector = SRSingleton<SceneContext>.Instance.TimeDirector;
			GlitchMetadata glitch = SRSingleton<SceneContext>.Instance.MetadataDirector.Glitch;
			PlayerState playerState = SRSingleton<SceneContext>.Instance.PlayerState;
			SRSingleton<DynamicObjectContainer>.Instance.DestroyChildren(_003C_003Ec._003C_003E9__31_0 ?? (_003C_003Ec._003C_003E9__31_0 = _003C_003Ec._003C_003E9._003CRegionSetChanged_003Eb__31_0), "GlitchRegionHelper.RegionSetChanged");
			GlitchImpostoDirector[] array = impostoDirectors;
			for (int i = 0; i < array.Length; i++)
			{
				array[i].ResetImpostos();
			}
			CellDirector[] array2 = cellDirectors;
			for (int i = 0; i < array2.Length; i++)
			{
				array2[i].ForceCheckSpawn();
			}
			GlitchLiquidSource[] array3 = stations;
			for (int i = 0; i < array3.Length; i++)
			{
				array3[i].ResetLiquidState();
			}
			List<GlitchTarrNode.Group> list = Enum.GetValues(typeof(GlitchTarrNode.Group)).Cast<GlitchTarrNode.Group>().ToList();
			list.Sort(new GlitchTarrNodeGroupComparer().OrderBy(_003C_003Ec._003C_003E9__31_1 ?? (_003C_003Ec._003C_003E9__31_1 = _003C_003Ec._003C_003E9._003CRegionSetChanged_003Eb__31_1)));
			GlitchTarrNode[] array4 = nodes;
			foreach (GlitchTarrNode glitchTarrNode in array4)
			{
				glitchTarrNode.ResetNode(timeDirector.WorldTime() + (double)((glitch.tarrNodeActivationDelay + (float)(list.IndexOf(glitchTarrNode.activationGroup) + list.Count * glitchTarrNode.activationIndex) * glitch.tarrNodeActivationDelayPerNode) * 3600f));
			}
			foreach (GlitchTeleportDestination destination in destinations)
			{
				destination.Reset(null);
			}
			Randoms.SHARED.Pick(destinations.Where(_003C_003Ec._003C_003E9__31_2 ?? (_003C_003Ec._003C_003E9__31_2 = _003C_003Ec._003C_003E9._003CRegionSetChanged_003Eb__31_2)), null).Reset(timeDirector.HoursFromNow(glitch.teleportActivationDelay.GetRandom()));
			playerState.Ammo.Replace(Identifiable.Id.GLITCH_BUG_REPORT, Identifiable.Id.GLITCH_SLIME);
		}
		if (previous != RegionRegistry.RegionSetId.SLIMULATIONS)
		{
			return;
		}
		_003C_003Ec__DisplayClass31_0 _003C_003Ec__DisplayClass31_ = new _003C_003Ec__DisplayClass31_0();
		_003C_003Ec__DisplayClass31_.player = SRSingleton<SceneContext>.Instance.PlayerState;
		foreach (GlitchTeleportDestination destination2 in destinations)
		{
			destination2.Reset(0.0);
		}
		SRSingleton<DynamicObjectContainer>.Instance.DestroyChildren(_003C_003Ec._003C_003E9__31_3 ?? (_003C_003Ec._003C_003E9__31_3 = _003C_003Ec._003C_003E9._003CRegionSetChanged_003Eb__31_3), "GlitchRegionHelper.RegionSetChanged");
		Destroyer.Destroy(exitHudInstance, "GlitchRegionHelper.RegionSetChanged");
		_003C_003Ec__DisplayClass31_.player.Ammo.Replace(Identifiable.Id.GLITCH_SLIME, Identifiable.Id.GLITCH_BUG_REPORT);
		_003C_003Ec__DisplayClass31_.player.Ammo.Clear(_003C_003Ec__DisplayClass31_._003CRegionSetChanged_003Eb__4);
	}

	public void OnExitTeleporterBecameActive()
	{
		GlitchMetadata glitch = SRSingleton<SceneContext>.Instance.MetadataDirector.Glitch;
		Destroyer.Destroy(exitHudInstance, "GlitchRegionHelper.OnExitTeleporterBecameActive");
		exitHudInstance = UnityEngine.Object.Instantiate(glitch.teleportHudPrefab, SRSingleton<HudUI>.Instance.uiContainer.transform);
		exitHudInstance.StartCoroutine(OnExitTeleporterBecameActive_Coroutine(exitHudInstance));
	}

	private static IEnumerator OnExitTeleporterBecameActive_Coroutine(GameObject instance)
	{
		GlitchMetadata glitch = SRSingleton<SceneContext>.Instance.MetadataDirector.Glitch;
		yield return new WaitForSeconds(glitch.teleportHudLifetime);
		instance.GetRequiredComponent<Animator>().SetBool("state_active", false);
	}

	public float GetCurrentDayFraction_Position()
	{
		return SRSingleton<SceneContext>.Instance.MetadataDirector.Glitch.ambianceTimeOfDay;
	}

	public float GetCurrentDayFraction_Color()
	{
		return SRSingleton<SceneContext>.Instance.MetadataDirector.Glitch.ambianceTimeOfDay;
	}

	public void InitModel(PlayerModel model)
	{
	}

	public void SetModel(PlayerModel model)
	{
	}

	public void TransformChanged(Vector3 position, Quaternion rotation)
	{
	}

	public void RegisteredPotentialAmmoChanged(Dictionary<PlayerState.AmmoMode, List<GameObject>> ammo)
	{
	}

	public void KeyAdded()
	{
	}
}
