using UnityEngine;

public class EnableBasedOnGrounded : MonoBehaviour
{
	public bool enableOnGrounded = true;
}
