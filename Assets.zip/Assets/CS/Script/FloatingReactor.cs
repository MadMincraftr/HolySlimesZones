public interface FloatingReactor
{
	void SetIsFloating(bool isFloating);
}
