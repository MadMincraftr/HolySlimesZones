using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;

public abstract class DroneProgramDestination : DroneProgram
{
	public class FastForward_Response
	{
		public int deposits;

		public int currency;
	}

	[Serializable]
	[CompilerGenerated]
	private sealed class _003C_003Ec
	{
		public static readonly _003C_003Ec _003C_003E9 = new _003C_003Ec();

		public static Predicate<Identifiable.Id> _003C_003E9__13_0;

		internal bool _003C_002Ector_003Eb__13_0(Identifiable.Id id)
		{
			return false;
		}
	}

	public Predicate<Identifiable.Id> predicate = _003C_003Ec._003C_003E9__13_0 ?? (_003C_003Ec._003C_003E9__13_0 = _003C_003Ec._003C_003E9._003C_002Ector_003Eb__13_0);

	protected override DroneAnimator.Id animation
	{
		get
		{
			return DroneAnimator.Id.DEPOSIT;
		}
	}

	protected override DroneAnimatorState.Id animationStateBegin
	{
		get
		{
			return DroneAnimatorState.Id.DEPOSIT_BEGIN;
		}
	}

	protected override DroneAnimatorState.Id animationStateEnd
	{
		get
		{
			return DroneAnimatorState.Id.DEPOSIT_END;
		}
	}

	public abstract int GetAvailableSpace(Identifiable.Id id);

	public abstract FastForward_Response FastForward(Identifiable.Id id, bool overflow, double endTime, int maxFastForward);

	public virtual bool HasAvailableSpace(Identifiable.Id id)
	{
		return GetAvailableSpace(id) > 0;
	}

	public sealed override bool Relevancy()
	{
		throw new InvalidOperationException();
	}

	public abstract bool Relevancy(bool overflow);
}
public abstract class DroneProgramDestination<T> : DroneProgramDestination where T : class
{
	protected int MAX_AVAIL_TO_REPORT = 1000000;

	protected T destination;

	private bool overflow;

	public sealed override bool Relevancy(bool overflow)
	{
		if (drone.ammo.IsEmpty())
		{
			return false;
		}
		Identifiable.Id slotName = drone.ammo.GetSlotName();
		if (!predicate(slotName))
		{
			return false;
		}
		destination = Prioritize(GetDestinations(slotName, overflow)).FirstOrDefault();
		return !IsNull(destination);
	}

	public override void Selected()
	{
		base.Selected();
		overflow = false;
	}

	protected sealed override bool OnAction()
	{
		if (!OnAction_Deposit(overflow))
		{
			return false;
		}
		if (drone.ammo.IsEmpty())
		{
			return true;
		}
		if (overflow)
		{
			Log.Error("Failed to complete overflow deposit.", "destination", destination);
			return true;
		}
		if (GetDestinations(drone.ammo.GetSlotName(), false).Any(_003COnAction_003Eb__3_0))
		{
			return true;
		}
		overflow = true;
		return false;
	}

	protected override bool CanCancel()
	{
		if (!drone.ammo.IsEmpty())
		{
			return IsNull(destination);
		}
		return true;
	}

	private static bool IsNull(T destination)
	{
		if (destination != null)
		{
			return destination.Equals(null);
		}
		return true;
	}

	protected abstract bool OnAction_Deposit(bool overflow);

	protected abstract IEnumerable<T> GetDestinations(Identifiable.Id id, bool overflow);

	protected abstract IEnumerable<T> Prioritize(IEnumerable<T> destinations);

	[CompilerGenerated]
	private bool _003COnAction_003Eb__3_0(T d)
	{
		return d != destination;
	}
}
