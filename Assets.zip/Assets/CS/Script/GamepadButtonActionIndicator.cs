using UnityEngine;

public class GamepadButtonActionIndicator : MonoBehaviour
{
	public void Awake()
	{
	}

	public void Update()
	{
	}
}
