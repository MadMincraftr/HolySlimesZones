using System;
using System.Runtime.CompilerServices;
using UnityEngine;

public class ExpoGameSelectUI : BaseUI
{
	[Serializable]
	[CompilerGenerated]
	private sealed class _003C_003Ec
	{
		public static readonly _003C_003Ec _003C_003E9 = new _003C_003Ec();

		public static Action _003C_003E9__1_0;

		internal void _003CLoadGame_003Eb__1_0()
		{
		}
	}

	public GameObject mainMenuUIPrefab;

	public void LoadGame(TextAsset asset)
	{
		SRSingleton<GameContext>.Instance.AutoSaveDirector.BeginLoad("", asset.name, _003C_003Ec._003C_003E9__1_0 ?? (_003C_003Ec._003C_003E9__1_0 = _003C_003Ec._003C_003E9._003CLoadGame_003Eb__1_0));
	}

	public override void Close()
	{
		UnityEngine.Object.Instantiate(mainMenuUIPrefab);
		base.Close();
	}
}
