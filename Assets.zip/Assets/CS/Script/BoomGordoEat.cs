using UnityEngine;

public class BoomGordoEat : GordoEat, BoomMaterialAnimator.BoomMaterialInformer
{
	public float explodePower = 600f;

	public float explodeRadius = 7f;

	public float minPlayerDamage = 15f;

	public float maxPlayerDamage = 45f;

	protected override void WillStartBurst()
	{
		base.WillStartBurst();
		GetComponentsInChildren<ExplodeIndicatorMarker>(true)[0].SetActive(true);
	}

	protected override void DidCompleteBurst()
	{
		base.DidCompleteBurst();
		PhysicsUtil.Explode(base.gameObject, explodeRadius, explodePower, minPlayerDamage, maxPlayerDamage, base.gameObject);
		GetComponentsInChildren<ExplodeIndicatorMarker>(true)[0].SetActive(false);
	}

	public float GetReadiness()
	{
		return Mathf.Lerp(0.2f, 1f, GetPercentageFed());
	}

	public float GetRecoveriness()
	{
		return 0f;
	}
}
